/** Microservice {@code chnn-cop-o-update-offer}: updates campaign offers. Flow: REST controller, time zone, suppression, message to the EMS, fulfillment event and a response per offer. */
package com.banamex.cops.update_offer;
