package com.banamex.cops.update_offer.service.timeZoneValidation;

import com.banamex.cops.app.model.CopTimezoneLookup;
import com.banamex.cops.app.service.CopTimezoneLookupService;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TzLookUpDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Queries the time zone configuration in the {@code COP_TIMEZONE_LOOKUP} table through the
 * {@code chnn-cop-lib-operation-db} library ({@code CopTimezoneLookupService}).
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CopTimezoneLookupClient implements TimeZoneLookupClient {

    /** Library service, obtained only when it is used. */
    private final ObjectProvider<CopTimezoneLookupService> lookupService;

    /**
     * Looks up the configuration of the system, mode and type.
     * @param system system or channel
     * @param sysMode system mode
     * @param type {@code Request} or {@code Response}
     * @return records found, empty if there are none
     */
    @Override
    public List<TzLookUpDTO> find(String system, String sysMode, String type) {
        CopTimezoneLookupService service = lookupService.orderedStream().findFirst().orElse(null);
        if (service == null) {
            log.warn("CopTimezoneLookupService no está disponible (¿BD sin configurar?); sin lookup de zona horaria");
            return List.of();
        }
        return service.findBySystemNameAndModeAndOperationType(system, sysMode, type).stream()
                .map(this::toDto)
                .toList();
    }

    /**
     * Converts the database record into the DTO; a database {@code NULL} becomes an empty string because the eight fields are mandatory.
     * @param r database record
     * @return DTO
     */
    private TzLookUpDTO toDto(CopTimezoneLookup r) {
        TzLookUpDTO d = new TzLookUpDTO();
        d.setSystemName(nz(r.tzSystemName()));
        d.setMode(nz(r.tzMode()));
        d.setTimeZone(nz(r.tzTimezone()));
        d.setType(nz(r.tzOperationType()));
        d.setTimeOffset(nz(r.tzTimeOffset()));
        d.setDateFormat(nz(r.tzDateFormat()));
        d.setTimeFormat(nz(r.tzTimeFormat()));
        d.setDateTimeFormat(nz(r.tzDatetimeFormat()));
        return d;
    }

    /**
     * @param s text
     * @return the text, or an empty string if it is null
     */
    private static String nz(String s) {
        return s == null ? "" : s;
    }
}
