/** REST endpoint of the offer update. */
package com.banamex.cops.update_offer.controller;
