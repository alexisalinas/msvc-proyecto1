package com.banamex.cops.update_offer.kafka;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * Active destinations of the fulfillment event: the Kafka bridge and the alternate EMS, each with its own switch in the yml.
 * The list is built on each publication, so a configuration change is honored without restarting.
 */
@Component
public class EventDestinations {

    /**
     * A destination of the event.
     * @param tag label written to the log
     * @param name name used in the result texts
     * @param publisher who publishes to that destination
     */
    public record EventDestination(String tag, String name, OfferPublisher publisher) {
    }

    /** Publisher of {@code dry-run} mode: it sends nothing. */
    private static final OfferPublisher DRY_RUN = (refId, json) -> "dry-run";

    /** Source of the destination list. */
    private Supplier<List<EventDestination>> destinations;

    /**
     * Creates the destinations from the configuration.
     * @param kafka Kafka bridge configuration
     * @param alternate alternate EMS configuration
     * @param beans factory to obtain the JMS templates
     */
    public EventDestinations(OfferKafkaProps kafka, AlternateEmsProps alternate, BeanFactory beans) {
        this.destinations = () -> {
            List<EventDestination> out = new ArrayList<>();
            boolean dryRun = "dry-run".equals(kafka.getMode());
            if (kafka.isBridgeEnabled()) {
                out.add(new EventDestination("KAFKA", "Kafka", dryRun ? DRY_RUN : new JmsOfferPublisher(
                        template(beans, "updateOfferJmsTemplate"), kafka.getQueue(), kafka.getMessageFormat(), kafka.getTimeToLiveMs())));
            }
            if (alternate.isEnabled()) {
                out.add(new EventDestination("EMS-ALTERNO", "EMS alterno", dryRun ? DRY_RUN : new JmsOfferPublisher(
                        template(beans, alternate.getJmsTemplateName()), alternate.getQueue(),
                        alternate.getMessageFormat(), alternate.getTimeToLiveMs())));
            }
            return out;
        };
    }

    /**
     * Creates fixed destinations (for tests).
     * @param fixed destinations
     * @return instance with those destinations
     */
    public static EventDestinations of(EventDestination... fixed) {
        EventDestinations result = new EventDestinations(null, null, null);
        result.destinations = () -> List.of(fixed);
        return result;
    }

    /**
     * Active destinations, in order: Kafka bridge and then alternate EMS.
     * @return list of destinations, empty if there is none
     */
    public List<EventDestination> enabled() {
        return destinations.get();
    }

    /**
     * Gets the JMS template by name at publication time, so the connection is only created if the destination is used.
     * @param beans bean factory
     * @param name bean name
     * @return template supplier
     */
    private static Supplier<JmsTemplate> template(BeanFactory beans, String name) {
        return () -> {
            try {
                return beans.getBean(name, JmsTemplate.class);
            } catch (NoSuchBeanDefinitionException e) {
                throw new IllegalStateException("no existe el bean JmsTemplate '" + name
                        + "': revisa su conexión en digital-integration.messaging.jms (jmsTemplateName) o en JmsConfig", e);
            }
        };
    }
}
