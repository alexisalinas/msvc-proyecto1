/** Validation of the rules of the internal DTOs. */
package com.banamex.cops.update_offer.validation;
