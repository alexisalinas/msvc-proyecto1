package com.banamex.cops.update_offer.mapper;

import com.banamex.cops.update_offer.dto.ControlFieldDTO;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Converts the EMS reply (XML or JSON) into {@code UpdateOfferResponse}. It accepts several field names for the code,
 * the description and the reference; if they are missing, the code is {@code ERROR}.
 */
@Component
@RequiredArgsConstructor
public class UpdateOfferResponseXmlMapper {

    /** Reads JSON replies. */
    private final ObjectMapper jsonMapper;

    /**
     * Converts the EMS reply into a single REST response.
     * @param reply raw EMS reply
     * @return REST response
     * @throws IllegalStateException if the reply is empty or cannot be read
     */
    public UpdateOfferResponse fromReply(String reply) {
        if (reply == null || reply.isBlank()) {
            throw new IllegalStateException("Respuesta vacía del EMS");
        }
        return reply.trim().startsWith("{") ? fromJson(reply) : fromXml(reply);
    }

    /**
     * One response per offer: if the XML has several {@code UpdateOfferRes}, it returns one for each, in the same order.
     * @param reply raw EMS reply
     * @return parsed responses
     * @throws IllegalStateException if the reply is empty or cannot be read
     */
    public List<UpdateOfferResponse> fromReplies(String reply) {
        if (reply == null || reply.isBlank()) {
            throw new IllegalStateException("Respuesta vacía del EMS");
        }
        if (reply.trim().startsWith("{")) {
            return List.of(fromJson(reply));
        }
        try {
            Document doc = parse(reply);
            List<Element> items = elements(doc, "UpdateOfferRes");
            if (items.isEmpty()) {
                return List.of(fromNode(doc));
            }
            List<UpdateOfferResponse> out = new ArrayList<>();
            for (Element item : items) {
                out.add(fromNode(item));
            }
            return out;
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo leer la respuesta XML del EMS: " + e.getMessage(), e);
        }
    }

    /**
     * Reads an XML reply.
     * @param xml reply
     * @return REST response
     */
    private UpdateOfferResponse fromXml(String xml) {
        try {
            return fromNode(parse(xml));
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo leer la respuesta XML del EMS: " + e.getMessage(), e);
        }
    }

    /**
     * Reads the fields of a whole document or of a single {@code UpdateOfferRes}.
     * @param root root node
     * @return REST response
     */
    private UpdateOfferResponse fromNode(Node root) {
        List<ControlFieldDTO> controlFields = new ArrayList<>();
        for (Element e : elements(root, "ControlField")) {
            controlFields.add(ControlFieldDTO.builder().contextType(e.getTextContent()).build());
        }
        return build(
                xmlFirst(root, "Code", "ResponseCode", "ReturnCode"),
                xmlFirst(root, "Description", "ResponseText", "Message"),
                xmlFirst(root, "CustomerReferenceNumber", "ReferenceContacto", "ContactReference"),
                xmlFirst(root, "StartDate"),
                xmlFirst(root, "EndDate"),
                xmlFirst(root, "SurveyModeCode", "ModeCmp"),
                controlFields);
    }

    /**
     * Reads a JSON reply.
     * @param json reply
     * @return REST response
     */
    private UpdateOfferResponse fromJson(String json) {
        try {
            JsonNode root = jsonMapper.readTree(json);
            return build(
                    jsonFirst(root, "code", "responseCode", "returnCode"),
                    jsonFirst(root, "description", "responseText", "message"),
                    jsonFirst(root, "customerReferenceNumber", "referenceContacto", "contactReference"),
                    jsonFirst(root, "startDate"),
                    jsonFirst(root, "endDate"),
                    jsonFirst(root, "surveyModeCode", "modeCmp"),
                    List.of());
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo leer la respuesta JSON del EMS: " + e.getMessage(), e);
        }
    }

    /**
     * Builds the response; without a code it uses {@code ERROR} and without a description a generic text.
     * @param code code
     * @param description description
     * @param reference customer reference
     * @param start start date
     * @param end end date
     * @param surveyMode survey mode
     * @param controlFields control fields
     * @return REST response
     */
    private UpdateOfferResponse build(String code, String description, String reference, String start,
                                      String end, String surveyMode, List<ControlFieldDTO> controlFields) {
        return UpdateOfferResponse.builder()
                .code(code != null ? code : "ERROR")
                .description(description != null ? description : "Respuesta del EMS sin descripción")
                .customerReferenceNumber(reference)
                .startDate(start)
                .endDate(end)
                .surveyModeCode(surveyMode)
                .contextType(controlFields.isEmpty() ? null : controlFields)
                .build();
    }

    /**
     * Converts the text into an XML document.
     * @param xml XML text
     * @return document
     * @throws Exception if the XML is not valid
     */
    private Document parse(String xml) throws Exception {
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(true);
        f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        f.setXIncludeAware(false);
        f.setExpandEntityReferences(false);
        return f.newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
    }

    /**
     * First value of the elements with any of those names.
     * @param root root node
     * @param names possible names
     * @return value, or {@code null}
     */
    private String xmlFirst(Node root, String... names) {
        for (String name : names) {
            List<Element> found = elements(root, name);
            if (!found.isEmpty()) {
                String t = found.get(0).getTextContent();
                if (t != null && !t.trim().isEmpty()) return t.trim();
            }
        }
        return null;
    }

    /**
     * Elements with that local name, regardless of the prefix.
     * @param root root node
     * @param localName local name
     * @return elements found
     */
    private List<Element> elements(Node root, String localName) {
        List<Element> out = new ArrayList<>();
        NodeList all = root instanceof Document d ? d.getElementsByTagName("*") : ((Element) root).getElementsByTagName("*");
        for (int i = 0; i < all.getLength(); i++) {
            Element e = (Element) all.item(i);
            String ln = e.getLocalName() != null ? e.getLocalName() : e.getTagName();
            if (ln.equalsIgnoreCase(localName)) out.add(e);
        }
        return out;
    }

    /**
     * Recursively searches the first simple value whose name matches, ignoring case.
     * @param root root node
     * @param names possible names
     * @return value, or {@code null}
     */
    private String jsonFirst(JsonNode root, String... names) {
        for (String name : names) {
            AtomicReference<String> found = new AtomicReference<>();
            search(root, name, found);
            if (found.get() != null) return found.get();
        }
        return null;
    }

    /**
     * Walks the JSON tree until it finds a simple value with that name.
     * @param n current node
     * @param name searched name
     * @param found value found
     */
    private void search(JsonNode n, String name, AtomicReference<String> found) {
        if (found.get() != null || n == null) return;
        if (n.isObject()) {
            for (java.util.Iterator<String> it = n.fieldNames(); it.hasNext(); ) {
                String key = it.next();
                JsonNode value = n.get(key);
                if (found.get() != null) return;
                if (key.equalsIgnoreCase(name) && value.isValueNode() && !value.isNull()) {
                    found.set(value.asText());
                } else {
                    search(value, name, found);
                }
            }
        } else if (n.isArray()) {
            n.forEach(c -> search(c, name, found));
        }
    }
}
