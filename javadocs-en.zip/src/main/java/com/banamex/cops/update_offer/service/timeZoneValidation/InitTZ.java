package com.banamex.cops.update_offer.service.timeZoneValidation;

import com.banamex.cops.update_offer.dto.timeZoneValidation.TzFormatsDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TzLookUpDTO;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * Looks for the time zone configuration that matches the system, mode and type in a list, and builds the formats.
 */
@Component
public class InitTZ {

    /**
     * Looks up the configuration and returns its formats.
     * @param system system or channel
     * @param sysMode system mode
     * @param type {@code Request} or {@code Response}
     * @param lookUp available configurations
     * @return the formats, or empty if there is no configuration
     */
    public Optional<TzFormatsDTO> execute(String system, String sysMode, String type, List<TzLookUpDTO> lookUp) {
        if (lookUp == null) {
            return Optional.empty();
        }
        return lookUp.stream()
                .filter(l -> Objects.equals(system, l.getSystemName())
                        && Objects.equals(sysMode, l.getMode())
                        && Objects.equals(type, l.getType()))
                .findFirst()
                .map(l -> {
                    TzFormatsDTO f = new TzFormatsDTO();
                    f.setTimeZoneOffset(l.getTimeOffset());
                    f.setDateFormat(l.getDateFormat());
                    f.setTimeFormat(l.getTimeFormat());
                    f.setDateTimeFormat(l.getDateTimeFormat());
                    f.setTimeZone(l.getTimeZone());
                    return f;
                });
    }
}
