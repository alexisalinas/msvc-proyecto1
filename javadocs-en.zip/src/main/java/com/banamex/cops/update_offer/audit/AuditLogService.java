package com.banamex.cops.update_offer.audit;

import com.banamex.cops.update_offer.dto.UpdateOfferHeaders;
import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Writes to the log, in JSON, the request the microservice receives and the response it returns.
 * Each point is enabled by {@code audit.points-enabled}: digit 1 enables the request log and digit 4 the response
 * log. Sensitive headers and the card number are masked.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AuditLogService {

    /** Headers whose value is never written to the log. */
    private static final Set<String> SENSITIVE_HEADERS = Set.of(
            "authorization", "proxy-authorization", "cookie", "set-cookie", "x-api-key", "api-key", "client_secret");

    /** Serializes the log messages to JSON. */
    private final ObjectMapper jsonMapper;

    /** Active audit points, for example {@code 1001}. */
    @Value("${audit.points-enabled:1001}")
    private String pointsEnabled;

    /**
     * Writes the received request: headers and body.
     * @param headers request headers
     * @param requests offers of the body
     */
    public void logRequest(UpdateOfferHeaders headers, List<UpdateOfferRequest> requests) {
        if (!requestAuditEnabled()) {
            return;
        }
        try {
            Map<String, Object> message = new LinkedHashMap<>();
            message.put("headers", receivedHeaders(headers));
            message.put("body", maskedBody(requests));
            log.info("[REQUEST] uuid={}\n{}", uuid(headers), pretty(message));
        } catch (Exception e) {
            log.warn("No se pudo escribir el log del request: {}", e.getMessage());
        }
    }

    /**
     * Writes the final response of the microservice.
     * @param headers request headers
     * @param responses responses per offer
     */
    public void logResponse(UpdateOfferHeaders headers, List<UpdateOfferResponse> responses) {
        if (!responseAuditEnabled()) {
            return;
        }
        try {
            log.info("[RESPONSE] uuid={}\n{}", uuid(headers), pretty(responses));
        } catch (Exception e) {
            log.warn("No se pudo escribir el log de la respuesta: {}", e.getMessage());
        }
    }

    /**
     * @return {@code true} if the first digit of {@code audit.points-enabled} is 1
     */
    private boolean requestAuditEnabled() {
        return pointsEnabled != null && pointsEnabled.length() >= 1 && pointsEnabled.charAt(0) == '1';
    }

    /**
     * @return {@code true} if the fourth digit of {@code audit.points-enabled} is 1
     */
    private boolean responseAuditEnabled() {
        return pointsEnabled != null && pointsEnabled.length() >= 4 && pointsEnabled.charAt(3) == '1';
    }

    /**
     * Serializes the object to indented JSON.
     * @param value object
     * @return JSON as text
     */
    private String pretty(Object value) {
        try {
            return jsonMapper.writerWithDefaultPrettyPrinter().writeValueAsString(value);
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo serializar a JSON: " + e.getMessage(), e);
        }
    }

    /**
     * @param headers request headers
     * @return the uuid, or {@code null} if there are no headers
     */
    private static String uuid(UpdateOfferHeaders headers) {
        return headers == null ? null : headers.getUuid();
    }

    /**
     * Received headers with the sensitive ones masked; if the full map did not arrive, it uses the known headers.
     * @param h request headers
     * @return map of name to value
     */
    private Map<String, Object> receivedHeaders(UpdateOfferHeaders h) {
        Map<String, Object> out = new LinkedHashMap<>();
        if (h == null) {
            return out;
        }
        Map<String, String> source = new LinkedHashMap<>();
        if (h.getAll() != null && !h.getAll().isEmpty()) {
            source.putAll(h.getAll());
        } else {
            put(source, "uuid", h.getUuid());
            put(source, "host", h.getHost());
            put(source, "ChannelId", h.getChannelId());
            put(source, "countryCode", h.getCountryCode());
            put(source, "businessCode", h.getBusinessCode());
            put(source, "sid", h.getSid());
            put(source, "Accept-Language", h.getAcceptLanguage());
        }
        source.forEach((name, value) ->
                out.put(name, SENSITIVE_HEADERS.contains(name.toLowerCase(Locale.ROOT)) ? "****" : value));
        return out;
    }

    /**
     * Adds the header to the map only if it has a value.
     * @param map target map
     * @param name header name
     * @param value value
     */
    private static void put(Map<String, String> map, String name, String value) {
        if (value != null) {
            map.put(name, value);
        }
    }

    /**
     * The body as it arrived, with the card number masked.
     * @param requests offers of the body
     * @return offers as maps, or {@code null} if there is no body
     */
    @SuppressWarnings("unchecked")
    private List<Object> maskedBody(List<UpdateOfferRequest> requests) {
        if (requests == null) {
            return null;
        }
        return requests.stream().map(rq -> {
            Map<String, Object> fields = jsonMapper.convertValue(rq, Map.class);
            if (fields != null && fields.get("cardNumber") instanceof String card) {
                fields.put("cardNumber", mask(card));
            }
            return (Object) fields;
        }).toList();
    }

    /**
     * Keeps only the last 4 digits.
     * @param s text
     * @return masked text
     */
    static String mask(String s) {
        if (s == null || s.length() <= 4) {
            return s;
        }
        return "*".repeat(s.length() - 4) + s.substring(s.length() - 4);
    }
}
