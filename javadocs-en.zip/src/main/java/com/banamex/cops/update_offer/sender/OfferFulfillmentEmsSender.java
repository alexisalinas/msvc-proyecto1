package com.banamex.cops.update_offer.sender;

import com.banamex.cops.app.model.CopOfferFulfillment;
import com.banamex.cops.update_offer.kafka.KafkaMetrics;
import com.banamex.cops.update_offer.kafka.OfferDataClient;
import com.banamex.cops.update_offer.kafka.OfferInput;
import com.banamex.cops.update_offer.kafka.OfferKafkaProps;
import com.banamex.cops.update_offer.kafka.OfferKeyBuilder;
import com.banamex.cops.update_offer.kafka.EventDestinations;
import com.banamex.cops.update_offer.kafka.EventDestinations.EventDestination;
import com.banamex.cops.update_offer.service.UpdateOfferResponseFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.task.TaskExecutor;
import org.springframework.core.task.TaskRejectedException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Publishes the offer fulfillment event ({@code Updateofferrequest}) to the active destinations.
 * Sending runs in a separate executor so it does not delay the REST response. Steps of {@link #process}:
 * <ol>
 * <li>Validates that the event has the mandatory fields.</li>
 * <li>Waits the configured delay so the database already has the offer.</li>
 * <li>Queries the offer data in the database ({@link OfferDataClient}).</li>
 * <li>Assembles the event JSON.</li>
 * <li>Publishes it to each active destination, with retries.</li>
 * </ol>
 */
@Slf4j
@Service
public class OfferFulfillmentEmsSender {

    /** Zone in which the event time ({@code timeStamp}) is written. */
    @Value("${update-offer.timezone.ecrm-time-zone:US/Central}")
    private String ecrmTimeZone = "US/Central";

    /** Date-time with milliseconds and offset. */
    private static final DateTimeFormatter WITH_OFFSET_MILLIS = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
    /** Local date-time with milliseconds. */
    private static final DateTimeFormatter LOCAL_MILLIS = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
    /** Date-time with seconds and offset, without fractions. */
    private static final DateTimeFormatter WITH_OFFSET_SECONDS = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssXXX");
    /** Matches the card number in the JSON to mask it in the log. */
    private static final Pattern CARD_IN_JSON = Pattern.compile("(\"CardNumber\"\\s*:\\s*\")(\\d*?)(\\d{4})\"");

    /** Event configuration. */
    private final OfferKafkaProps props;
    /** Builds the offer and wave keys. */
    private final OfferKeyBuilder keys;
    /** Queries the offer data in the database. */
    private final OfferDataClient dataClient;
    /** Active destinations of the event. */
    private final EventDestinations destinations;
    /** Serializes the event to JSON. */
    private final ObjectMapper mapper;
    /** Flow counters. */
    private final KafkaMetrics metrics;
    /** Executor where the publication runs, with a bounded queue. */
    private final TaskExecutor executor;
    /** Result texts of the publication. */
    private final UpdateOfferResponseFactory responses;

    /**
     * Creates the fulfillment event sender.
     * @param props event configuration
     * @param keys key builder
     * @param dataClient database query
     * @param destinations active destinations
     * @param mapper JSON serializer
     * @param metrics counters
     * @param executor publication executor
     * @param responses result texts
     */
    public OfferFulfillmentEmsSender(OfferKafkaProps props, OfferKeyBuilder keys, OfferDataClient dataClient,
                              EventDestinations destinations, ObjectMapper mapper, KafkaMetrics metrics,
                              @Qualifier("offerFulfillmentExecutor") TaskExecutor executor,
                              UpdateOfferResponseFactory responses) {
        this.props = props;
        this.keys = keys;
        this.dataClient = dataClient;
        this.destinations = destinations;
        this.mapper = mapper;
        this.metrics = metrics;
        this.executor = executor;
        this.responses = responses;
    }

    /**
     * Indicates whether the event is built and there is at least one active destination.
     * @return {@code true} if the event must be sent
     */
    public boolean isEnabled() {
        return props.isEnabled() && !destinations.enabled().isEmpty();
    }

    /**
     * Queues the publication in the executor. If the queue is full, it rejects it, counts it and writes the result to the log.
     * @param in input event
     */
    public void sendAsync(OfferInput in) {
        List<EventDestination> activos = destinations.enabled();
        try {
            executor.execute(() -> process(in));
        } catch (TaskRejectedException e) {
            metrics.incRejected();
            log.warn("KAFKA-REJECTED cola llena, no se envió uuid={} refId={}", in.getUuid(), in.getRefId());
            resultado(tag(activos), responses.kafkaErrorText(names(activos), "Cola de envío llena", "no hay espacio en el ejecutor"));
        }
    }

    /**
     * Validates the event, queries the database, builds the JSON and publishes it (synchronous; run by the executor thread).
     * If the offer is not in the database and {@code send-without-db-rows} is {@code true}, the event is sent with the
     * database fields empty. Any failure is written to the log; it is not propagated.
     * @param in input event
     */
    public void process(OfferInput in) {
        List<EventDestination> activos = destinations.enabled();
        String tag = tag(activos);
        String destino = names(activos);
        String paso = "Validación del evento";
        try {
            if (!valid(in)) {
                resultado(tag, responses.kafkaErrorText(destino, paso,
                        "faltan campos obligatorios (RefID, CampaignID, WaveID, CustomerNo, OfferStatus)"));
                return;
            }
            if (props.getDelayMs() > 0) {
                paso = "Espera previa a la consulta";
                Thread.sleep(props.getDelayMs());
            }
            paso = "Consulta a la base de datos";
            String waveKey = keys.waveKey(in.getWaveId(), in.getChannel());
            Optional<CopOfferFulfillment> db =
                    retry("consulta a la BD", () -> dataClient.find(waveKey, in.getOfferKey()));
            if (db.isEmpty()) {
                metrics.incNoRows();
                if (!props.isSendWithoutDbRows()) {
                    log.error("KAFKA-NO-ROWS uuid={} refId={} waveKey={} offerKey={}",
                            in.getUuid(), in.getRefId(), waveKey, in.getOfferKey());
                    resultado(tag, responses.kafkaErrorText(destino, paso,
                            "no se encontró la oferta (waveKey=" + waveKey + ", offerKey=" + in.getOfferKey() + ")"));
                    return;
                }
                log.warn("KAFKA-NO-ROWS uuid={} refId={} waveKey={} offerKey={} se envía el evento sin los datos de la BD",
                        in.getUuid(), in.getRefId(), waveKey, in.getOfferKey());
                db = Optional.of(new CopOfferFulfillment(null, null, null, null, null, null, null,
                        null, null, null, null, null, null, null));
            }
            paso = "Armado del evento";
            String json = mapper.writeValueAsString(assemble(in, db.get()));
            log.info("[{}] Envía: {}", tag, maskCardInJson(json));
            for (EventDestination d : activos) {
                publicar(in, json, d);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.warn("KAFKA-ERROR interrumpido uuid={} refId={}", in.getUuid(), in.getRefId());
            resultado(tag, responses.kafkaErrorText(destino, paso, "el envío se interrumpió"));
        } catch (Exception e) {
            metrics.incFailed();
            log.error("KAFKA-ERROR uuid={} refId={} {}", in.getUuid(), in.getRefId(), e.toString(), e);
            resultado(tag, responses.kafkaErrorText(destino, paso, e));
        }
    }

    /**
     * Publishes the JSON to a destination with retries; if it fails, only that destination is left with an error.
     * @param in input event
     * @param json serialized event
     * @param d destination
     * @throws InterruptedException if the thread is interrupted
     */
    private void publicar(OfferInput in, String json, EventDestination d) throws InterruptedException {
        try {
            retry("publicación en " + d.name(), () -> d.publisher().publish(in.getRefId(), json));
            metrics.incSent();
            resultado(d.tag(), "dry-run".equals(props.getMode())
                    ? responses.kafkaDryRunText(d.name()) : responses.kafkaSuccessText(d.name()));
        } catch (InterruptedException e) {
            throw e;
        } catch (Exception e) {
            metrics.incFailed();
            log.error("KAFKA-ERROR uuid={} refId={} destino={} Causas: {}", in.getUuid(), in.getRefId(), d.name(), EmsSender.causeChain(e), e);
            resultado(d.tag(), responses.kafkaErrorText(d.name(), "Publicación en la cola de " + d.name(), e));
        }
    }

    /**
     * Writes the publication result to the log, with the date in the ECRM zone.
     * @param tag destination tag
     * @param mensaje result text
     */
    private void resultado(String tag, String mensaje) {
        log.info("[{}] Resultado: {}", tag, mensaje);
    }

    /**
     * Log tag of the active destinations, joined with {@code +}.
     * @param activos active destinations
     * @return tag
     */
    private static String tag(List<EventDestination> activos) {
        return activos.isEmpty() ? "KAFKA" : String.join("+", activos.stream().map(EventDestination::tag).toList());
    }

    /**
     * Names of the active destinations for the result texts.
     * @param activos active destinations
     * @return joined names
     */
    private static String names(List<EventDestination> activos) {
        return activos.isEmpty() ? "Kafka" : String.join(" y ", activos.stream().map(EventDestination::name).toList());
    }

    /**
     * Duration of the appointment in minutes, from start to end, rounded.
     * @param start appointment start
     * @param end appointment end
     * @return minutes, or {@code null} if a value is missing or it is not positive
     */
    static Long appointmentMinutes(Timestamp start, Timestamp end) {
        if (start == null || end == null) return null;
        long minutes = Math.round((end.getTime() - start.getTime()) / 60000.0);
        return minutes > 0 ? minutes : null;
    }

    /**
     * Assembles {@code { "event": { "header": ..., "body": ... } }} with the data of the request, the EMS reply and the
     * database, in the event order. If {@code omit-nulls} is {@code true}, null fields are not written.
     * @param in input event
     * @param db offer data from the database
     * @return structure ready to be serialized
     */
    Map<String, Object> assemble(OfferInput in, CopOfferFulfillment db) {
        Map<String, Object> header = new LinkedHashMap<>();
        header.put("name", props.getEventName());
        header.put("version", props.getEventVersion());
        header.put("producerCSI", props.getProducerCsi());
        header.put("Channel", in.getChannel());
        header.put("countryCode", props.getCountryCode());
        header.put("businessCode", props.getBusinessCode());
        header.put("UUID", in.getUuid());
        header.put("sid", isBlank(in.getEsbUuid()) ? in.getUuid() : in.getEsbUuid());
        header.put("transactionTime", isBlank(in.getTransactionTime())
                ? LocalDateTime.now().format(LOCAL_MILLIS) : in.getTransactionTime());
        header.put("timeStamp", OffsetDateTime.now(ZoneId.of(ecrmTimeZone)).format(WITH_OFFSET_MILLIS));

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("RefID", in.getRefId());
        body.put("CampaignID", in.getCampaignId());
        body.put("WaveID", in.getWaveId());
        body.put("CustomerNo", padLeft(in.getCustomerNo(), 9));
        body.put("AccountNo", in.getAccountNo());
        body.put("CardNumber", props.isMaskCardNumber() ? mask(in.getCardNumber()) : in.getCardNumber());
        body.put("OfferStatus", in.getOfferStatus());
        body.put("ID_ProductType", db.prdType());
        body.put("CRP_Category_ID", db.crpCategoryId());
        body.put("Product_Description", db.prdDescription());
        body.put("Reason_Code", db.reasonCode());
        body.put("Reason_Description", db.reasonDesc());
        body.put("Action_ID", in.getActionId());
        body.put("ResponseTime", in.getResponseTime());
        body.put("ResponseCode", in.getResponseCode());
        body.put("ResponseText", in.getResponseText());
        body.put("FulfillmentID", db.fulfillmentProcId());
        List<String> userFields = db.userFields();
        for (int i = 1; i <= 100; i++) {
            body.put("UserField" + i, userFields != null && i <= userFields.size() ? userFields.get(i - 1) : null);
        }
        body.put("AppointmentDate", iso(db.apptStartDate()));
        body.put("AppointmentMinDur", appointmentMinutes(db.apptStartDate(), db.apptEndDate()));
        body.put("OfferExpiryDate", iso(db.expiryDate()));
        body.put("OfferStartDate", iso(db.offerCreationDate()));
        body.put("PrdCode", db.prdCode());
        body.put("PrdFamily", db.prdFamily());
        body.put("Availability", db.availability());

        if (props.isOmitNulls()) {
            header.values().removeIf(Objects::isNull);
            body.values().removeIf(Objects::isNull);
        }

        Map<String, Object> event = new LinkedHashMap<>();
        event.put("header", header);
        event.put("body", body);
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("event", event);
        return root;
    }

    /**
     * Checks that the event has the mandatory fields; otherwise it counts it as invalid.
     * @param in input event
     * @return {@code true} if it is valid
     */
    private boolean valid(OfferInput in) {
        if (isBlank(in.getRefId()) || isBlank(in.getOfferKey()) || isBlank(in.getCampaignId())
                || isBlank(in.getWaveId()) || isBlank(in.getCustomerNo()) || isBlank(in.getOfferStatus())) {
            metrics.incInvalid();
            log.error("KAFKA-INVALID uuid={} refId={} faltan campos obligatorios (RefID, CampaignID, WaveID, CustomerNo, OfferStatus)",
                    in.getUuid(), in.getRefId());
            return false;
        }
        return true;
    }

    /**
     * Retries only infrastructure failures (exceptions), with increasing wait. An empty result is not an exception and is
     * not retried.
     * @param what description of the action for the log
     * @param action action to run
     * @param <T> result type
     * @return result of the action
     * @throws Exception the last failure when the attempts are exhausted
     */
    private <T> T retry(String what, Callable<T> action) throws Exception {
        long backoff = props.getRetryBackoffMs();
        for (int attempt = 1; ; attempt++) {
            try {
                return action.call();
            } catch (Exception e) {
                if (attempt >= props.getMaxAttempts()) {
                    throw e;
                }
                log.warn("KAFKA-RETRY {} intento {}/{}: {}", what, attempt, props.getMaxAttempts(), e.toString());
                if (backoff > 0) {
                    Thread.sleep(backoff);
                }
                backoff *= 2;
            }
        }
    }

    /**
     * Masks the card number in the JSON, keeping the last 4 digits (log only).
     * @param json serialized event
     * @return masked JSON
     */
    static String maskCardInJson(String json) {
        Matcher m = CARD_IN_JSON.matcher(json);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            m.appendReplacement(sb, Matcher.quoteReplacement(m.group(1) + "*".repeat(m.group(2).length()) + m.group(3) + "\""));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    /**
     * Pads with zeros on the left up to the given length.
     * @param s text
     * @param len desired length
     * @return padded text, or {@code null} if it is null
     */
    static String padLeft(String s, int len) {
        if (s == null) return null;
        StringBuilder sb = new StringBuilder();
        for (int i = s.length(); i < len; i++) sb.append('0');
        return sb.append(s).toString();
    }

    /**
     * Keeps only the last 4 characters and replaces the rest with {@code *}.
     * @param s text
     * @return masked text
     */
    static String mask(String s) {
        if (s == null || s.length() <= 4) return s;
        return "*".repeat(s.length() - 4) + s.substring(s.length() - 4);
    }

    /**
     * Converts a database date to a date-time with offset and no fractions, for example {@code 2026-12-31T00:00:00-06:00}.
     * @param v database value
     * @return date as text, or {@code null} if it is null
     */
    static String iso(Object v) {
        if (v == null) return null;
        if (v instanceof Timestamp t) {
            return t.toLocalDateTime().atZone(ZoneId.systemDefault()).format(WITH_OFFSET_SECONDS);
        }
        return v.toString();
    }

    /**
     * @param s text
     * @return {@code true} if it is null or blank
     */
    private static boolean isBlank(String s) { return s == null || s.isBlank(); }
}
