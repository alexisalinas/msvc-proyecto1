/** Check of whether an operation is suppressed for a channel and a country. */
package com.banamex.cops.update_offer.suppressed;
