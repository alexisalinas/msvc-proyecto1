package com.banamex.cops.update_offer.kafka;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/** Configuration of the offer fulfillment event ({@code offer.kafka.*}). */
@Data
@Component
@ConfigurationProperties(prefix = "offer.kafka")
public class OfferKafkaProps {

    /** If {@code false}, no event is built or sent. */
    private boolean enabled = true;

    /** {@code jms} publishes to the active destinations; {@code dry-run} only writes the JSON to the log. */
    private String mode = "dry-run";

    /** If {@code true}, the event is published to the Kafka bridge queue. */
    private boolean bridgeEnabled = false;

    /**
     * If {@code true}, when the query does not return the offer the event is still sent, with the database fields empty.
     */
    private boolean sendWithoutDbRows = true;

    /** Wait in milliseconds before querying the database. */
    private long delayMs = 200;

    /** Kafka bridge queue. */
    private String queue;

    /** Prefix of the offer key. */
    private String offerPrefix = "off:mx:";
    /** Prefix of the wave key. */
    private String wavePrefix = "wvch:";
    /** Separator of the key parts. */
    private String keySeparator = ":";

    /** If {@code true}, null fields are not written to the JSON. */
    private boolean omitNulls = true;
    /** If {@code true}, {@code CardNumber} goes out with only the last 4 digits in the message. */
    private boolean maskCardNumber = false;

    /** Maximum attempts of each query or publication. */
    private int maxAttempts = 3;
    /** Initial wait between attempts in milliseconds; it doubles on each attempt. */
    private long retryBackoffMs = 500;

    /** Message time to live in the bridge queue, in milliseconds; 0 = it does not expire. */
    private long timeToLiveMs = 0;

    /** Message format to the bridge queue: {@code json} or {@code envelope}. */
    private String messageFormat = "json";

    /** CSI of the event producer. */
    private String producerCsi = "163621";
    /** Event name. */
    private String eventName = "Updateofferrequest";
    /** Event version. */
    private String eventVersion = "1.0";
    /** Country code of the event. */
    private String countryCode = "MX";
    /** Business code of the event. */
    private String businessCode = "DM";

    /** Core threads of the executor. */
    private int executorCoreSize = 2;
    /** Maximum threads of the executor. */
    private int executorMaxSize = 4;
    /** Capacity of the executor queue. */
    private int executorQueueCapacity = 100;
}
