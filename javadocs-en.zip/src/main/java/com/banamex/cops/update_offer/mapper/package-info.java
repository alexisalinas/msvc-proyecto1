/** Conversions between the REST offer, the EMS message and the EMS reply. */
package com.banamex.cops.update_offer.mapper;
