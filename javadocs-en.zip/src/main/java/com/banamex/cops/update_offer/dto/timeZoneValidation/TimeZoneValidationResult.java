package com.banamex.cops.update_offer.dto.timeZoneValidation;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Result of the time zone validation: code, text, formats and converted values. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TimeZoneValidationResult {

    /** Result code. */
    @NotBlank(message = "El campo ResponseCode es obligatorio")
    private String responseCode;

    /** Result text. */
    @NotBlank(message = "El campo ResponseText es obligatorio")
    private String responseText;

    /** Time zone formats of the system. */
    private TzFormatsDTO formats;

    /** Converted dates and times. */
    @Valid
    private MapRequestResultDTO mapResult;
}
