package com.banamex.cops.update_offer.dto.timeZoneValidation;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** A value to convert (date, time or date-time) with the name that identifies it. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ValueItemDTO {

    /** Value to convert; if empty it is ignored. */
    private String value;

    /** Name of the value, for example {@code AppointmentDate}. */
    @NotBlank(message = "El nombre del valor es obligatorio")
    private String name;
}
