package com.banamex.cops.update_offer.service.timeZoneValidation;

/** Conditions of the update flow that depend on the time zone. */
public final class UpdateOfferFlowConditions {

    /** It is not instantiated. */
    private UpdateOfferFlowConditions() {
    }

    /**
     * Indicates whether the time zone must be validated: the value is {@code true}, ignoring case.
     * @param translateTimeZone configured value
     * @return {@code true} if it must be validated
     */
    public static boolean translateTimeZone(String translateTimeZone) {
        return "true".equalsIgnoreCase(translateTimeZone);
    }

    /**
     * Indicates whether the flow continues with the suppression check: the validation code ends in {@code 0} (success) or is the not-configured one.
     * @param tzResponseCode code of the time zone validation
     * @return {@code true} if it must continue
     */
    public static boolean continueToSuppression(String tzResponseCode) {
        if (tzResponseCode == null || tzResponseCode.isEmpty()) {
            return false;
        }
        return tzResponseCode.endsWith("0") || "COP_TZCOD_114".equals(tzResponseCode);
    }
}
