package com.banamex.cops.update_offer.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;

@Configuration
@ComponentScan(basePackages = "com.banamex.cops.app", useDefaultFilters = false,
        includeFilters = @ComponentScan.Filter(type = FilterType.REGEX, pattern = ".*Repository(Custom)?Impl"))
/**
 * Registers the custom implementations of the library JPA repositories (for example
 * {@code DOfferpaletteRepositoryCustomImpl}), which Spring Data looks up by name. Only those: the rest of the library is
 * not scanned, to avoid duplicate beans.
 */
public class LibraryRepositoryFragmentsConfig {
}
