package com.banamex.cops.update_offer.mapper;

import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.timeZoneValidation.MapRequestResultDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Map;

import static com.banamex.cops.update_offer.mapper.XmlUtil.tag;

/** Converts the offer into the XML and the message properties sent to the EMS. */
@Component
@RequiredArgsConstructor
public class UpdateOfferRequestXmlMapper {

    /** Builds the event fields. */
    private final OfferEventMapper offerEventMapper;

    /**
     * If {@code true}, the event goes inside {@code <Envelope><Body>}; if {@code false}, only the event is sent.
     */
    @Value("${update-offer.ems.envelope:true}")
    private boolean envelope;

    /** If {@code true}, the event element carries its namespace as an unprefixed {@code xmlns}. */
    @Value("${update-offer.ems.xml-namespace:false}")
    private boolean xmlNamespace;

    /** Event namespace. */
    @Value("${update-offer.ems.event-namespace:www.tibco.com/be/ontology/OfferEngine/Events/UpdateOffer}")
    private String eventNamespace = "www.tibco.com/be/ontology/OfferEngine/Events/UpdateOffer";

    /** Name of the event body element. */
    @Value("${update-offer.ems.body-element:UpdateOffer}")
    private String bodyElement;

    /**
     * Builds the message XML: the event with its fields as simple elements, without prefixes.
     * @param rq offer
     * @param requestTime processing time
     * @param updatedBy value of the {@code client_id} header
     * @param tzResponseCode time zone code
     * @param tz converted dates and times
     * @return message XML
     */
    public String toEmsXml(UpdateOfferRequest rq, LocalDateTime requestTime, String updatedBy,
                           String tzResponseCode, MapRequestResultDTO tz) {
        Map<String, String> fields = offerEventMapper.map(rq, requestTime, updatedBy, tzResponseCode, tz);

        String indent = envelope ? "      " : "";
        StringBuilder x = new StringBuilder();
        if (envelope) {
            x.append("<Envelope>\n");
            x.append("   <Body>\n");
        }
        x.append(indent).append("<").append(bodyElement)
                .append(xmlNamespace ? " xmlns=\"" + XmlUtil.esc(eventNamespace) + "\"" : "").append(">\n");
        fields.forEach((k, v) -> tag(x, indent + "   ", k, v));
        x.append(indent).append("</").append(bodyElement).append(">");
        if (envelope) {
            x.append("\n   </Body>\n");
            x.append("</Envelope>");
        }
        return x.toString();
    }

    /**
     * Builds the JMS message properties: {@code _nm_} (event name), {@code _ns_} (namespace) and the offer fields.
     * @param rq offer
     * @param requestTime processing time
     * @param updatedBy value of the {@code client_id} header
     * @param tzResponseCode time zone code
     * @param tz converted dates and times
     * @return message properties
     */
    public Map<String, String> toEmsProperties(UpdateOfferRequest rq, LocalDateTime requestTime, String updatedBy,
                                               String tzResponseCode, MapRequestResultDTO tz) {
        Map<String, String> properties = new java.util.LinkedHashMap<>();
        properties.put("_nm_", bodyElement);
        properties.put("_ns_", eventNamespace);
        properties.putAll(offerEventMapper.map(rq, requestTime, updatedBy, tzResponseCode, tz));
        return properties;
    }
}
