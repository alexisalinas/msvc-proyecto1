package com.banamex.cops.update_offer.validation;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/** Applies the validation rules (mandatory, optional, list) carried by the internal DTOs of the flow. */
@Component
public class DtoValidator {

    /** Jakarta Validation validator. */
    private final Validator validator;

    /**
     * Constructor used by Spring: it takes the validator from the context or, if there is none, creates a default one.
     * @param provider validator provider
     */
    @Autowired
    public DtoValidator(ObjectProvider<Validator> provider) {
        Validator v = provider.getIfAvailable();
        this.validator = v != null ? v : Validation.buildDefaultValidatorFactory().getValidator();
    }

    /**
     * Constructor with an already created validator (useful in tests).
     * @param validator validator
     */
    public DtoValidator(Validator validator) {
        this.validator = validator;
    }

    /**
     * Rules the DTO breaks.
     * @param dto object to validate
     * @return sorted list of {@code path: message}, empty if everything is met
     */
    public List<String> violations(Object dto) {
        return validator.validate(dto).stream()
                .map((ConstraintViolation<Object> v) -> v.getPropertyPath() + ": " + v.getMessage())
                .sorted()
                .toList();
    }

    /**
     * Throws an exception with the detail if the DTO breaks any rule.
     * @param dto object to validate
     * @throws IllegalArgumentException if any rule is broken
     */
    public void validateOrThrow(Object dto) {
        List<String> v = violations(dto);
        if (!v.isEmpty()) {
            throw new IllegalArgumentException(
                    "Datos inválidos en " + dto.getClass().getSimpleName() + ": " + String.join("; ", v));
        }
    }
}
