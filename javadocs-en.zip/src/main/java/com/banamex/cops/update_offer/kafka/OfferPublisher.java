package com.banamex.cops.update_offer.kafka;

/** Publishes the event to a destination. */
public interface OfferPublisher {
    /**
     * Publishes the event.
     * @param refId event reference
     * @param json serialized event
     * @return result of the publication
     * @throws Exception if the publication fails
     */
    String publish(String refId, String json) throws Exception;
}
