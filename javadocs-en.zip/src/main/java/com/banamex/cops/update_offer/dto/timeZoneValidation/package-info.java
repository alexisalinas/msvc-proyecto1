/** Objects of the time zone validation and conversion. */
package com.banamex.cops.update_offer.dto.timeZoneValidation;
