package com.banamex.cops.update_offer.suppressed;

import com.banamex.cops.app.model.CopSuppressionChannel;
import com.banamex.cops.app.model.CopSuppressionOperation;
import com.banamex.cops.update_offer.dto.suppression.OperationDetailsDTO;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntitiesListRoot;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntityDTO;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/** Builds the list of suppressed entities from the channel and operation rows of the database. */
@Component
public class StartUpSuppressionLoader {

    /**
     * Builds the list of suppressed entities.
     * @param channels suppressed channels
     * @param operations suppressed operations
     * @return built list
     */
    public SuppressedEntitiesListRoot build(List<CopSuppressionChannel> channels, List<CopSuppressionOperation> operations) {
        List<CopSuppressionOperation> ops = operations == null ? List.of() : operations;
        List<SuppressedEntityDTO> entities = new ArrayList<>();
        if (channels != null) {
            for (CopSuppressionChannel channel : channels) {
                entities.add(entity(channel, details(channel, ops)));
            }
        }
        return SuppressedEntitiesListRoot.builder().suppressedEntities(entities).build();
    }

    /**
     * Converts a channel into an entity with its operations.
     * @param c channel
     * @param details operations of the channel
     * @return entity
     */
    private SuppressedEntityDTO entity(CopSuppressionChannel c, List<OperationDetailsDTO> details) {
        return SuppressedEntityDTO.builder()
                .countryCode(c.countryCode())
                .mode(c.reqMode())
                .channelId(c.channelId())
                .suppressionFlag(c.suppressionFlag())
                .operationFlag(c.operationFlag())
                .sourceSystem(c.sourceSystem())
                .operationDetails(details)
                .build();
    }

    /**
     * Operations of the channel according to its flags. With suppression {@code Y} and operations {@code Y}: the operations of that channel. With suppression {@code Y} and operations {@code N}: all the operations, each with its own flag. Otherwise: none.
     * @param c channel
     * @param ops suppressed operations
     * @return operations of the channel
     */
    private List<OperationDetailsDTO> details(CopSuppressionChannel c, List<CopSuppressionOperation> ops) {
        List<OperationDetailsDTO> out = new ArrayList<>();
        if ("Y".equals(c.suppressionFlag()) && "Y".equals(c.operationFlag())) {
            for (CopSuppressionOperation o : ops) {
                if (o.reqChannel() != null && o.reqChannel().equals(c.channelId())) {
                    out.add(detail(o, "Y"));
                }
            }
        } else if ("Y".equals(c.suppressionFlag()) && "N".equals(c.operationFlag())) {
            for (CopSuppressionOperation o : ops) {
                out.add(detail(o, o.operationSuppressFlag()));
            }
        }
        return out;
    }

    /**
     * Converts a database operation into its DTO.
     * @param o operation
     * @param operationFlag operation flag
     * @return operation DTO
     */
    private OperationDetailsDTO detail(CopSuppressionOperation o, String operationFlag) {
        return OperationDetailsDTO.builder()
                .operationName(o.operationName())
                .operationFlag(operationFlag)
                .reqChannel(o.reqChannel())
                .build();
    }
}
