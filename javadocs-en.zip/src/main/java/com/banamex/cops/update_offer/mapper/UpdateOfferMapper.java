package com.banamex.cops.update_offer.mapper;

import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import com.banamex.cops.update_offer.dto.timeZoneValidation.MapRequestResultDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Conversion facade used by the service: from the offer to the EMS message and from the EMS reply to the REST response.
 */
@Component
@RequiredArgsConstructor
public class UpdateOfferMapper {

    /** Builds the XML and the message properties. */
    private final UpdateOfferRequestXmlMapper requestXmlMapper;
    /** Reads the EMS reply. */
    private final UpdateOfferResponseXmlMapper responseXmlMapper;

    /**
     * Properties of the message to the EMS: the name and namespace of the event plus the offer fields.
     * @param rq offer
     * @param requestTime processing time
     * @param updatedBy value of the {@code client_id} header
     * @param tzResponseCode time zone code
     * @param tz converted dates and times
     * @return message properties
     */
    public java.util.Map<String, String> toEmsProperties(UpdateOfferRequest rq, LocalDateTime requestTime, String updatedBy,
                                                         String tzResponseCode, MapRequestResultDTO tz) {
        return requestXmlMapper.toEmsProperties(rq, requestTime, updatedBy, tzResponseCode, tz);
    }

    /**
     * XML sent to the EMS with the {@code UpdateOffer} event.
     * @param rq offer
     * @param requestTime processing time
     * @param updatedBy value of the {@code client_id} header
     * @param tzResponseCode time zone code
     * @param tz converted dates and times
     * @return message XML
     */
    public String toEmsXml(UpdateOfferRequest rq, LocalDateTime requestTime, String updatedBy,
                           String tzResponseCode, MapRequestResultDTO tz) {
        return requestXmlMapper.toEmsXml(rq, requestTime, updatedBy, tzResponseCode, tz);
    }

    /**
     * One response per offer: when the message carries several offers, the EMS answers one for each.
     * @param reply raw EMS reply
     * @return parsed responses
     */
    public List<UpdateOfferResponse> toRestResponses(String reply) {
        return responseXmlMapper.fromReplies(reply);
    }

    /**
     * Converts the EMS reply (XML or JSON) into a single REST response.
     * @param reply raw EMS reply
     * @return REST response
     */
    public UpdateOfferResponse toRestResponse(String reply) {
        return responseXmlMapper.fromReply(reply);
    }
}
