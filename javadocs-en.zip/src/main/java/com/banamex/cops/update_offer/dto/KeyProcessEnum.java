package com.banamex.cops.update_offer.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/** Execution versions allowed for {@code keyProcess}. */
public enum KeyProcessEnum {
    /** Version 1. */
    V1("V1"),
    /** Version 2. */
    V2("V2"),
    /** Version 3. */
    V3("V3");

    /** Text used to send and receive it in the JSON. */
    private final String value;

    /**
     * @param value version text
     */
    KeyProcessEnum(String value) {
        this.value = value;
    }

    /**
     * Text value used to serialize the process in the JSON.
     * @return version text
     */
    @JsonValue
    public String getValue() {
        return value;
    }

    /**
     * Converts the received text into the matching version, ignoring case.
     * @param value received text
     * @return version
     * @throws IllegalArgumentException if the text is not a valid version
     */
    @JsonCreator
    public static KeyProcessEnum fromValue(String value) {
        for (KeyProcessEnum process : KeyProcessEnum.values()) {
            if (process.value.equalsIgnoreCase(value)) {
                return process;
            }
        }
        throw new IllegalArgumentException("Valor inválido para KeyProcessEnum: " + value);
    }
}