package com.banamex.cops.update_offer.service;

import com.banamex.cops.update_offer.config.UpdateOfferResponseProperties;
import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.Clock;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Builds the responses the microservice returns for each offer and the result texts of the event publication.
 * Codes and texts come from {@link UpdateOfferResponseProperties}; the date is written in the ECRM zone.
 */
@Component
@RequiredArgsConstructor
public class UpdateOfferResponseFactory {

    /** Configured codes, texts and date format. */
    private final UpdateOfferResponseProperties props;

    /** Zone in which the date of the texts is written. */
    @Value("${update-offer.timezone.ecrm-time-zone:US/Central}")
    private String ecrmTimeZone = "US/Central";

    /** Clock used for the date; replaced in the tests. */
    private Clock clock = Clock.systemUTC();

    /**
     * Generic success response.
     * @return the configured success code and text
     */
    public UpdateOfferResponse success() {
        return build(props.getSuccessCode(), props.getSuccessText(), "", "");
    }

    /**
     * Success response of an offer.
     * If the offer has status {@code U} and that format is enabled, it answers with the offer key; if it has no
     * {@code campaignId}, it answers with the missing-campaign code. Otherwise, the generic success.
     * @param request processed offer
     * @return success response
     */
    public UpdateOfferResponse success(UpdateOfferRequest request) {
        if (request == null || !props.isStatusUBwFormat() || !"U".equals(request.getOfferStatus())) {
            return success();
        }
        UpdateOfferResponse r = new UpdateOfferResponse();
        if (isEmpty(request.getCampaignId())) {
            r.setCode(props.getStatusUCampaignMissingCode());
            r.setDescription(props.getStatusUCampaignMissingText()
                    .replace("{campaignId}", request.getCampaignId() == null ? "" : request.getCampaignId()));
        } else {
            r.setCode(props.getStatusUSuccessCode());
            r.setDescription(props.getStatusUSuccessText().replace("{offerKey}", updateKey(request)));
        }
        return r;
    }

    /**
     * Success response taking into account what the EMS answered.
     * With {@code update-offer.response.source=ems} and an EMS response with a code, it returns the EMS one (except for
     * status {@code U}); otherwise it builds the microservice response.
     * @param request processed offer
     * @param emsResponse response read from the EMS, or {@code null}
     * @return response of the offer
     */
    public UpdateOfferResponse success(UpdateOfferRequest request, UpdateOfferResponse emsResponse) {
        boolean esU = request != null && props.isStatusUBwFormat() && "U".equals(request.getOfferStatus());
        if (!esU && "ems".equalsIgnoreCase(props.getSource()) && emsResponse != null
                && emsResponse.getCode() != null && !emsResponse.getCode().isBlank()) {
            return emsResponse;
        }
        return success(request);
    }

    /**
     * Offer key for status {@code U}: {@code off:mx:campaign_wave_customer[_account][_card]}.
     * @param rq offer
     * @return offer key
     */
    static String updateKey(UpdateOfferRequest rq) {
        StringBuilder key = new StringBuilder("off:mx:")
                .append(nz(rq.getCampaignId())).append('_')
                .append(nz(rq.getWaveId())).append('_')
                .append(nz(rq.getCustomerId()));
        if (!isEmpty(rq.getAccountNumber())) {
            key.append('_').append(rq.getAccountNumber());
        }
        if (!isEmpty(rq.getCardNumber())) {
            key.append('_').append(rq.getCardNumber());
        }
        return key.toString();
    }

    /**
     * A text is empty if it is null or has no characters; one with only spaces counts as having a value.
     * @param s text
     * @return {@code true} if it is null or empty
     */
    private static boolean isEmpty(String s) {
        return s == null || s.isEmpty();
    }

    /**
     * @param s text
     * @return the text, or an empty string if it is null
     */
    private static String nz(String s) {
        return s == null ? "" : s;
    }

    /**
     * Error response of an offer.
     * @param step name of the step that failed
     * @param cause cause of the failure
     * @return error code and text with the step and the detail
     */
    public UpdateOfferResponse error(String step, Throwable cause) {
        return build(props.getErrorCode(), props.getErrorText(), step, detail(cause));
    }

    /**
     * Result text when the event was published.
     * @param destination destination name
     * @return text with the date
     */
    public String kafkaSuccessText(String destination) {
        return format(props.getKafkaSuccessText(), "", "").replace("{destination}", nz(destination));
    }

    /**
     * Result text when the event has no active destination.
     * @return text with the date
     */
    public String kafkaDisabledText() {
        return format(props.getKafkaDisabledText(), "", "");
    }

    /**
     * Result text when the destination is in dry-run and nothing was published.
     * @param destination destination name
     * @return text with the date
     */
    public String kafkaDryRunText(String destination) {
        return format(props.getKafkaDryRunText(), "", "").replace("{destination}", nz(destination));
    }

    /**
     * Result text when the publication to the destination failed.
     * @param destination destination name
     * @param step step that failed
     * @param detail detail of the failure
     * @return text with the date
     */
    public String kafkaErrorText(String destination, String step, String detail) {
        return format(props.getKafkaErrorText(), step, detail).replace("{destination}", nz(destination));
    }

    /**
     * Same as the previous one, taking the detail from the deepest cause of the exception.
     * @param destination destination name
     * @param step step that failed
     * @param cause exception
     * @return text with the date
     */
    public String kafkaErrorText(String destination, String step, Throwable cause) {
        return kafkaErrorText(destination, step, detail(cause));
    }

    /**
     * Creates the response with the code and the completed text.
     * @param code code
     * @param textTemplate text with placeholders
     * @param step step for the {@code {step}} placeholder
     * @param detail detail for the {@code {detail}} placeholder
     * @return response
     */
    private UpdateOfferResponse build(String code, String textTemplate, String step, String detail) {
        UpdateOfferResponse r = new UpdateOfferResponse();
        r.setCode(code);
        r.setDescription(format(textTemplate, step, detail));
        return r;
    }

    /**
     * Replaces the {@code {dateTime}}, {@code {step}} and {@code {detail}} placeholders of the text.
     * @param template text with placeholders
     * @param step step
     * @param detail detail
     * @return complete text
     */
    private String format(String template, String step, String detail) {
        return template
                .replace("{dateTime}", dateTime())
                .replace("{step}", step == null ? "" : step)
                .replace("{detail}", detail == null ? "" : detail);
    }

    /**
     * Current date and time in the ECRM zone, with the configured format.
     * @return date and time as text
     */
    String dateTime() {
        return ZonedDateTime.now(clock.withZone(ZoneId.of(ecrmTimeZone)))
                .format(DateTimeFormatter.ofPattern(props.getDateFormat()));
    }

    /**
     * Message of the deepest cause; if it has none, the name of its class.
     * @param cause exception
     * @return detail of the failure
     */
    private static String detail(Throwable cause) {
        if (cause == null) return "";
        Throwable root = cause;
        while (root.getCause() != null && root.getCause() != root) root = root.getCause();
        return root.getMessage() != null ? root.getMessage() : root.getClass().getSimpleName();
    }
}
