package com.banamex.cops.update_offer.dto.suppression;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Suppressed operation with the response code and text that are returned. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OperationDetailOutput {

    /** Operation name. */
    @NotBlank(message = "El campo OperationName es obligatorio")
    private String operationName;

    /** Channel that requests the operation. */
    @NotBlank(message = "El campo ReqChannel es obligatorio")
    private String reqChannel;

    /** Operation flag. */
    @NotBlank(message = "El campo OperationFlag es obligatorio")
    private String operationFlag;

    /** Country. */
    @NotBlank(message = "El campo CountryCode es obligatorio")
    private String countryCode;

    /** Suppression response code. */
    @NotBlank(message = "El campo ResponseCode es obligatorio")
    private String responseCode;

    /** Suppression response text. */
    @NotBlank(message = "El campo ResponseText es obligatorio")
    private String responseText;

    /** {@code true} when the operation is suppressed. */
    private String indicator;
}
