package com.banamex.cops.update_offer.dto.suppression;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/** A suppressed entity that matches the request. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FilteredSuppressionResult {

    /** Country. */
    @NotBlank(message = "El campo CountryCode es obligatorio")
    private String countryCode;

    /** Channel. */
    @NotBlank(message = "El campo ChannelID es obligatorio")
    private String channelID;

    /** Suppression flag of the channel. */
    @NotBlank(message = "El campo SuppressionFlag es obligatorio")
    private String suppressionFlag;

    /** Operation flag of the channel. */
    @NotBlank(message = "El campo OperationFlag es obligatorio")
    private String operationFlag;

    /** Suppression mode. */
    @NotBlank(message = "El campo Mode es obligatorio")
    private String mode;

    /** Source system of the suppression. */
    @NotBlank(message = "El campo SourceSystem es obligatorio")
    private String sourceSystem;

    /** Matching suppressed operations. */
    @NotNull
    @Valid
    @Builder.Default
    private List<OperationDetailOutput> operationDetails = new ArrayList<>();
}
