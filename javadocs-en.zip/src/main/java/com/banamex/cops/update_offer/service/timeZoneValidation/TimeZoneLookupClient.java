package com.banamex.cops.update_offer.service.timeZoneValidation;

import com.banamex.cops.update_offer.dto.timeZoneValidation.TzLookUpDTO;

import java.util.List;

/** Queries the time zone configuration by system, mode and type. */
public interface TimeZoneLookupClient {
    /**
     * Looks up the configuration.
     * @param system system or channel
     * @param sysMode system mode
     * @param type {@code Request} or {@code Response}
     * @return records found, empty if there are none
     */
    List<TzLookUpDTO> find(String system, String sysMode, String type);
}
