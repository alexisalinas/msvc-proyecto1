package com.banamex.cops.update_offer.dto.timeZoneValidation;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/** Input data of the time zone validation: system, mode, type and the values to convert. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TimeZoneValidationStartDTO {

    /** System or channel whose time zone is looked up. */
    @NotBlank(message = "El campo System es obligatorio")
    private String system;

    /** System mode. */
    @NotBlank(message = "El campo SysMode es obligatorio")
    private String sysMode;

    /** {@code Request} to take the client values to the backend, {@code Response} for the opposite direction. */
    @NotBlank(message = "El campo Type es obligatorio")
    private String type;

    /** Dates to convert. */
    @NotNull
    @Valid
    @Builder.Default
    private List<ValueItemDTO> date = new ArrayList<>();

    /** Times to convert. */
    @NotNull
    @Valid
    @Builder.Default
    private List<ValueItemDTO> time = new ArrayList<>();

    /** Date-times to convert. */
    @NotNull
    @Valid
    @Builder.Default
    private List<ValueItemDTO> dateTime = new ArrayList<>();
}
