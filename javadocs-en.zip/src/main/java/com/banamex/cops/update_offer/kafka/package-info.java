/** Offer fulfillment event: configuration, keys, destinations (Kafka bridge and alternate EMS), publication and metrics. */
package com.banamex.cops.update_offer.kafka;
