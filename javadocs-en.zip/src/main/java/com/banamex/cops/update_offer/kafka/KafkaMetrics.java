package com.banamex.cops.update_offer.kafka;

import org.springframework.stereotype.Component;

import java.util.concurrent.atomic.AtomicLong;

/** Simple counters of the event publication: sent, without database rows, invalid, failed and rejected. */
@Component
public class KafkaMetrics {

    /** Published events. */
    private final AtomicLong sent = new AtomicLong();
    /** Offers not found in the database. */
    private final AtomicLong noRows = new AtomicLong();
    /** Events discarded for missing mandatory data. */
    private final AtomicLong invalid = new AtomicLong();
    /** Publications that failed after the retries. */
    private final AtomicLong failed = new AtomicLong();
    /** Publications rejected because the executor queue was full. */
    private final AtomicLong rejected = new AtomicLong();

    /** Adds one published event. */
    public void incSent() { sent.incrementAndGet(); }
    /** Adds one offer not found in the database. */
    public void incNoRows() { noRows.incrementAndGet(); }
    /** Adds one input discarded for missing mandatory data. */
    public void incInvalid() { invalid.incrementAndGet(); }
    /** Adds one publication that failed after the retries. */
    public void incFailed() { failed.incrementAndGet(); }
    /** Adds one publication rejected because the executor queue was full. */
    public void incRejected() { rejected.incrementAndGet(); }

    /**
     * @return published events
     */
    public long getSent() { return sent.get(); }

    /**
     * @return offers without database rows
     */
    public long getNoRows() { return noRows.get(); }

    /**
     * @return invalid events
     */
    public long getInvalid() { return invalid.get(); }

    /**
     * @return failed publications
     */
    public long getFailed() { return failed.get(); }

    /**
     * @return rejected publications
     */
    public long getRejected() { return rejected.get(); }
}
