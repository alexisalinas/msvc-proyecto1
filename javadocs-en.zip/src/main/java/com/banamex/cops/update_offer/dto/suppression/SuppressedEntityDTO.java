package com.banamex.cops.update_offer.dto.suppression;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/** A channel with its suppression flags and the operations it affects. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SuppressedEntityDTO {

    /** Country. */
    @JsonProperty("CountryCode")
    private String countryCode;

    /** Channel. */
    @JsonProperty("ChannelId")
    private String channelId;

    /** Suppression mode. */
    @NotBlank(message = "El campo Mode es obligatorio")
    @JsonProperty("Mode")
    private String mode;

    /** Suppression flag. */
    @NotBlank(message = "El campo Suppression_Flag es obligatorio")
    @JsonProperty("Suppression_Flag")
    private String suppressionFlag;

    /** Operation flag. */
    @NotBlank(message = "El campo Operation_Flag es obligatorio")
    @JsonProperty("Operation_Flag")
    private String operationFlag;

    /** Source system. */
    @NotBlank(message = "El campo SourceSystem es obligatorio")
    @JsonProperty("SourceSystem")
    private String sourceSystem;

    /** Operations of the channel. */
    @NotNull
    @Valid
    @Builder.Default
    @JsonProperty("OperationDetails")
    private List<OperationDetailsDTO> operationDetails = new ArrayList<>();
}
