package com.banamex.cops.update_offer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Entry point of the {@code chnn-cop-o-update-offer} microservice.
 * It receives a list of offers over REST, validates time zone and suppression, sends the update message to the EMS
 * and publishes the fulfillment event of each offer.
 */
@SpringBootApplication(scanBasePackages = "com.banamex.cops.update_offer")
public class UpdateOfferApplication {

    /**
     * Starts the Spring Boot application.
     * @param args command-line arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(UpdateOfferApplication.class, args);
    }
}
