package com.banamex.cops.update_offer.kafka;

import com.banamex.cops.update_offer.dto.UpdateOfferHeaders;
import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Builds the input event of the fulfillment publication ({@link OfferInput}) from the request, the HTTP headers and the
 * EMS reply: offer keys, transaction identifiers and event times.
 */
@Component
@RequiredArgsConstructor
public class KafkaSenderDashboard {

    /** Zone in which the response time ({@code ResponseTime}) is written. */
    @Value("${update-offer.timezone.ecrm-time-zone:US/Central}")
    private String ecrmTimeZone = "US/Central";

    /** Generates the ESB identifier of the transaction (a GUID). */
    private Supplier<String> esbUuidGenerator = () -> UUID.randomUUID().toString();

    /** Format of the transaction time. */
    private static final DateTimeFormatter TRANSACTION_TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
    /** Offset format of the response time. */
    private static final DateTimeFormatter WITH_OFFSET = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

    /** Builds the offer keys. */
    private final OfferKeyBuilder keys;

    /**
     * Builds the input event of the publication.
     * @param rq received offer
     * @param headers request headers
     * @param requestTime time when the offer started to be processed
     * @param rs EMS response, or {@code null} if there was none
     * @return input event
     */
    public OfferInput build(UpdateOfferRequest rq, UpdateOfferHeaders headers, LocalDateTime requestTime,
                            UpdateOfferResponse rs) {
        LocalDateTime time = requestTime != null ? requestTime : LocalDateTime.now();
        return OfferInput.builder()
                .uuid(headers.getUuid())
                .esbUuid(esbUuidGenerator.get())
                .channel(rq.getChannelCode())
                .transactionTime(time.format(TRANSACTION_TIME))
                .refId(keys.refId(rq.getCampaignId(), rq.getWaveId(), rq.getCustomerId(), rq.getAccountNumber(), rq.getCardNumber()))
                .offerKey(keys.offerKey(rq.getCampaignId(), rq.getWaveId(), rq.getCustomerId(), rq.getAccountNumber()))
                .campaignId(rq.getCampaignId())
                .waveId(rq.getWaveId())
                .customerNo(rq.getCustomerId())
                .accountNo(rq.getAccountNumber())
                .cardNumber(rq.getCardNumber())
                .offerStatus(rq.getOfferStatus())
                .actionId(rq.getOfferActionCode())
                .responseTime(OffsetDateTime.now(ZoneId.of(ecrmTimeZone)).format(WITH_OFFSET))
                .responseCode(rs != null ? rs.getCode() : null)
                .responseText(rs != null ? rs.getDescription() : null)
                .build();
    }
}
