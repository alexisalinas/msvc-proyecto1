package com.banamex.cops.update_offer.dto.timeZoneValidation;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/** Conversion result: dates, times and date-times. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MapRequestResultDTO {

    /** Converted dates. */
    @NotNull @Valid @Builder.Default private List<DateGrpDTO> dateGrp = new ArrayList<>();
    /** Converted times. */
    @NotNull @Valid @Builder.Default private List<TimeGrpDTO> timeGrp = new ArrayList<>();
    /** Converted date-times. */
    @NotNull @Valid @Builder.Default private List<DateTimeGrpDTO> dateTimeGrp = new ArrayList<>();
}
