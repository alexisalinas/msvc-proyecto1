package com.banamex.cops.update_offer.suppressed;

import com.banamex.cops.app.model.CopSuppressionChannel;
import com.banamex.cops.app.model.CopSuppressionOperation;
import com.banamex.cops.app.service.CopSuppressionService;
import com.banamex.cops.update_offer.dto.suppression.StartRequestParams;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntitiesListRoot;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Provides the list of suppressed entities by reading it from the database (suppressed channels and operations tables).
 * The first call loads it and keeps it in memory; the following ones use that copy.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DbSuppressedEntitiesClient implements SuppressedEntitiesClient {

    /** Library service, obtained only when it is used. */
    private final ObjectProvider<CopSuppressionService> suppressionService;
    /** Builds the list from the database rows. */
    private final StartUpSuppressionLoader loader;

    /** Maximum time of the queries, in seconds. */
    @Value("${cop.suppression.query-timeout-seconds:30}")
    private int queryTimeoutSeconds = 30;

    /** Maximum rows of the queries; 0 = no limit. */
    @Value("${cop.suppression.max-rows:0}")
    private int maxRows = 0;

    /** Already built list, in memory. */
    private volatile SuppressedEntitiesListRoot cached;

    /**
     * Returns the list of suppressed entities; the first time it loads it from the database.
     * @param params request data (not used to filter)
     * @return list of suppressed entities
     */
    @Override
    public SuppressedEntitiesListRoot getListOfSuppressedEntities(StartRequestParams params) {
        SuppressedEntitiesListRoot list = cached;
        if (list == null) {
            synchronized (this) {
                list = cached;
                if (list == null) {
                    list = load();
                    cached = list;
                }
            }
        }
        return list;
    }

    /**
     * Reloads the list from the database and replaces the one in memory.
     * @return the newly loaded list
     */
    public synchronized SuppressedEntitiesListRoot reload() {
        SuppressedEntitiesListRoot list = load();
        cached = list;
        return list;
    }

    /**
     * Queries suppressed channels and operations and builds the list.
     * @return built list
     */
    private SuppressedEntitiesListRoot load() {
        CopSuppressionService service = suppressionService.orderedStream().findFirst().orElseThrow(() ->
                new IllegalStateException("CopSuppressionService no está disponible: revisa que exista "
                        + "OfferFulfillmentConfig (registra las consultas de la librería) y que haya un spring.datasource configurado"));
        List<CopSuppressionChannel> channels = service.findAllChannels(queryTimeoutSeconds, maxRows);
        List<CopSuppressionOperation> operations = service.findAllOperations(queryTimeoutSeconds, maxRows);
        SuppressedEntitiesListRoot list = loader.build(channels, operations);
        log.debug("startUpSuppression: {} entidades suprimidas cargadas", list.getSuppressedEntities().size());
        return list;
    }
}
