package com.banamex.cops.update_offer.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;
import java.util.TreeMap;

/** HTTP request headers used by the flow. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateOfferHeaders {
    /** Transaction identifier. */
    private String uuid;
    /** Origin host (optional). */
    private String host;
    /** Channel that invokes the operation. */
    private String channelId;
    /** 2-letter country code. */
    private String countryCode;
    /** Business code. */
    private String businessCode;
    /** Session identifier. */
    private String sid;
    /** Preferred language. */
    private String acceptLanguage;

    /** All the received headers, case-insensitive. */
    @Builder.Default
    private Map<String, String> all = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);

    /**
     * Value of the header with that name, ignoring case.
     * @param name header name
     * @return value, or {@code null} if it did not arrive
     */
    public String get(String name) {
        return name == null || all == null ? null : all.get(name);
    }
}
