package com.banamex.cops.update_offer.service.timeZoneValidation;

import com.banamex.cops.update_offer.dto.timeZoneValidation.DateGrpDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.DateTimeGrpDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.MapRequestResultDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TimeGrpDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TzFormatsDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.ValueItemDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.TemporalAccessor;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

/**
 * Validates and converts dates, times and date-times between the client zone and the backend (ECRM) zone.
 * With type {@code Request} it takes the client values to the backend; with {@code Response}, from the backend to the client.
 * An invalid value is marked with the {@code Invalid TimeZone} status.
 */
@Service
@RequiredArgsConstructor
public class TimeZoneMapRequest {

    /** Status of an invalid value. */
    private static final String INVALID = "Invalid TimeZone";

    /** Backend zone: a name like {@code America/Mexico_City} or an offset like {@code -06:00}. */
    @Value("${update-offer.timezone.ecrm-time-zone}")
    private String ecrmTimeZone;

    /** Source pattern used to read date-times when converting them. */
    @Value("${update-offer.timezone.time-zone-date-time-format}")
    private String timeZoneDateTimeFormat;

    /** Backend time format. */
    @Value("${update-offer.timezone.be-time-format:HH:mm:ss}")
    private String beTimeFormat;

    /** Backend date-time format. */
    @Value("${update-offer.timezone.be-date-time-format:yyyy-MM-dd HH:mm:ss}")
    private String beDateTimeFormat;

    /**
     * Validates and converts the received values.
     * @param type {@code Request} or {@code Response}; with any other value it returns an empty result
     * @param f time zone formats of the system
     * @param dates dates to convert
     * @param times times to convert
     * @param dateTimes date-times to convert
     * @return converted values or values marked as invalid
     */
    public MapRequestResultDTO map(String type, TzFormatsDTO f,
                                   List<ValueItemDTO> dates,
                                   List<ValueItemDTO> times,
                                   List<ValueItemDTO> dateTimes) {
        MapRequestResultDTO out = new MapRequestResultDTO();
        boolean request = "request".equalsIgnoreCase(type);
        boolean response = "response".equalsIgnoreCase(type);
        if (!request && !response) {
            return out;
        }

        for (ValueItemDTO d : nz(dates)) {
            DateGrpDTO g = mapDate(request, f, d);
            if (g != null) out.getDateGrp().add(g);
        }

        for (ValueItemDTO t : nz(times)) {
            String v = t.getValue();
            if (request) {
                if (invalid(f.getTimeZoneOffset(), f.getTimeFormat(), v)) {
                    out.getTimeGrp().add(new TimeGrpDTO(v, INVALID, null));
                } else if (hasText(v)) {
                    try {
                        out.getTimeGrp().add(new TimeGrpDTO(convertTimeRequest(f, v), "", t.getName()));
                    } catch (DateTimeException | IllegalArgumentException e) {
                        out.getTimeGrp().add(new TimeGrpDTO(v, INVALID, null));
                    }
                }
            } else if (hasText(v)) {
                out.getTimeGrp().add(new TimeGrpDTO(formatTimeResponse(f, v), "", t.getName()));
            }
        }

        for (ValueItemDTO dt : nz(dateTimes)) {
            String v = dt.getValue();
            if (request) {
                if (invalid(f.getTimeZoneOffset(), f.getDateTimeFormat(), v)) {
                    out.getDateTimeGrp().add(new DateTimeGrpDTO(v, INVALID, null));
                } else if (hasText(v)) {
                    try {
                        out.getDateTimeGrp().add(new DateTimeGrpDTO(convertDateTimeRequest(f, v), "", dt.getName()));
                    } catch (DateTimeException | IllegalArgumentException e) {
                        out.getDateTimeGrp().add(new DateTimeGrpDTO(v, INVALID, null));
                    }
                }
            } else if (hasText(v)) {
                out.getDateTimeGrp().add(new DateTimeGrpDTO(formatDateTimeResponse(f, v), "", dt.getName()));
            }
        }
        return out;
    }

    /**
     * Validates and converts a date.
     * @param request {@code true} if the type is {@code Request}
     * @param f formats
     * @param d date
     * @return converted date, or {@code null} if it has no value
     */
    private DateGrpDTO mapDate(boolean request, TzFormatsDTO f, ValueItemDTO d) {
        String v = d.getValue();
        if (request) {
            if (invalid(f.getTimeZoneOffset(), f.getDateFormat(), v)) {
                return new DateGrpDTO(v, INVALID, null);
            }
            if (hasText(v)) {
                return new DateGrpDTO(parseDate(f.getDateFormat(), v) + "T00:00:00" + tzOffset(), "", d.getName());
            }
            return null;
        }
        return hasText(v) ? new DateGrpDTO(formatDate(f.getDateFormat(), v), "", d.getName()) : null;
    }

    /**
     * Client time, read with its format, taken to the backend zone and written with the backend format.
     * @param f formats
     * @param v client time
     * @return converted time
     */
    private String convertTimeRequest(TzFormatsDTO f, String v) {
        ZoneId client = clientZone(f);
        LocalTime t = LocalTime.parse(v.trim(), DateTimeFormatter.ofPattern(f.getTimeFormat()));
        ZonedDateTime src = ZonedDateTime.of(LocalDate.now(client), t, client);
        return src.withZoneSameInstant(ecrmZone()).toLocalTime().format(DateTimeFormatter.ofPattern(beTimeFormat));
    }

    /**
     * Client date-time, taken to the backend zone and written with the backend format.
     * @param f formats
     * @param v client date-time
     * @return converted date-time
     */
    private String convertDateTimeRequest(TzFormatsDTO f, String v) {
        ZonedDateTime src = parseZoned(v.trim(), f.getDateTimeFormat(), clientZone(f));
        return src.withZoneSameInstant(ecrmZone()).format(DateTimeFormatter.ofPattern(beDateTimeFormat));
    }

    /**
     * Reads the text with the pattern; if it has no zone, it assumes the given one.
     * @param v text
     * @param pattern pattern
     * @param assumed assumed zone
     * @return zoned date-time
     */
    private ZonedDateTime parseZoned(String v, String pattern, ZoneId assumed) {
        DateTimeFormatter fm = DateTimeFormatter.ofPattern(pattern);
        try {
            TemporalAccessor ta = fm.parseBest(v, ZonedDateTime::from, OffsetDateTime::from, LocalDateTime::from);
            if (ta instanceof ZonedDateTime z) return z;
            if (ta instanceof OffsetDateTime o) return o.toZonedDateTime();
            return ((LocalDateTime) ta).atZone(assumed);
        } catch (DateTimeParseException e) {
            if (v.length() >= 3 && v.charAt(v.length() - 3) == ':') {
                return OffsetDateTime.parse(v).toZonedDateTime();
            }
            throw e;
        }
    }

    /**
     * Backend time (of today) taken to the client zone and written with its format.
     * @param f formats
     * @param timeVal backend time
     * @return converted time
     */
    private String formatTimeResponse(TzFormatsDTO f, String timeVal) {
        ZoneId ecrm = ecrmZone();
        ZonedDateTime src = ZonedDateTime.of(LocalDate.now(ecrm), parseBackendTime(timeVal), ecrm);
        return src.withZoneSameInstant(clientZone(f)).toLocalTime().format(DateTimeFormatter.ofPattern(f.getTimeFormat()));
    }

    /**
     * Reads the backend time with its format; if it does not match, it tries it as {@code HH:mm:ss}.
     * @param value time
     * @return parsed time
     */
    private LocalTime parseBackendTime(String value) {
        String v = value.trim();
        try {
            return LocalTime.parse(v, DateTimeFormatter.ofPattern(beTimeFormat));
        } catch (DateTimeException e) {
            return LocalTime.parse(v);
        }
    }

    /**
     * Backend date-time taken to the client format; if the time offset contains {@code :}, it is inserted in the value.
     * @param f formats
     * @param v backend date-time
     * @return converted date-time
     */
    private String formatDateTimeResponse(TzFormatsDTO f, String v) {
        String offset = f.getTimeZoneOffset();
        String dtvar;
        if (v.length() >= 3 && v.charAt(v.length() - 3) == ':') {
            dtvar = OffsetDateTime.parse(v.trim())
                    .atZoneSameInstant(clientZone(f))
                    .format(DateTimeFormatter.ofPattern(f.getDateTimeFormat()));
        } else {
            dtvar = convertedDateTime(v, f);
        }
        if (offset != null && offset.contains(":")) {
            int n = dtvar.length();
            return dtvar.substring(0, n - 2) + ":" + dtvar.substring(n - 2);
        }
        return dtvar;
    }

    /**
     * Interprets the value in the backend zone with the configured pattern and shows it in the client zone with its format.
     * @param v value
     * @param f formats
     * @return converted date-time
     */
    private String convertedDateTime(String v, TzFormatsDTO f) {
        try {
            SimpleDateFormat in = new SimpleDateFormat(timeZoneDateTimeFormat);
            in.setTimeZone(TimeZone.getTimeZone(ecrmTimeZone));
            Date d = in.parse(v);
            SimpleDateFormat out = new SimpleDateFormat(f.getDateTimeFormat());
            out.setTimeZone(TimeZone.getTimeZone(f.getTimeZone()));
            return out.format(d);
        } catch (Exception e) {
            throw new IllegalArgumentException("DateTime inválido: " + v, e);
        }
    }

    /**
     * Decides whether a value is invalid according to the client time offset and format.
     * @param offset offset from UTC
     * @param format expected format
     * @param value value
     * @return {@code true} if it is invalid
     */
    private boolean invalid(String offset, String format, String value) {
        if (isEmpty(offset)) return true;
        if (!hasText(value)) return false;
        return !validate(format, value);
    }

    /**
     * Checks that the value meets the format.
     * @param format expected format
     * @param value value
     * @return {@code true} if it meets it
     */
    private boolean validate(String format, String value) {
        try {
            SimpleDateFormat s = new SimpleDateFormat(format);
            s.setLenient(false);
            s.parse(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Reads a date with the client format and returns it in ISO format.
     * @param format client format
     * @param value date
     * @return ISO date
     */
    private String parseDate(String format, String value) {
        try {
            SimpleDateFormat s = new SimpleDateFormat(format);
            s.setLenient(false);
            return new SimpleDateFormat("yyyy-MM-dd").format(s.parse(value));
        } catch (Exception e) {
            throw new IllegalArgumentException("Fecha inválida: " + value, e);
        }
    }

    /**
     * Writes an ISO date with the client format.
     * @param format client format
     * @param isoValue ISO date
     * @return date with the client format
     */
    private String formatDate(String format, String isoValue) {
        LocalDateTime ldt;
        try {
            ldt = OffsetDateTime.parse(isoValue).toLocalDateTime();
        } catch (Exception e) {
            ldt = LocalDateTime.parse(isoValue);
        }
        return ldt.format(DateTimeFormatter.ofPattern(format));
    }

    /**
     * @return backend zone
     */
    private ZoneId ecrmZone() {
        return ZoneId.of(ecrmTimeZone);
    }

    /**
     * @return offset from UTC of the backend zone
     */
    private ZoneOffset ecrmOffset() {
        return ecrmZone().getRules().getOffset(Instant.now());
    }

    /**
     * Offset from UTC of the backend zone in {@code -0600} format, without a colon.
     * @return time offset
     */
    private String tzOffset() {
        ZoneOffset o = ecrmOffset();
        return o.getTotalSeconds() == 0 ? "+0000" : o.getId().replace(":", "");
    }

    /**
     * Client zone: its offset from UTC if present; otherwise the zone name.
     * @param f formats
     * @return client zone
     */
    private ZoneId clientZone(TzFormatsDTO f) {
        if (hasText(f.getTimeZoneOffset())) {
            return ZoneOffset.of(f.getTimeZoneOffset().trim());
        }
        if (hasText(f.getTimeZone())) {
            return ZoneId.of(f.getTimeZone().trim());
        }
        throw new IllegalArgumentException("No hay TimeZoneOffset ni TimeZone del cliente en la configuración");
    }

    /**
     * @param s text
     * @return {@code true} if it is neither null nor blank
     */
    private static boolean hasText(String s) { return s != null && !s.trim().isEmpty(); }
    /**
     * @param s text
     * @return {@code true} if it is null or empty
     */
    private static boolean isEmpty(String s) { return s == null || s.isEmpty(); }
    /**
     * @param l list
     * @param <T> element type
     * @return the list, or an empty one if it is null
     */
    private static <T> List<T> nz(List<T> l) { return l == null ? List.of() : l; }
}
