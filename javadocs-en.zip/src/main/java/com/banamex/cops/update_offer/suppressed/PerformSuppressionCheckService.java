package com.banamex.cops.update_offer.suppressed;

import com.banamex.cops.update_offer.dto.suppression.FilteredSuppressionList;
import com.banamex.cops.update_offer.dto.suppression.StartRequest;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntitiesListRoot;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Checks whether the operation is suppressed. With {@code cop.suppression.check-for-suppression=Y} it gets the list of
 * suppressed entities and filters it with the request data; with any other value it checks nothing.
 */
@Slf4j
@Service
public class PerformSuppressionCheckService {

    /** Provides the list of suppressed entities. */
    private final SuppressedEntitiesClient suppressedEntitiesClient;
    /** Filters the list with the request data. */
    private final SuppressionCheckService checkService;

    /**
     * Creates the service.
     * @param suppressedEntitiesClient client of the suppressed entities list
     * @param checkService list filter
     */
    public PerformSuppressionCheckService(@Qualifier("dbSuppressedEntitiesClient") SuppressedEntitiesClient suppressedEntitiesClient,
                                          SuppressionCheckService checkService) {
        this.suppressedEntitiesClient = suppressedEntitiesClient;
        this.checkService = checkService;
    }

    /** {@code Y} to check the suppression; any other value skips it. */
    @Value("${cop.suppression.check-for-suppression:N}")
    private String checkForSuppression;

    /**
     * Queries the list of suppressed entities and returns those that match the request.
     * If the check is disabled or an error occurs, it returns an empty result (the operation is not considered suppressed).
     * @param request channel, country and operation to check
     * @return matching entities; empty if it is not checked or the query fails
     */
    public FilteredSuppressionList perform(StartRequest request) {
        try {
            if ("Y".equals(checkForSuppression)) {
                SuppressedEntitiesListRoot suppressed =
                        suppressedEntitiesClient.getListOfSuppressedEntities(request.getRequestParams());
                return checkService.checkIfSuppressed(request, suppressed);
            }

            return empty();

        } catch (Exception ex) {
            log.error("Error en PerformSuppressionCheck", ex);
            return empty();
        }
    }

    /**
     * @return empty result, with no matching entities
     */
    private FilteredSuppressionList empty() {
        FilteredSuppressionList out = new FilteredSuppressionList();
        out.setResults(List.of());
        return out;
    }
}
