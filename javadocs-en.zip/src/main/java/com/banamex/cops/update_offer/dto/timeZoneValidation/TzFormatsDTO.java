package com.banamex.cops.update_offer.dto.timeZoneValidation;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Time zone formats of a system; they may be empty but not absent. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TzFormatsDTO {

    /** Offset from UTC, for example {@code -0600}. */
    @NotNull private String timeZoneOffset;
    /** Client date format. */
    @NotNull private String dateFormat;
    /** Client time format. */
    @NotNull private String timeFormat;
    /** Client date-time format. */
    @NotNull private String dateTimeFormat;
    /** Time zone name, for example {@code America/Mexico_City}. */
    @NotNull private String timeZone;
}
