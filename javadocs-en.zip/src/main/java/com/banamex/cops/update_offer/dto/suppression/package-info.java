/** Objects of the suppression check. */
package com.banamex.cops.update_offer.dto.suppression;
