package com.banamex.cops.update_offer.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Codes and texts of the response the microservice builds for each offer and of the event publication results
 * ({@code update-offer.response.*}). The texts accept the placeholders {@code {dateTime}}, {@code {step}},
 * {@code {detail}}, {@code {destination}}, {@code {offerKey}} and {@code {campaignId}}.
 */
@Data
@Component
@ConfigurationProperties(prefix = "update-offer.response")
public class UpdateOfferResponseProperties {

    /** Where the success response comes from: {@code micro} or {@code ems}. */
    private String source = "micro";

    /** Code when the offer was processed successfully. */
    private String successCode = "COP_UPDOF_0";

    /** Success text. */
    private String successText = "Successfully update offer {dateTime}";

    /** Code when something fails. */
    private String errorCode = "ERROR";

    /** Error text: the date and the step where it failed. */
    private String errorText = "Error update offer {dateTime}. Falló en {step}: {detail}";

    /** Date format ({@link java.time.format.DateTimeFormatter}). */
    private String dateFormat = "yyyy/MM/dd HH:mm:ss";

    /** If {@code true}, offers with {@code OfferStatus = "U"} answer with the offer key in the success text. */
    private boolean statusUBwFormat = true;

    /** Status {@code U}: code when the offer was processed. */
    private String statusUSuccessCode = "COP_UPDOF_0";

    /**
     * Status {@code U}: success text; {@code {offerKey}} is the key {@code off:mx:campaign_wave_customer[_account][_card]}.
     */
    private String statusUSuccessText = "Successfully update offer {offerKey}";

    /** Status {@code U}: code when the request has no {@code campaignId}. */
    private String statusUCampaignMissingCode = "COP_UPDOF_432";

    /** Status {@code U}: text when {@code campaignId} is missing; {@code {campaignId}} is the received value. */
    private String statusUCampaignMissingText = "Campaign cmp: {campaignId} is not present cannot proceed with the Update Offer";

    /** Log text when the event was published. */
    private String kafkaSuccessText = "Successfully send offer to {destination} {dateTime}";

    /** Log text when the event has no active destination. */
    private String kafkaDisabledText = "Envío del evento desactivado: no hay destino activo {dateTime}";

    /** Log text when the destination is in dry-run and nothing is published. */
    private String kafkaDryRunText = "{destination} en dry-run: el mensaje no se publicó {dateTime}";

    /** Log text when the event could not be sent: the date and where it failed. */
    private String kafkaErrorText = "Error send offer to {destination} {dateTime}. Falló en {step}: {detail}";
}
