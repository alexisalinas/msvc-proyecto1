package com.banamex.cops.update_offer.service;

import com.banamex.cops.update_offer.dto.UpdateOfferHeaders;
import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;

import java.util.List;

/** Contract of the service that handles the offer update. */
public interface UpdateOfferService {

    /**
     * Processes the offers of the request, one by one.
     * @param requests offers received in the body
     * @param headers request headers
     * @return one response per offer, in the same order
     */
    List<UpdateOfferResponse> updateOffer(List<UpdateOfferRequest> requests, UpdateOfferHeaders headers);
}
