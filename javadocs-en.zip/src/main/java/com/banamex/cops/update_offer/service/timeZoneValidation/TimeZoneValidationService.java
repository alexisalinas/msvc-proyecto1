package com.banamex.cops.update_offer.service.timeZoneValidation;

import com.banamex.cops.update_offer.dto.timeZoneValidation.MapRequestResultDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TimeZoneValidationResult;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TimeZoneValidationStartDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TzFormatsDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TzLookUpDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.ValueItemDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Validates the time zone of a request. It looks for the system formats in the cache; if they are not there, it queries
 * the database and stores them in the cache; then it converts the dates and times ({@link TimeZoneMapRequest}).
 * The cache is not cleared while the microservice is up and it does not store systems without configuration.
 */
@Service
@RequiredArgsConstructor
public class TimeZoneValidationService {

    /** Code when the validation succeeded. */
    public static final String OK = "COP_TZCOD_000";
    /** Code when the system, mode and type have no time zone configured. */
    public static final String NOT_CONFIGURED = "COP_TZCOD_114";
    /** Status of an invalid value. */
    private static final String INVALID_STATUS = "Invalid TimeZone";

    /** Looks up the formats in a list of configurations. */
    private final InitTZ initTZ;
    /** Queries the configuration in the database. */
    private final TimeZoneLookupClient lookupClient;
    /** Converts the dates and times. */
    private final TimeZoneMapRequest mapRequest;

    /** Code when any value is invalid. */
    @Value("${update-offer.timezone.invalid-code:COP_TZCOD_115}")
    private String invalidCode;

    /** In-memory cache of the configurations already queried. */
    private final List<TzLookUpDTO> cache = new CopyOnWriteArrayList<>();

    /**
     * Same as the other form of {@code validate}, receiving the complete input data.
     * @param start system, mode, type and values to convert
     * @return validation result
     */
    public TimeZoneValidationResult validate(TimeZoneValidationStartDTO start) {
        return validate(start.getSystem(), start.getSysMode(), start.getType(),
                start.getDate(), start.getTime(), start.getDateTime());
    }

    /**
     * Validates the time zone: it gets or loads the system formats (with cache) and converts the dates and times.
     * It returns {@link #OK} if everything is valid, {@link #NOT_CONFIGURED} if there is no configuration, or the invalid
     * value code if any value does not meet the format.
     * @param system system or channel
     * @param sysMode system mode
     * @param type {@code Request} or {@code Response}
     * @param dates dates to convert
     * @param times times to convert
     * @param dateTimes date-times to convert
     * @return validation result
     */
    public TimeZoneValidationResult validate(String system, String sysMode, String type,
                                             List<ValueItemDTO> dates, List<ValueItemDTO> times,
                                             List<ValueItemDTO> dateTimes) {
        Optional<TzFormatsDTO> formats = initTZ.execute(system, sysMode, type, cache);

        if (formats.isEmpty()) {
            List<TzLookUpDTO> found = lookupClient.find(system, sysMode, type);
            if (found != null && !found.isEmpty()) {
                cache.addAll(found);
                formats = initTZ.execute(system, sysMode, type, found);
            }
        }

        if (formats.isEmpty()) {
            return result(NOT_CONFIGURED, "TimeZone not configured", emptyFormats(), new MapRequestResultDTO());
        }

        MapRequestResultDTO map = mapRequest.map(type, formats.get(), dates, times, dateTimes);
        boolean invalid = map.getDateGrp().stream().anyMatch(g -> INVALID_STATUS.equals(g.getDateStatus()))
                || map.getTimeGrp().stream().anyMatch(g -> INVALID_STATUS.equals(g.getTimeStatus()))
                || map.getDateTimeGrp().stream().anyMatch(g -> INVALID_STATUS.equals(g.getDateTimeStatus()));

        return result(invalid ? invalidCode : OK, invalid ? INVALID_STATUS : "Success", formats.get(), map);
    }

    /**
     * Formats without configuration: the five fields are mandatory, so they are empty rather than null.
     * @return empty formats
     */
    private TzFormatsDTO emptyFormats() {
        TzFormatsDTO f = new TzFormatsDTO();
        f.setTimeZoneOffset("");
        f.setDateFormat("");
        f.setTimeFormat("");
        f.setDateTimeFormat("");
        f.setTimeZone("");
        return f;
    }

    /**
     * Builds the validation result.
     * @param code code
     * @param text text
     * @param formats formats
     * @param map converted values
     * @return result
     */
    private TimeZoneValidationResult result(String code, String text, TzFormatsDTO formats, MapRequestResultDTO map) {
        TimeZoneValidationResult r = new TimeZoneValidationResult();
        r.setResponseCode(code);
        r.setResponseText(text);
        r.setFormats(formats);
        r.setMapResult(map);
        return r;
    }
}
