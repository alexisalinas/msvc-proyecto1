package com.banamex.cops.update_offer.dto.timeZoneValidation;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Converted or invalid time of the time zone validation. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TimeGrpDTO {

    /** Resulting time. */
    @NotNull private String time;
    /** Empty if everything is fine; {@code Invalid TimeZone} if the time is invalid. */
    @NotNull private String timeStatus;

    /** Name that identifies the time. */
    private String timeName;
}
