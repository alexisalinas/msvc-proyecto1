package com.banamex.cops.update_offer.kafka;

import com.banamex.cops.update_offer.mapper.XmlUtil;
import jakarta.jms.DeliveryMode;
import jakarta.jms.MessageProducer;
import jakarta.jms.TextMessage;
import org.springframework.jms.core.JmsTemplate;

import java.util.function.Supplier;

/** Leaves the event in a JMS queue: the one of the Kafka bridge or the one of the alternate EMS. */
public class JmsOfferPublisher implements OfferPublisher {

    /** JMS template supplier. */
    private final Supplier<JmsTemplate> jms;
    /** Target queue. */
    private final String queue;
    /** Message format: {@code json} or {@code envelope}. */
    private final String messageFormat;
    /** Message time to live in milliseconds; 0 = it does not expire. */
    private final long timeToLiveMs;

    /**
     * Creates the publisher. The template is requested when publishing, so the connection is only created if the destination is used.
     * @param jms JMS template supplier
     * @param queue target queue
     * @param messageFormat message format
     * @param timeToLiveMs time to live in milliseconds
     */
    public JmsOfferPublisher(Supplier<JmsTemplate> jms, String queue, String messageFormat, long timeToLiveMs) {
        this.jms = jms;
        this.queue = queue;
        this.messageFormat = messageFormat;
        this.timeToLiveMs = timeToLiveMs;
    }

    /**
     * Sends the JSON as is, or inside {@code <root><RefId/><jsonString/></root>} with the {@code envelope} format.
     * @param refId event reference
     * @param json serialized event
     * @return result of the publication
     * @throws Exception if the publication fails
     */
    @Override
    public String publish(String refId, String json) throws Exception {
        if (queue == null || queue.isBlank()) {
            throw new IllegalStateException("no hay cola configurada para este destino");
        }
        String body = "envelope".equalsIgnoreCase(messageFormat)
                ? "<root><RefId>" + XmlUtil.esc(refId) + "</RefId><jsonString>" + XmlUtil.esc(json) + "</jsonString></root>"
                : json;
        return jms.get().execute(session -> {
            try (MessageProducer producer = session.createProducer(session.createQueue(queue))) {
                TextMessage message = session.createTextMessage(body);
                message.setJMSCorrelationID(refId);
                message.setStringProperty("RefId", refId);
                producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
                if (timeToLiveMs > 0) {
                    producer.setTimeToLive(timeToLiveMs);
                }
                producer.send(message);
                return message.getJMSMessageID();
            }
        }, true);
    }
}
