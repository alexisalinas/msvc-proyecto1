package com.banamex.cops.update_offer.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/** Response of an offer. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UpdateOfferResponse {

    /** Return code. */
    @NotNull(message = "El campo code es obligatorio")
    private String code;

    /** Description of the operation. */
    @NotNull(message = "El campo description es obligatorio")
    private String description;

    /** Customer contact reference. */
    private String customerReferenceNumber;

    /** Start date. */
    private String startDate;

    /** End date. */
    private String endDate;

    /** Survey mode. */
    private String surveyModeCode;

    /** Control fields. */
    @Valid
    private List<ControlFieldDTO> contextType;
}