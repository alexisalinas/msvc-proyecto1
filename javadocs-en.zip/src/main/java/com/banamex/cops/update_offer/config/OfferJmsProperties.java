package com.banamex.cops.update_offer.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/** Padding of the customer number sent to the EMS ({@code update-offer.jms-requestor.*}). */
@Data
@Component
@ConfigurationProperties(prefix = "update-offer.jms-requestor")
public class OfferJmsProperties {

    /** If {@code true}, the customer number is padded on the left. */
    private boolean customerPadding;
    /** Final length of the customer number. */
    private int customerPaddingLength = 19;
    /** Padding character. */
    private char customerPaddingChar = '0';
}
