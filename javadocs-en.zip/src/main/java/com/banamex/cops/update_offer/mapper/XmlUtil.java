package com.banamex.cops.update_offer.mapper;

/** Utilities to write XML by hand. */
public final class XmlUtil {

    /** It is not instantiated. */
    private XmlUtil() { }

    /**
     * Escapes the special XML characters so the text can be used inside an element.
     * @param s text
     * @return escaped text
     */
    public static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&apos;");
    }

    /**
     * Writes {@code <name>value</name>}.
     * @param x target
     * @param indent indentation
     * @param name element name
     * @param value value
     */
    static void tag(StringBuilder x, String indent, String name, String value) {
        if (value == null) return;
        x.append(indent).append('<').append(name).append('>').append(esc(value))
                .append("</").append(name).append(">\n");
    }

    /**
     * Same as {@code tag}, but a null or empty value is written as {@code <name/>}.
     * @param x target
     * @param indent indentation
     * @param name element name
     * @param value value
     */
    static void tagOrEmpty(StringBuilder x, String indent, String name, String value) {
        if (value == null || value.isEmpty()) {
            x.append(indent).append('<').append(name).append("/>\n");
        } else {
            tag(x, indent, name, value);
        }
    }
}
