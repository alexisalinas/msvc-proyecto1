package com.banamex.cops.update_offer.kafka;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Configuration of the alternate destination of the event: a queue in another EMS ({@code offer.alternate-ems.*}).
 */
@Data
@Component
@ConfigurationProperties(prefix = "offer.alternate-ems")
public class AlternateEmsProps {

    /** If {@code true}, the event is also published to this destination. */
    private boolean enabled = false;

    /** Name of the {@code JmsTemplate} bean of the alternate EMS connection. */
    private String jmsTemplateName = "alternateEmsJmsTemplate";

    /** Alternate EMS queue. */
    private String queue;

    /** Message format: {@code json} or {@code envelope}. */
    private String messageFormat = "json";

    /** Message time to live in milliseconds; 0 = it does not expire. */
    private long timeToLiveMs = 0;
}
