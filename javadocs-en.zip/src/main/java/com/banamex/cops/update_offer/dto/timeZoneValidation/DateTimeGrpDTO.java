package com.banamex.cops.update_offer.dto.timeZoneValidation;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Converted or invalid date-time of the time zone validation. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DateTimeGrpDTO {

    /** Resulting date-time. */
    @NotNull private String dateTime;
    /** Empty if everything is fine; {@code Invalid TimeZone} if it is invalid. */
    @NotNull private String dateTimeStatus;

    /** Name that identifies the date-time. */
    private String dateTimeName;
}
