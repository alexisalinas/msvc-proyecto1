/** Objects of the REST request and response. */
package com.banamex.cops.update_offer.dto;
