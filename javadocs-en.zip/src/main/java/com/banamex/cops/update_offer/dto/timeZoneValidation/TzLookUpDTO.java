package com.banamex.cops.update_offer.dto.timeZoneValidation;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** A time zone configuration record from the database. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TzLookUpDTO {

    /** System or channel. */
    @NotNull private String systemName;
    /** System mode. */
    @NotNull private String mode;
    /** Time zone name. */
    @NotNull private String timeZone;
    /** Type ({@code Request} or {@code Response}). */
    @NotNull private String type;
    /** Offset from UTC. */
    @NotNull private String timeOffset;
    /** Date format. */
    @NotNull private String dateFormat;
    /** Time format. */
    @NotNull private String timeFormat;
    /** Date-time format. */
    @NotNull private String dateTimeFormat;
}
