package com.banamex.cops.update_offer.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Configuration;

/**
 * Registers the JPA entities of the microservice and of the database library to avoid the {@code Not a managed type} error.
 */
@Configuration
@EntityScan(basePackages = {"com.banamex.cops.update_offer", "com.banamex.cops.app"})
public class EntityScanConfig {
}
