package com.banamex.cops.update_offer.kafka;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * Builds the offer key, the wave key and the event reference from the unmodified values, as they arrive in the request.
 */
@Component
@RequiredArgsConstructor
public class OfferKeyBuilder {

    /** Configured prefixes and separator. */
    private final OfferKafkaProps props;

    /**
     * Offer key for the query ({@code D_OFFERPALETTE.EXTID$}): {@code off:mx:campaign:wave:customer[:account]}.
     * @param campaignId campaign
     * @param waveId wave
     * @param customerNo customer
     * @param accountNo account, optional
     * @return offer key
     */
    public String offerKey(String campaignId, String waveId, String customerNo, String accountNo) {
        return props.getOfferPrefix() + join(props.getKeySeparator(), campaignId, waveId, customerNo, accountNo, null);
    }

    /**
     * Event reference: {@code campaign_wave_customer}, and with {@code _account_card} only if both are present.
     * @param campaignId campaign
     * @param waveId wave
     * @param customerNo customer
     * @param accountNo account, optional
     * @param cardNumber card, optional
     * @return event reference
     */
    public String refId(String campaignId, String waveId, String customerNo, String accountNo, String cardNumber) {
        boolean cuentaYTarjeta = hasText(accountNo) && hasText(cardNumber);
        return cuentaYTarjeta
                ? join("_", campaignId, waveId, customerNo, accountNo, cardNumber)
                : join("_", campaignId, waveId, customerNo, null, null);
    }

    /**
     * @param s text
     * @return {@code true} if it is neither null nor blank
     */
    private static boolean hasText(String s) {
        return s != null && !s.isBlank();
    }

    /**
     * Wave key with its channel ({@code D_WAVECHINFO.EXTID$}): {@code wvch:wave:channel}.
     * @param waveId wave
     * @param channel channel
     * @return wave key
     */
    public String waveKey(String waveId, String channel) {
        return props.getWavePrefix() + waveId + props.getKeySeparator() + channel;
    }

    /**
     * Always joins campaign, wave and customer; account and card only if they have a value.
     * @param sep separator
     * @param campaignId campaign
     * @param waveId wave
     * @param customerNo customer
     * @param accountNo account
     * @param cardNumber card
     * @return joined parts
     */
    private static String join(String sep, String campaignId, String waveId, String customerNo,
                               String accountNo, String cardNumber) {
        StringBuilder sb = new StringBuilder();
        sb.append(campaignId).append(sep).append(waveId).append(sep).append(customerNo);
        if (!isBlank(accountNo)) sb.append(sep).append(accountNo);
        if (!isBlank(cardNumber)) sb.append(sep).append(cardNumber);
        return sb.toString();
    }

    /**
     * @param s text
     * @return {@code true} if it is null or blank
     */
    private static boolean isBlank(String s) { return s == null || s.isBlank(); }
}
