package com.banamex.cops.update_offer.kafka;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.ThreadPoolExecutor;

/**
 * Configures the executor of the event publication, with a bounded queue: if it fills up, tasks are rejected (and counted) instead of piling up without limit.
 */
@Configuration
public class KafkaExecutorConfig {

    /**
     * Creates the executor where {@link com.banamex.cops.update_offer.sender.OfferFulfillmentEmsSender} runs.
     * @param props sizes of the executor and its queue
     * @return configured executor
     */
    @Bean(name = "offerFulfillmentExecutor")
    public ThreadPoolTaskExecutor offerFulfillmentExecutor(OfferKafkaProps props) {
        ThreadPoolTaskExecutor e = new ThreadPoolTaskExecutor();
        e.setThreadNamePrefix("offer-fulfillment-");
        e.setCorePoolSize(props.getExecutorCoreSize());
        e.setMaxPoolSize(props.getExecutorMaxSize());
        e.setQueueCapacity(props.getExecutorQueueCapacity());
        e.setRejectedExecutionHandler(new ThreadPoolExecutor.AbortPolicy());
        e.setWaitForTasksToCompleteOnShutdown(true);
        e.setAwaitTerminationSeconds(5);
        return e;
    }
}
