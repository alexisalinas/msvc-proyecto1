package com.banamex.cops.update_offer.kafka;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Input event of the fulfillment publication: what the microservice already knows about the offer before querying the database.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OfferInput {

    /** Transaction identifier ({@code uuid} header). */
    private String uuid;
    /** ESB identifier generated for the event. */
    private String esbUuid;
    /** Channel that invoked the operation. */
    private String channel;
    /** Time when the offer started to be processed. */
    private String transactionTime;

    /** Event reference: {@code campaign_wave_customer[_account_card]}. */
    private String refId;
    /** Offer key in the database: {@code off:mx:campaign:wave:customer[:account]}. */
    private String offerKey;
    /** Campaign. */
    private String campaignId;
    /** Wave. */
    private String waveId;
    /** Customer number. */
    private String customerNo;
    /** Account number. */
    private String accountNo;
    /** Card number. */
    private String cardNumber;
    /** Offer status. */
    private String offerStatus;
    /** Offer action. */
    private String actionId;
    /** Time of the EMS reply. */
    private String responseTime;
    /** Code of the EMS reply. */
    private String responseCode;
    /** Text of the EMS reply. */
    private String responseText;
}
