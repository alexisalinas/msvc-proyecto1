package com.banamex.cops.update_offer.suppressed;

import com.banamex.cops.update_offer.dto.suppression.FilteredSuppressionList;
import com.banamex.cops.update_offer.dto.suppression.FilteredSuppressionResult;
import com.banamex.cops.update_offer.dto.suppression.OperationDetailOutput;
import com.banamex.cops.update_offer.dto.suppression.StartRequest;
import com.banamex.cops.update_offer.dto.suppression.StartRequestParams;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntitiesListRoot;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntityDTO;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Filters the list of suppressed entities with the request data.
 * An entity matches if it belongs to the channel and country of the request, with suppression flag {@code Y}, mode
 * {@code RT} and source system {@code ECRM}. Inside it, the operation is suppressed if its name is contained in the
 * current operation name, the channel matches and its flag is {@code Y}; the result is then {@code COP_OPSUP_001}.
 */
@Service
public class SuppressionCheckService {

    /**
     * Returns the suppressed entities that match the request.
     * @param request channel, country and operation to check
     * @param suppressed list of suppressed entities
     * @return matching entities, with the suppressed operations
     */
    public FilteredSuppressionList checkIfSuppressed(StartRequest request,
                                                     SuppressedEntitiesListRoot suppressed) {
        StartRequestParams p = request.getRequestParams();

        List<FilteredSuppressionResult> results = suppressed.getSuppressedEntities().stream()
                .filter(e -> p.getRequestingChannel() != null
                        && p.getRequestingChannel().equals(e.getChannelId()))
                .filter(e -> p.getCountryCode().equals(e.getCountryCode())
                        && "Y".equals(e.getSuppressionFlag())
                        && "RT".equals(e.getMode())
                        && "ECRM".equals(e.getSourceSystem()))
                .map(e -> toResult(e, p))
                .toList();

        FilteredSuppressionList out = new FilteredSuppressionList();
        out.setResults(results);
        return out;
    }

    /**
     * Converts an entity into a result, keeping only the suppressed operations with their response code and text.
     * @param e entity
     * @param p request data
     * @return result
     */
    private FilteredSuppressionResult toResult(SuppressedEntityDTO e, StartRequestParams p) {
        FilteredSuppressionResult r = new FilteredSuppressionResult();
        r.setCountryCode(e.getCountryCode());
        r.setChannelID(e.getChannelId());
        r.setSuppressionFlag(e.getSuppressionFlag());
        r.setOperationFlag(e.getOperationFlag());
        r.setMode(e.getMode());
        r.setSourceSystem(e.getSourceSystem());

        List<OperationDetailOutput> details = e.getOperationDetails().stream()
                .filter(d -> p.getCurrentOperationName().contains(d.getOperationName()))
                .filter(d -> p.getRequestingChannel().equals(d.getReqChannel())
                        && "Y".equals(d.getOperationFlag()))
                .map(d -> {
                    OperationDetailOutput o = new OperationDetailOutput();
                    o.setOperationName(d.getOperationName());
                    o.setReqChannel(d.getReqChannel());
                    o.setOperationFlag(d.getOperationFlag());
                    o.setCountryCode(p.getCountryCode());
                    o.setIndicator("true");
                    o.setResponseCode("COP_OPSUP_001");
                    o.setResponseText("The " + d.getOperationName()
                            + " operation is temporarily unavailable");
                    return o;
                })
                .toList();

        r.setOperationDetails(details);
        return r;
    }
}
