package com.banamex.cops.update_offer.config;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import org.springframework.jms.core.JmsTemplate;

import com.citibanamex.messaging.connector.config.jms.JmsProperties;
import com.citibanamex.messaging.connector.ems.config.EmsConnectionFactory;
import com.citibanamex.messaging.connector.ems.config.EmsJmsTemplate;
import com.citibanamex.messaging.connector.ems.service.IdentityService;
import com.citibanamex.messaging.connector.ems.service.impl.IdentityServiceImpl;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.json.JsonMapper;

import jakarta.jms.ConnectionFactory;
import jakarta.jms.JMSException;
import lombok.extern.slf4j.Slf4j;

/** JMS connection configuration: the main EMS where the update is sent and the alternate EMS of the event. */
@Configuration
@Slf4j
public class JmsConfig {

    /**
     * Shared JSON mapper.
     * @return JSON mapper
     */
    @Bean("jsonMapper")
    public JsonMapper jsonMapper() {
        return JsonMapper.builder().findAndAddModules().disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS).build();
    }

    /**
     * JMS connection properties from the yml ({@code digital-integration.messaging.jms}).
     * @return JMS properties
     */
    @Bean("jmsProperties")
    @ConfigurationProperties(prefix = "digital-integration.messaging.jms")
    public JmsProperties jmsProperties() {
        return new JmsProperties();
    }

    /**
     * Identity service used for the EMS credentials.
     * @return identity service
     */
    @Bean("localOrRemoteIdentityService")
    @Primary
    public IdentityService localOrRemoteIdentityService() {
        IdentityService remote = new IdentityServiceImpl(10);
        return location -> {
            if (location.startsWith("http://") || location.startsWith("https://")) {
                return remote.getIdentity(location);
            }
            try {
                return Files.readAllBytes(Path.of(location));
            } catch (IOException e) {
                throw new UncheckedIOException("No se pudo leer la identidad: " + location, e);
            }
        };
    }

    /**
     * EMS connection factory.
     * @param identityService identity service
     * @return connection factory
     */
    @Bean("emsConnectionFactoryBean")
    public EmsConnectionFactory emsConnectionFactoryBean(IdentityService identityService) {
        return new EmsConnectionFactory(identityService);
    }

    /**
     * Base JMS template of the EMS.
     * @return JMS template
     */
    @Bean("emsJmsTemplateBean")
    public EmsJmsTemplate emsJmsTemplateBean() {
        return new EmsJmsTemplate();
    }

    /**
     * Connection to the main EMS.
     * @return connection factory of the main EMS
     */
    @Bean("updateOfferConnectionFactory")
    public ConnectionFactory updateOfferConnectionFactory(
            @Qualifier("emsConnectionFactoryBean") EmsConnectionFactory emsConnectionFactory,
            JmsProperties props) throws JMSException {
        JmsProperties.JmsConnection connection =
                props.getPlatforms().get(0).getConnections().get(0);
        log.info("Creando ConnectionFactory EMS: id={}, brokerUrl={}",
                connection.getId(), connection.getBrokerUrl());
        return emsConnectionFactory.createInstance(connection);
    }

    /**
     * JMS template of the main EMS, used by {@link com.banamex.cops.update_offer.sender.EmsSender}.
     * @return JMS template
     */
    @Bean("updateOfferJmsTemplate")
    public JmsTemplate updateOfferJmsTemplate(
            @Qualifier("updateOfferConnectionFactory") ConnectionFactory connectionFactory,
            @Qualifier("emsJmsTemplateBean") EmsJmsTemplate emsJmsTemplate,
            @Value("${update-offer.ems.timeout-seconds:30}") long timeoutSeconds) {
        return emsJmsTemplate.createInstance(connectionFactory, timeoutSeconds * 1000);
    }

    /**
     * Connection to the alternate EMS: the one in the yml whose {@code jmsTemplateName} is {@code offer.alternate-ems.jms-template-name}. It only exists if the destination is enabled and it is created on the first send.
     * @return connection factory of the alternate EMS
     */
    @Lazy
    @Bean("alternateEmsConnectionFactory")
    @ConditionalOnProperty(name = "offer.alternate-ems.enabled", havingValue = "true")
    public ConnectionFactory alternateEmsConnectionFactory(
            @Qualifier("emsConnectionFactoryBean") EmsConnectionFactory emsConnectionFactory,
            JmsProperties props,
            @Value("${offer.alternate-ems.jms-template-name:alternateEmsJmsTemplate}") String templateName) throws JMSException {
        JmsProperties.JmsConnection connection = props.getPlatforms().stream()
                .flatMap(platform -> platform.getConnections().stream())
                .filter(c -> templateName.equals(c.getJmsTemplateName()))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException(
                        "No hay conexión con jmsTemplateName=" + templateName + " en digital-integration.messaging.jms.platforms"));
        log.info("Creando ConnectionFactory EMS alterno: id={}, brokerUrl={}",
                connection.getId(), connection.getBrokerUrl());
        return emsConnectionFactory.createInstance(connection);
    }

    /**
     * JMS template of the alternate EMS; it is created on the first send.
     * @return JMS template
     */
    @Lazy
    @Bean("alternateEmsJmsTemplate")
    @ConditionalOnProperty(name = "offer.alternate-ems.enabled", havingValue = "true")
    public JmsTemplate alternateEmsJmsTemplate(
            @Qualifier("alternateEmsConnectionFactory") ConnectionFactory connectionFactory,
            @Qualifier("emsJmsTemplateBean") EmsJmsTemplate emsJmsTemplate,
            @Value("${update-offer.ems.timeout-seconds:30}") long timeoutSeconds) {
        return emsJmsTemplate.createInstance(connectionFactory, timeoutSeconds * 1000);
    }

}
