package com.banamex.cops.update_offer.dto.timeZoneValidation;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Converted or invalid date of the time zone validation. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DateGrpDTO {

    /** Resulting date. */
    @NotNull private String date;
    /** Empty if everything is fine; {@code Invalid TimeZone} if the date is invalid. */
    @NotNull private String dateStatus;

    /** Name that identifies the date. */
    private String dateName;
}
