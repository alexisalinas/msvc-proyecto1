package com.banamex.cops.update_offer.mapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Reads the {@code userText} JSON and returns the fields {@code UserField1} to {@code UserField100}. */
@Slf4j
@Component
@RequiredArgsConstructor
public class UserTextParser {

    /** Name of a user field: {@code userfield} followed by 1 to 3 digits, ignoring case. */
    private static final Pattern USER_FIELD = Pattern.compile("(?i)^userfield(\\d{1,3})$");

    /** Reads the JSON. */
    private final ObjectMapper jsonMapper;

    /**
     * Converts the {@code userText} JSON into the user fields.
     * @param userText JSON received in the offer
     * @return map of field number (1 to 100) to value; empty if there is none or it cannot be read
     */
    public Map<Integer, String> parse(String userText) {
        Map<Integer, String> out = new TreeMap<>();
        if (userText == null || userText.isBlank()) return out;
        try {
            JsonNode root = jsonMapper.readTree(userText);
            if (root.isArray()) root.forEach(n -> collect(n, out)); else collect(root, out);
        } catch (Exception e) {
            log.warn("userText no es un JSON válido; se ignoran los UserFields: {}", e.getMessage());
        }
        return out;
    }

    /**
     * Walks the JSON and takes the {@code UserFieldN} fields.
     * @param n current node
     * @param out fields found
     */
    private void collect(JsonNode n, Map<Integer, String> out) {
        if (n.hasNonNull("parameterName")) {
            add(out, n.get("parameterName").asText(), n.path("parameterValue").asText(""));
            return;
        }
        for (java.util.Iterator<String> it = n.fieldNames(); it.hasNext(); ) {
            String key = it.next();
            add(out, key, n.get(key).asText(""));
        }
    }

    /**
     * Stores the field if its name is valid and the number is between 1 and 100.
     * @param out fields found
     * @param name field name
     * @param value value
     */
    private void add(Map<Integer, String> out, String name, String value) {
        Matcher m = USER_FIELD.matcher(name == null ? "" : name.trim());
        if (m.matches()) {
            int i = Integer.parseInt(m.group(1));
            if (i >= 1 && i <= 100) out.put(i, value);
        }
    }
}
