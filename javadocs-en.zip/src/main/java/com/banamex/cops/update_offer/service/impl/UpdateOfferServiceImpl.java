package com.banamex.cops.update_offer.service.impl;

import com.banamex.cops.update_offer.audit.AuditLogService;
import com.banamex.cops.update_offer.dto.UpdateOfferHeaders;
import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import com.banamex.cops.update_offer.dto.suppression.FilteredSuppressionList;
import com.banamex.cops.update_offer.dto.suppression.StartRequest;
import com.banamex.cops.update_offer.dto.suppression.StartRequestParams;
import com.banamex.cops.update_offer.dto.timeZoneValidation.MapRequestResultDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TimeZoneValidationResult;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TimeZoneValidationStartDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.ValueItemDTO;
import com.banamex.cops.update_offer.kafka.KafkaSenderDashboard;
import com.banamex.cops.update_offer.mapper.UpdateOfferMapper;
import com.banamex.cops.update_offer.sender.EmsSender;
import com.banamex.cops.update_offer.sender.OfferFulfillmentEmsSender;
import com.banamex.cops.update_offer.service.UpdateOfferResponseFactory;
import com.banamex.cops.update_offer.service.UpdateOfferService;
import com.banamex.cops.update_offer.service.timeZoneValidation.TimeZoneValidationService;
import com.banamex.cops.update_offer.service.timeZoneValidation.UpdateOfferFlowConditions;
import com.banamex.cops.update_offer.suppressed.PerformSuppressionCheckService;
import com.banamex.cops.update_offer.validation.DtoValidator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Update flow of one offer. For each offer of the request:
 * <ol>
 * <li>If {@code update-offer.timezone.translate-time-zone} is {@code true}, it validates and converts the date and the
 * times of the appointment to the backend zone ({@link TimeZoneValidationService}). If the resulting code does not
 * allow continuing, it answers with that code.</li>
 * <li>It checks the suppression of the operation for the channel and country ({@link PerformSuppressionCheckService}).
 * If it is suppressed, it answers with the suppression code.</li>
 * <li>It builds the XML and the message properties ({@link UpdateOfferMapper}) and sends them to the EMS, waiting for
 * its reply ({@link EmsSender}).</li>
 * <li>It queues the fulfillment event of the offer ({@link OfferFulfillmentEmsSender}); it does not block the
 * response.</li>
 * <li>It builds the response of the offer ({@link UpdateOfferResponseFactory}).</li>
 * </ol>
 * If a step fails, the offer answers with the error code and the name of the step; the other offers continue.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class UpdateOfferServiceImpl implements UpdateOfferService {

    /** Name of the operation searched in the suppression list. */
    private static final String OPERATION_NAME = "UpdateOffer";

    /** Header that provides {@code UpdatedBy} in the message to the EMS. */
    private static final String CLIENT_ID_HEADER = "client_id";

    /** Sends the message to the EMS and waits for the reply. */
    private final EmsSender emsSender;
    /** Converts the offer into the EMS XML and properties, and the EMS reply into a REST response. */
    private final UpdateOfferMapper updateOfferMapper;
    /** Writes the received request and the final response to the log. */
    private final AuditLogService auditLogService;
    /** Checks whether the operation is suppressed for the channel and country. */
    private final PerformSuppressionCheckService suppressionCheckService;
    /** Validates and converts dates and times between the client zone and the backend zone. */
    private final TimeZoneValidationService timeZoneValidationService;
    /** Builds the input event of the fulfillment publication. */
    private final KafkaSenderDashboard kafkaSenderDashboard;
    /** Publishes the fulfillment event of the offer to the active destinations. */
    private final OfferFulfillmentEmsSender offerFulfillmentEmsSender;
    /** Validates the rules of the internal DTOs before using them. */
    private final DtoValidator dtoValidator;
    /** Builds the success and error responses of each offer. */
    private final UpdateOfferResponseFactory responses;

    /** If {@code true}, the time zone is validated and converted before continuing. */
    @Value("${update-offer.timezone.translate-time-zone:true}")
    private boolean translateTimeZone;

    /**
     * Test flag {@code update-offer.ab-initio-test}. With {@code Y} only a warning is written to the log:
     * the microservice has no alternate test path and the offer follows the normal flow.
     */
    @Value("${update-offer.ab-initio-test:N}")
    private String abInitioTest;

    /** System mode used to look up the time zone configuration. */
    @Value("${update-offer.timezone.sys-mode:RealTime}")
    private String tzSysMode;

    /**
     * Writes the input log, processes each offer and writes the output log.
     * @param requests received offers
     * @param headers request headers
     * @return one response per offer
     */
    @Override
    public List<UpdateOfferResponse> updateOffer(List<UpdateOfferRequest> requests, UpdateOfferHeaders headers) {
        auditLogService.logRequest(headers, requests);
        List<UpdateOfferResponse> responses = requests.stream()
                .map(request -> procesarOferta(request, headers))
                .toList();
        auditLogService.logResponse(headers, responses);
        return responses;
    }

    /**
     * Processes one offer. Any failure becomes an error response for that offer.
     * @param request offer to process
     * @param headers request headers
     * @return response of the offer
     */
    private UpdateOfferResponse procesarOferta(UpdateOfferRequest request, UpdateOfferHeaders headers) {
        LocalDateTime requestTime = LocalDateTime.now();

        try {
            return ejecutar(request, headers, requestTime);
        } catch (StepFailedException e) {
            log.error("Falló '{}' uuid={}: {}", e.getStep(), headers.getUuid(), e.getCause().toString());
            return responses.error(e.getStep(), e.getCause());
        } catch (Exception e) {
            log.error("Falló el proceso de la oferta uuid={}", headers.getUuid(), e);
            return responses.error("Proceso de la oferta", e);
        }
    }

    /**
     * Runs a step and, if it fails, tags it with its name to know where it failed.
     * @param nombre step name
     * @param accion work of the step
     * @param <T> result type
     * @return result of the step
     */
    private <T> T paso(String nombre, Supplier<T> accion) {
        try {
            return accion.get();
        } catch (Exception e) {
            throw new StepFailedException(nombre, e);
        }
    }

    /** A step of the flow failed: it carries the step name and the cause. */
    private static final class StepFailedException extends RuntimeException {
        /** Name of the step that failed. */
        private final String step;

        /**
         * Creates the step exception.
         * @param step step name
         * @param cause cause of the failure
         */
        StepFailedException(String step, Throwable cause) {
            super(cause);
            this.step = step;
        }

        /**
         * @return name of the step that failed
         */
        String getStep() {
            return step;
        }
    }

    /**
     * Runs the whole flow of an offer: time zone, suppression, sending to the EMS, fulfillment event and response.
     * If the EMS fails, the fulfillment event is still sent (without the EMS reply) and the error is propagated.
     * @param request offer to process
     * @param headers request headers
     * @param requestTime time when the offer started to be processed
     * @return response of the offer
     */
    private UpdateOfferResponse ejecutar(UpdateOfferRequest request, UpdateOfferHeaders headers, LocalDateTime requestTime) {
        String tzResponseCode = null;
        MapRequestResultDTO tz = null;
        if (translateTimeZone) {
            TimeZoneValidationStartDTO start = TimeZoneValidationStartDTO.builder()
                    .system(headers.getChannelId()).sysMode(tzSysMode).type("Request")
                    .date(dates(request)).time(times(request))
                    .build();
            TimeZoneValidationResult validation = paso("Validación de zona horaria", () -> {
                dtoValidator.validateOrThrow(start);
                return timeZoneValidationService.validate(start);
            });
            if (!UpdateOfferFlowConditions.continueToSuppression(validation.getResponseCode())) {
                UpdateOfferResponse res = new UpdateOfferResponse();
                res.setCode(validation.getResponseCode());
                res.setDescription(validation.getResponseText());
                return res;
            }
            tzResponseCode = validation.getResponseCode();
            tz = validation.getMapResult();
        }

        UpdateOfferResponse suppressed = paso("Validación de supresión", () -> checkSuppression(request, headers));
        if (suppressed != null) {
            return suppressed;
        }

        if ("Y".equals(abInitioTest)) {
            log.warn("AbInitioTest = Y uuid={}: el camino de AbInitio no está migrado; la oferta sigue por el JMS", headers.getUuid());
        }

        final String codigoZona = tzResponseCode;
        final MapRequestResultDTO zona = tz;
        String xml = paso("Armado del XML para el EMS", () -> updateOfferMapper.toEmsXml(request, requestTime, headers.get(CLIENT_ID_HEADER), codigoZona, zona));
        Map<String, String> propiedades = paso("Armado de las propiedades del mensaje", () ->
                updateOfferMapper.toEmsProperties(request, requestTime, headers.get(CLIENT_ID_HEADER), codigoZona, zona));
        String reply;
        try {
            reply = paso("Envío al EMS", () -> emsSender.send(xml, propiedades));
        } catch (StepFailedException e) {
            sendToKafka(request, headers, requestTime, null);     // el evento no depende del EMS
            throw e;
        }
        UpdateOfferResponse emsResponse = leerRespuestaDelEms(reply);

        sendToKafka(request, headers, requestTime, emsResponse);

        return responses.success(request, emsResponse);
    }

    /**
     * Reads the code and text of the EMS reply, which travel in the fulfillment event.
     * @param reply raw EMS reply
     * @return the parsed response, or {@code null} if there was no reply or it could not be read
     */
    private UpdateOfferResponse leerRespuestaDelEms(String reply) {
        if (reply == null || reply.isBlank()) {
            return null;
        }
        try {
            return updateOfferMapper.toRestResponse(reply);
        } catch (Exception e) {
            log.warn("No se pudo leer la respuesta del EMS: {}", e.getMessage());
            return null;
        }
    }

    /**
     * Queues the fulfillment event if there is an active destination. It never propagates errors: the event does not
     * affect the response.
     * @param request processed offer
     * @param headers request headers
     * @param requestTime time when the offer started to be processed
     * @param response EMS response, or {@code null} if there was none
     */
    private void sendToKafka(UpdateOfferRequest request, UpdateOfferHeaders headers, LocalDateTime requestTime,
                             UpdateOfferResponse response) {
        try {
            if (offerFulfillmentEmsSender.isEnabled()) {
                offerFulfillmentEmsSender.sendAsync(kafkaSenderDashboard.build(request, headers, requestTime, response));
            } else {
                log.info("[KAFKA] Resultado: {}", responses.kafkaDisabledText());
            }
        } catch (Exception e) {
            log.error("KAFKA-ERROR no se pudo encolar uuid={}: {}", headers.getUuid(), e.toString(), e);
        }
    }

    /**
     * Dates of the offer to validate: the appointment date.
     * @param r offer
     * @return list with the date, or empty
     */
    private List<ValueItemDTO> dates(UpdateOfferRequest r) {
        return hasText(r.getAppointmentDate())
                ? List.of(new ValueItemDTO(r.getAppointmentDate(), "AppointmentDate")) : List.of();
    }

    /**
     * Times of the offer to validate: start and end of the appointment, with the name used to read them later.
     * @param r offer
     * @return list with the times that have a value
     */
    private List<ValueItemDTO> times(UpdateOfferRequest r) {
        List<ValueItemDTO> out = new ArrayList<>();
        if (hasText(r.getAppointmentStartTime())) {
            out.add(new ValueItemDTO(r.getAppointmentStartTime(), "AppointmentStartTime"));
        }
        if (hasText(r.getAppointmentEndTime())) {
            out.add(new ValueItemDTO(r.getAppointmentEndTime(), "AppointmentEndTime"));
        }
        return out;
    }

    /**
     * @param s text to check
     * @return {@code true} if it is neither null nor blank
     */
    private static boolean hasText(String s) { return s != null && !s.trim().isEmpty(); }

    /**
     * Checks whether the operation is suppressed for the channel and country of the offer.
     * @param request offer
     * @param headers request headers
     * @return the suppression response, or {@code null} if the operation is not suppressed
     */
    private UpdateOfferResponse checkSuppression(UpdateOfferRequest request, UpdateOfferHeaders headers) {
        StartRequestParams params = new StartRequestParams();
        params.setRequestingChannel(request.getChannelCode());
        params.setCountryCode(headers.getCountryCode());
        params.setCurrentOperationName(OPERATION_NAME);

        StartRequest startRequest = new StartRequest();
        startRequest.setRequestParams(params);
        dtoValidator.validateOrThrow(startRequest);

        FilteredSuppressionList filtered = suppressionCheckService.perform(startRequest);
        if (filtered == null || filtered.getResults() == null) {
            return null;
        }
        return filtered.getResults().stream()
                .filter(r -> r.getOperationDetails() != null)
                .flatMap(r -> r.getOperationDetails().stream())
                .filter(d -> "true".equalsIgnoreCase(d.getIndicator()))
                .findFirst()
                .map(d -> {
                    UpdateOfferResponse res = new UpdateOfferResponse();
                    res.setCode(d.getResponseCode());
                    res.setDescription(d.getResponseText());
                    return res;
                })
                .orElse(null);
    }
}
