/** Audit log of the received request and the returned response. */
package com.banamex.cops.update_offer.audit;
