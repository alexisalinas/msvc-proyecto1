package com.banamex.cops.update_offer.mapper;

import com.banamex.cops.update_offer.config.OfferJmsProperties;
import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.timeZoneValidation.DateGrpDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.MapRequestResultDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TimeGrpDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Converts the received offer into the fields of the {@code UpdateOffer} event sent to the EMS.
 * Mandatory fields are always written (empty if there is no data) and optional ones only if they have a value. If the
 * time zone is enabled and the validation succeeded, the date and times of the appointment are already converted.
 */
@Component
@RequiredArgsConstructor
public class OfferEventMapper {

    /** Format of the update time without offset. */
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
    /** Format of the update time with offset. */
    private static final DateTimeFormatter TS_OFFSET = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

    /** Customer number padding configuration. */
    private final OfferJmsProperties props;
    /** Extracts the user fields from {@code userText}. */
    private final UserTextParser userTextParser;

    /** If {@code true}, the converted date and times are used. */
    @Value("${update-offer.timezone.translate-time-zone:true}")
    private boolean translateTimeZone;

    /** Zone in which the update time is written when the time zone is enabled. */
    @Value("${update-offer.timezone.ecrm-time-zone:US/Central}")
    private String ecrmTimeZone;

    /**
     * Converts the offer into the event fields, in the order they are sent.
     * @param rq received offer
     * @param requestTime time when the offer started to be processed
     * @param updatedBy value of the {@code client_id} header
     * @param tzResponseCode code of the time zone validation, or {@code null} if it was not validated
     * @param tz converted dates and times, or {@code null} if it was not validated
     * @return event fields, from name to value
     */
    public Map<String, String> map(UpdateOfferRequest rq, LocalDateTime requestTime, String updatedBy,
                                   String tzResponseCode, MapRequestResultDTO tz) {
        boolean tzActive = translateTimeZone && tz != null && tzOk(tzResponseCode);
        Map<Integer, String> uf = userTextParser.parse(rq.getUserText());
        Map<String, String> o = new LinkedHashMap<>();

        req(o, "RequestingChannel", rq.getChannelCode());
        req(o, "CampaignID", rq.getCampaignId());
        req(o, "WaveID", rq.getWaveId());
        req(o, "AccountNO", rq.getAccountNumber());
        req(o, "CardNO", rq.getCardNumber());
        req(o, "AssignedBy", rq.getAssignedBy());
        opt(o, "AgentID", rq.getAssignedTo());

        if (hasText(rq.getAppointmentDate())) {
            String tzDate = tzActive ? tzDate(tz, "AppointmentDate") : null;
            o.put("ApptDate", tzDate != null ? tzDate : rq.getAppointmentDate());
        }
        String tzStart = tzActive ? tzTime(tz, "AppointmentStartTime") : null;
        req(o, "ApptStartTime", tzStart != null ? tzStart : withoutSeconds(rq.getAppointmentStartTime()));
        String tzEnd = tzActive ? tzTime(tz, "AppointmentEndTime") : null;
        req(o, "ApptEndTime", tzEnd != null ? tzEnd : withoutSeconds(rq.getAppointmentEndTime()));

        opt(o, "ApptConfirmation", rq.getOfferedNumber());
        req(o, "ReasonCode", rq.getReasonCode());
        req(o, "ReasonDescription", rq.getReasonDescription());
        req(o, "Comments", rq.getComments());
        req(o, "ContactNumber", rq.getContactIndicatorNumber());
        req(o, "OfferStatus", rq.getOfferStatus());
        req(o, "SysVersion", rq.getSchemaVersion());

        req(o, "CustomerNO", customerNo(rq.getCustomerId()));
        req(o, "OfferSource", rq.getOfferSource());
        for (int i = 1; i <= 100; i++) {
            if (i <= 20 || i == 29) req(o, "UserField" + i, uf.get(i)); else opt(o, "UserField" + i, uf.get(i));
        }
        req(o, "OfferAction", rq.getOfferActionCode());
        req(o, "GiftCode", rq.getGiftCode());
        req(o, "GiftConfirmationNO", rq.getGiftConfirmationNumber());
        opt(o, "FulfillmentReferencedNO", rq.getFulfillmentTrackerFlag());
        opt(o, "ProbabilityAmount", rq.getAmount());
        opt(o, "Department", rq.getDepartmentId());
        opt(o, "Branch", rq.getBranchId());
        req(o, "ContactReference", rq.getCustomerReferenceNumber());
        opt(o, "Priority", rq.getOfferPriority());
        opt(o, "Workgroup", rq.getWorkgroupId());
        req(o, "LVCode", rq.getLevelCode());
        req(o, "UpdatedBy", updatedBy);
        req(o, "UpdateTime", tzActive
                ? OffsetDateTime.now(ZoneId.of(ecrmTimeZone)).format(TS_OFFSET)
                : (requestTime != null ? requestTime.format(TS) : null));
        opt(o, "ControlField", contextTypeAt(rq, 0));

        opt(o, "AreaID", rq.getAreaIdentifier());
        opt(o, "DivisionID", rq.getDivisionCode());
        opt(o, "RegionID", rq.getBranchRegionIdentifier());
        opt(o, "AgentName", rq.getAgentName());
        req(o, "ContactType", rq.getContactType());
        req(o, "ContactInfo", rq.getContactIndicatorNumber());
        opt(o, "OfferCategory", rq.getOfferCategory());
        opt(o, "BranchName", rq.getBranchName());
        req(o, "DepartmentName", rq.getDepartmentName());
        opt(o, "ChannelResponse", rq.getResponseChannel());
        opt(o, "Purpose", rq.getPurpose());
        opt(o, "LocationIndicator", contextTypeAt(rq, 1));
        opt(o, "CustomerEmail", rq.getCustomerEmailAddress());
        opt(o, "FulfillmentScript", rq.getFulfillmentCode());
        return o;
    }

    /**
     * Converted date with that name.
     * @param tz conversion result
     * @param name date name
     * @return converted date, or {@code null}
     */
    private String tzDate(MapRequestResultDTO tz, String name) {
        return tz.getDateGrp().stream()
                .filter(g -> name.equalsIgnoreCase(g.getDateName()))
                .map(DateGrpDTO::getDate).findFirst().orElse(null);
    }

    /**
     * Converted time with that name.
     * @param tz conversion result
     * @param name time name
     * @return converted time, or {@code null}
     */
    private String tzTime(MapRequestResultDTO tz, String name) {
        return tz.getTimeGrp().stream()
                .filter(g -> name.equalsIgnoreCase(g.getTimeName()))
                .map(TimeGrpDTO::getTime).findFirst().orElse(null);
    }

    /**
     * Removes the seconds from an {@code HH:mm:ss} time; if it does not have three parts, it is left as is.
     * @param t time
     * @return time without seconds, or an empty string if null
     */
    private static String withoutSeconds(String t) {
        if (t == null || t.isEmpty()) return "";
        return t.split(":", -1).length == 3 ? t.substring(0, t.lastIndexOf(':')) : t;
    }

    /**
     * The time zone validation succeeded if the code ends in {@code 0}.
     * @param responseCode validation code
     * @return {@code true} if it succeeded
     */
    private static boolean tzOk(String responseCode) {
        return responseCode != null && !responseCode.isEmpty()
                && responseCode.charAt(responseCode.length() - 1) == '0';
    }

    /**
     * Customer number, padded on the left if padding is enabled.
     * @param v customer number
     * @return customer number for the event
     */
    private String customerNo(String v) {
        if (v == null || v.isEmpty()) return "";
        return props.isCustomerPadding()
                ? padFront(v, props.getCustomerPaddingLength(), props.getCustomerPaddingChar()) : v;
    }

    /**
     * Pads on the left with the given character up to the requested length.
     * @param v text
     * @param len desired length
     * @param c padding character
     * @return padded text
     */
    private static String padFront(String v, int len, char c) {
        StringBuilder sb = new StringBuilder();
        for (int i = v.length(); i < len; i++) sb.append(c);
        return sb.append(v).toString();
    }

    /**
     * Value of {@code contextType} at the given position.
     * @param rq offer
     * @param idx position
     * @return value, or {@code null} if it does not exist
     */
    private String contextTypeAt(UpdateOfferRequest rq, int idx) {
        return rq.getContextType() != null && idx < rq.getContextType().size()
                && rq.getContextType().get(idx) != null
                ? rq.getContextType().get(idx).getContextType() : null;
    }

    /**
     * @param s text
     * @return {@code true} if it is neither null nor blank
     */
    private static boolean hasText(String s) { return s != null && !s.trim().isEmpty(); }

    /**
     * Mandatory field: always written (empty if there is no data).
     * @param m fields
     * @param k name
     * @param v value
     */
    private static void req(Map<String, String> m, String k, String v) { m.put(k, v == null ? "" : v); }

    /**
     * Optional field: written only if it has a value.
     * @param m fields
     * @param k name
     * @param v value
     */
    private static void opt(Map<String, String> m, String k, String v) { if (v != null) m.put(k, v); }
}
