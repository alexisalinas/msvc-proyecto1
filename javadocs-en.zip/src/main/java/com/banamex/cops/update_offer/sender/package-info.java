/** Sending of the update message to the EMS and publication of the fulfillment event. */
package com.banamex.cops.update_offer.sender;
