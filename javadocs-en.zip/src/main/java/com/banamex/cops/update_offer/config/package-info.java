/** Spring configuration: JMS connections, security, response properties and the link with the database library. */
package com.banamex.cops.update_offer.config;
