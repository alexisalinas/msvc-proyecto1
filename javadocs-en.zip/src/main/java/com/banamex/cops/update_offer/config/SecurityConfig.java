package com.banamex.cops.update_offer.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.web.SecurityFilterChain;

import com.citibanamex.messaging.connector.ems.config.EmsConfig;

/**
 * Web security configuration: CSRF disabled and all routes open; header validation is done by the errors library.
 */
@Configuration("updateoffer_SecurityConfig")
@EnableWebSecurity
@Import(EmsConfig.class)
public class SecurityConfig {

    /**
     * Security filter chain.
     * @param http Spring Security HTTP configuration
     * @return filter chain
     * @throws Exception if it cannot be built
     */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(AbstractHttpConfigurer::disable)
            .authorizeHttpRequests(auth -> auth
                .anyRequest().permitAll()
            );
        return http.build();
    }
}