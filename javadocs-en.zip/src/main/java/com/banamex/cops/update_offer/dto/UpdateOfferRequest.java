package com.banamex.cops.update_offer.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/** One offer of the request body; the body is a list of these. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateOfferRequest {

    /** Channel that requests the update; it is also used to check the suppression. */
    @NotNull(message = "channelCode es obligatorio")
    private String channelCode;

    /** Campaign of the offer. */
    @NotNull(message = "campaignId es obligatorio")
    @Size(min = 1, max = 20, message = "campaignId debe tener entre 1 y 20 caracteres")
    private String campaignId;

    /** Wave of the offer. */
    @NotNull(message = "waveId es obligatorio")
    @Size(min = 1, max = 20, message = "waveId debe tener entre 1 y 20 caracteres")
    private String waveId;

    /** Customer of the offer. */
    @NotNull(message = "customerId es obligatorio")
    @Size(min = 1, max = 20, message = "customerId debe tener entre 1 y 20 caracteres")
    private String customerId;

    /** Execution version. */
    private KeyProcessEnum keyProcess;

    /** Account number. */
    @Size(min = 1, max = 35)
    private String accountNumber;

    /** Card number; it is masked in the logs. */
    @Size(min = 1, max = 19)
    private String cardNumber;

    /** Source of the offer. */
    private String offerSource;

    /** Priority of the offer. */
    @Size(min = 1, max = 5)
    private String offerPriority;

    /** Who assigned the offer. */
    private String assignedBy;
    /** Who the offer was assigned to. */
    private String assignedTo;
    /** Department identifier. */
    private String departmentId;
    /** Branch identifier. */
    private String branchId;
    /** Appointment date. */
    private String appointmentDate;
    /** Appointment start time. */
    private String appointmentStartTime;
    /** Appointment end time. */
    private String appointmentEndTime;
    /** Offered number (appointment confirmation). */
    private String offeredNumber;

    /** Offer status. */
    @Size(min = 1, max = 2)
    private String offerStatus;

    /** Reason code. */
    private String reasonCode;
    /** Reason description. */
    private String reasonDescription;
    /** Amount or probability of the offer. */
    private String amount;
    /** Offer action. */
    private String offerActionCode;
    /** Comments. */
    private String comments;

    /** JSON with the user fields ({@code UserField1} to {@code UserField100}). */
    @Pattern(regexp = "(?s)^\\{.*\\}$", message = "userText debe ser un JSON válido")
    private String userText;

    /** Contact number or indicator. */
    private String contactIndicatorNumber;
    /** Customer contact reference. */
    private String customerReferenceNumber;
    /** Gift code. */
    private String giftCode;
    /** Gift confirmation. */
    private String giftConfirmationNumber;
    /** Fulfillment tracking reference. */
    private String fulfillmentTrackerFlag;
    /** Level code. */
    private String levelCode;

    /** Schema version. */
    @Size(min = 1, max = 3)
    private String schemaVersion;

    /** Workgroup. */
    private String workgroupId;
    /** Agent name. */
    private String agentName;
    /** Division code. */
    private String divisionCode;
    /** Branch region. */
    private String branchRegionIdentifier;
    /** Area identifier. */
    private String areaIdentifier;
    /** Contact type. */
    private String contactType;
    /** Offer category. */
    private String offerCategory;
    /** Branch name. */
    private String branchName;
    /** Purpose of the contact. */
    private String purpose;
    /** Department name. */
    private String departmentName;
    /** Response channel. */
    private String responseChannel;
    /** Customer email address. */
    private String customerEmailAddress;
    /** Fulfillment script or code. */
    private String fulfillmentCode;

    /** Control fields; the first is the control field and the second is the location indicator. */
    @Valid
    private List<ControlFieldDTO> contextType;
}