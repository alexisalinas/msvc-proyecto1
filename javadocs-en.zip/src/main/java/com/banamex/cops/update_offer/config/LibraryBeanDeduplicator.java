package com.banamex.cops.update_offer.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** If a library class was registered more than once as a bean, it keeps only the library registration. */
@Slf4j
@Component
public class LibraryBeanDeduplicator implements BeanFactoryPostProcessor, Ordered {

    /** Library package that is checked. */
    private final String libraryPackage;

    /** Checks the classes of {@code com.banamex.cops.app}. */
    public LibraryBeanDeduplicator() {
        this("com.banamex.cops.app.");
    }

    /**
     * Checks the classes of the given package (for tests).
     * @param libraryPackage package to check
     */
    LibraryBeanDeduplicator(String libraryPackage) {
        this.libraryPackage = libraryPackage;
    }

    /**
     * It runs last, when all the registrations are already present.
     * @return execution order
     */
    @Override
    public int getOrder() {
        return Ordered.LOWEST_PRECEDENCE;
    }

    /**
     * Removes the duplicate registrations and keeps the library one (the one named after the class).
     * @param beanFactory bean factory
     */
    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) {
        if (!(beanFactory instanceof BeanDefinitionRegistry registry)) {
            return;
        }
        Map<String, Class<?>> library = new LinkedHashMap<>();
        for (String name : beanFactory.getBeanDefinitionNames()) {
            Class<?> type = typeOf(beanFactory, name);
            if (type != null && type.getName().startsWith(libraryPackage)) {
                library.put(name, type);
            }
        }
        for (Map.Entry<String, Class<?>> keeper : library.entrySet()) {
            String keeperName = keeper.getKey();
            Class<?> keeperType = keeper.getValue();
            if (!keeperName.equals(keeperType.getName()) || !registry.containsBeanDefinition(keeperName)) {
                continue;
            }
            List<String> extra = new ArrayList<>();
            library.forEach((name, type) -> {
                if (!name.equals(keeperName) && registry.containsBeanDefinition(name) && type.isAssignableFrom(keeperType)) {
                    extra.add(name);
                }
            });
            for (String name : extra) {
                log.warn("[BEANS] {} estaba registrado dos veces: se quita '{}' ({}) y se conserva el de la librería",
                        keeperType.getSimpleName(), name, origin(registry.getBeanDefinition(name)));
                registry.removeBeanDefinition(name);
            }
        }
    }

    /**
     * Type of a bean, or {@code null} if it cannot be resolved.
     * @param beanFactory bean factory
     * @param name bean name
     * @return class of the bean
     */
    private static Class<?> typeOf(ConfigurableListableBeanFactory beanFactory, String name) {
        try {
            return beanFactory.getType(name, false);
        } catch (RuntimeException e) {
            return null;
        }
    }

    /**
     * Text saying where the registration comes from, for the log.
     * @param definition bean definition
     * @return origin
     */
    private static String origin(BeanDefinition definition) {
        if (definition.getFactoryMethodName() != null) {
            String factory = definition.getFactoryBeanName() == null ? "?" : definition.getFactoryBeanName();
            return "@Bean " + definition.getFactoryMethodName() + "() en " + factory.substring(factory.lastIndexOf('.') + 1);
        }
        return definition.getResourceDescription() == null ? "@Import" : "escaneo de componentes";
    }
}
