package com.banamex.cops.update_offer.controller;

import com.banamex.cops.commons.errors.headers.HeaderValidation;
import com.banamex.cops.update_offer.dto.UpdateOfferHeaders;
import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import com.banamex.cops.update_offer.service.UpdateOfferService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * REST controller for the offer update operation.
 * It exposes {@code POST /sd-campaing-management/v1/update-offer}. The mandatory headers are validated by the errors
 * library through {@code @HeaderValidation}; the controller only gathers headers and body and delegates the flow to
 * {@link UpdateOfferService}.
 */
@Slf4j
@RestController
@RequestMapping("/sd-campaing-management/v1/update-offer")
@RequiredArgsConstructor
@HeaderValidation
public class UpdateOfferController {

    /** Service that runs the update flow. */
    private final UpdateOfferService updateOfferService;

    /**
     * Updates one or more offers.
     * It answers 200 even if an offer fails: the result of each one travels in its own {@code code} and
     * {@code description}. Header and body errors are resolved by the errors library before reaching this method.
     * @param uuid transaction identifier
     * @param channelId channel that invokes the operation
     * @param countryCode 2-letter country code (ISO 3166)
     * @param businessCode business code
     * @param host origin host (optional)
     * @param sid session identifier
     * @param acceptLanguage preferred language (optional)
     * @param httpHeaders all the received headers
     * @param requests offers to update
     * @return one response per offer, in the same order as the request
     */
    @PostMapping
    public ResponseEntity<List<UpdateOfferResponse>> updateOffer(
            @RequestHeader(value = "uuid", required = false) String uuid,
            @RequestHeader(value = "ChannelId", required = false) String channelId,
            @RequestHeader(value = "countryCode", required = false)
            @Pattern(regexp = "^[A-Za-z]{2}$", message = "countryCode debe tener 2 letras (ISO 3166)") String countryCode,
            @RequestHeader(value = "businessCode", required = false) String businessCode,
            @RequestHeader(value = "host", required = false) String host,
            @RequestHeader(value = "sid", required = false) String sid,
            @RequestHeader(value = "Accept-Language", required = false) String acceptLanguage,
            @RequestHeader HttpHeaders httpHeaders,
            @RequestBody List<@Valid UpdateOfferRequest> requests) {

        UpdateOfferHeaders headers = UpdateOfferHeaders.builder()
                .uuid(uuid)
                .channelId(channelId)
                .countryCode(countryCode)
                .businessCode(businessCode)
                .host(host)
                .sid(sid)
                .acceptLanguage(acceptLanguage)
                .all(allHeaders(httpHeaders))
                .build();

        List<UpdateOfferResponse> responses = updateOfferService.updateOffer(requests, headers);

        return ResponseEntity.ok(responses);
    }

    /**
     * Copies all the received headers into a case-insensitive map, keeping the first value of each one.
     * @param httpHeaders request headers
     * @return map of name to first value
     */
    private static Map<String, String> allHeaders(HttpHeaders httpHeaders) {
        Map<String, String> all = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        if (httpHeaders != null) {
            httpHeaders.forEach((name, values) -> {
                if (values != null && !values.isEmpty()) {
                    all.put(name, values.get(0));
                }
            });
        }
        return all;
    }
}
