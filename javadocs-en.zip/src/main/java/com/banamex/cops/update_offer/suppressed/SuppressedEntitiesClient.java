package com.banamex.cops.update_offer.suppressed;

import com.banamex.cops.update_offer.dto.suppression.StartRequestParams;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntitiesListRoot;

/** Provides the list of suppressed entities. */
public interface SuppressedEntitiesClient {

    /**
     * Returns the list of suppressed entities.
     * @param params request data
     * @return list of suppressed entities
     */
    SuppressedEntitiesListRoot getListOfSuppressedEntities(StartRequestParams params);
}
