package com.banamex.cops.update_offer.config;

import com.banamex.cops.app.repository.CopOfferFulfillmentRepository;
import com.banamex.cops.app.repository.CopSuppressionRepository;
import com.banamex.cops.app.service.impl.CopOfferFulfillmentServiceImpl;
import com.banamex.cops.app.service.impl.CopSuppressionServiceImpl;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({
        CopOfferFulfillmentRepository.class,
        CopOfferFulfillmentServiceImpl.class,
        CopSuppressionRepository.class,
        CopSuppressionServiceImpl.class
})
/** Connects the microservice with the queries of the {@code chnn-cop-lib-operation-db} library. */
public class OfferFulfillmentConfig {
}
