package com.banamex.cops.update_offer.dto.suppression;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Data that identifies the operation to check. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StartRequestParams {

    /** Channel that requests the operation. */
    private String requestingChannel;

    /** Country. */
    @NotBlank(message = "El campo CountryCode es obligatorio")
    private String countryCode;

    /** Name of the current operation. */
    @NotBlank(message = "El campo CurrentOperationName es obligatorio")
    private String currentOperationName;
}
