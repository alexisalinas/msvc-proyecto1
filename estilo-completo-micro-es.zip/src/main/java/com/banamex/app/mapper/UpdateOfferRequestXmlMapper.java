package com.banamex.app.mapper;

import static com.banamex.app.mapper.XmlUtil.tag;

import com.banamex.app.dto.UpdateOfferRequest;
import com.banamex.app.dto.timezonevalidation.MapRequestResultDto;
import java.time.LocalDateTime;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/** Convierte la oferta en el XML y en las propiedades del mensaje que se mandan al EMS. */
@Component
@RequiredArgsConstructor
public class UpdateOfferRequestXmlMapper {

  /** Arma los campos del evento. */
  private final OfferEventMapper offerEventMapper;

  /**
   * Si es {@code true}, el evento va dentro de {@code <Envelope><Body>}; si es {@code false}, va
   * solo el evento.
   */
  @Value("${update-offer.ems.envelope:true}")
  private boolean envelope;

  /**
   * Si es {@code true}, el elemento del evento lleva su namespace como {@code xmlns} sin prefijo.
   */
  @Value("${update-offer.ems.xml-namespace:false}")
  private boolean xmlNamespace;

  /** Namespace del evento. */
  @Value(
      // TODO checkstyle: línea larga por un texto que no se puede partir sin cambiarlo.
      "${update-offer.ems.event-namespace:www.tibco.com/be/ontology/OfferEngine/Events/Updat"
          + "eOffer}")
  private String eventNamespace = "www.tibco.com/be/ontology/OfferEngine/Events/UpdateOffer";

  /** Nombre del elemento del cuerpo del evento. */
  @Value("${update-offer.ems.body-element:UpdateOffer}")
  private String bodyElement;

  /**
   * Arma el XML del mensaje: el evento con sus campos como elementos simples, sin prefijos.
   *
   * @param rq oferta
   * @param requestTime hora de proceso
   * @param updatedBy valor del header {@code client_id}
   * @param tzResponseCode código de zona horaria
   * @param tz fechas y horas convertidas
   * @return XML del mensaje
   */
  public String toEmsXml(
      UpdateOfferRequest rq,
      LocalDateTime requestTime,
      String updatedBy,
      String tzResponseCode,
      MapRequestResultDto tz) {
    Map<String, String> fields =
        offerEventMapper.map(rq, requestTime, updatedBy, tzResponseCode, tz);

    String indent = envelope ? "      " : "";
    StringBuilder x = new StringBuilder();
    if (envelope) {
      x.append("<Envelope>\n");
      x.append("   <Body>\n");
    }
    x.append(indent)
        .append("<")
        .append(bodyElement)
        .append(xmlNamespace ? " xmlns=\"" + XmlUtil.esc(eventNamespace) + "\"" : "")
        .append(">\n");
    fields.forEach((k, v) -> tag(x, indent + "   ", k, v));
    x.append(indent).append("</").append(bodyElement).append(">");
    if (envelope) {
      x.append("\n   </Body>\n");
      x.append("</Envelope>");
    }
    return x.toString();
  }

  /**
   * Arma las propiedades del mensaje JMS: {@code _nm_} (nombre del evento), {@code _ns_}
   * (namespace) y los campos de la oferta.
   *
   * @param rq oferta
   * @param requestTime hora de proceso
   * @param updatedBy valor del header {@code client_id}
   * @param tzResponseCode código de zona horaria
   * @param tz fechas y horas convertidas
   * @return propiedades del mensaje
   */
  public Map<String, String> toEmsProperties(
      UpdateOfferRequest rq,
      LocalDateTime requestTime,
      String updatedBy,
      String tzResponseCode,
      MapRequestResultDto tz) {
    Map<String, String> properties = new java.util.LinkedHashMap<>();
    properties.put("_nm_", bodyElement);
    properties.put("_ns_", eventNamespace);
    properties.putAll(offerEventMapper.map(rq, requestTime, updatedBy, tzResponseCode, tz));
    return properties;
  }
}
