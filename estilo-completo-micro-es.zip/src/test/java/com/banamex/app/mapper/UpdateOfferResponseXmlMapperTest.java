package com.banamex.app.mapper;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.banamex.app.dto.ControlFieldDto;
import com.banamex.app.dto.UpdateOfferResponse;
import com.fasterxml.jackson.databind.json.JsonMapper;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/** Pruebas unitarias de {@code UpdateOfferResponseXmlMapper}. */
class UpdateOfferResponseXmlMapperTest {

  private UpdateOfferResponseXmlMapper mapper;

  @BeforeEach
  void setUp() {
    mapper = new UpdateOfferResponseXmlMapper(JsonMapper.builder().build());
  }

  @Test
  void xmlConNombresNuevos() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    UpdateOfferResponse r =
        mapper.fromReply(
            "<Response><Code>000</Code><Description>OK</Description>"
                // TODO checkstyle: línea larga por un texto que no se puede partir sin cambiarlo.
                + "<CustomerReferenceNumber>REF1</CustomerReferenceNumber><StartDate>2026-10"
                + "-01</StartDate>"
                + "<EndDate>2026-10-31</EndDate><SurveyModeCode>M1</SurveyModeCode></Response>");

    // Then
    assertThat(r.getCode()).isEqualTo("000");
    assertThat(r.getDescription()).isEqualTo("OK");
    assertThat(r.getCustomerReferenceNumber()).isEqualTo("REF1");
    assertThat(r.getStartDate()).isEqualTo("2026-10-01");
    assertThat(r.getEndDate()).isEqualTo("2026-10-31");
    assertThat(r.getSurveyModeCode()).isEqualTo("M1");
  }

  @Test
  void xmlConNombresAntiguosDeBw() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    UpdateOfferResponse r =
        mapper.fromReply(
            "<Rs><ReferenceContacto>R9</ReferenceContacto><ModeCmp>MC</ModeCmp>"
                + "<Code>0</Code><Description>ok</Description></Rs>");

    // Then
    assertThat(r.getCustomerReferenceNumber()).isEqualTo("R9");
    assertThat(r.getSurveyModeCode()).isEqualTo("MC");
  }

  @Test
  void xmlConPrefijosDeNamespaceSeEncuentraIgual() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    UpdateOfferResponse r =
        mapper.fromReply(
            "<a:Rs xmlns:a=\"urn:x\"><a:Code>7</a:Code><a:Description>desc</a:Description></a:Rs>");

    // Then
    assertThat(r.getCode()).isEqualTo("7");
    assertThat(r.getDescription()).isEqualTo("desc");
  }

  @Test
  void xmlControlFieldSeConvierteAcontextType() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    UpdateOfferResponse r =
        mapper.fromReply(
            // TODO checkstyle: línea larga por un texto que no se puede partir sin cambiarlo.
            "<Rs><Code>0</Code><Description>d</Description><ControlField>c1</ControlField><C"
                + "ontrolField>c2</ControlField></Rs>");

    // Then
    assertThat(r.getContextType())
        .extracting(ControlFieldDto::getContextType)
        .containsExactly("c1", "c2");
  }

  @Test
  void xmlSinCodeNiDescriptionUsaValoresPorDefecto() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    UpdateOfferResponse r = mapper.fromReply("<Rs><Otra>x</Otra></Rs>");

    // Then
    assertThat(r.getCode()).isEqualTo("ERROR");
    assertThat(r.getDescription()).isNotBlank();
    assertThat(r.getContextType()).isNull();
  }

  @Test
  void xmlMalFormadoLanzaIllegalState() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When / Then
    assertThatThrownBy(() -> mapper.fromReply("<Rs><Code>0</Rs>"))
        .isInstanceOf(IllegalStateException.class);
  }

  @Test
  void xmlConDoctypeSeRechaza() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When / Then
    assertThatThrownBy(
            () -> mapper.fromReply("<!DOCTYPE a [<!ENTITY x \"y\">]><a><Code>&x;</Code></a>"))
        .isInstanceOf(IllegalStateException.class);
  }

  @Test
  void respuestaVaciaOrNulaLanzaIllegalState() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When / Then
    assertThatThrownBy(() -> mapper.fromReply(null)).isInstanceOf(IllegalStateException.class);
    assertThatThrownBy(() -> mapper.fromReply("  ")).isInstanceOf(IllegalStateException.class);
  }

  @Test
  void jsonConNombresNuevosAndAntiguos() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    UpdateOfferResponse r =
        mapper.fromReply(
            // TODO checkstyle: línea larga por un texto que no se puede partir sin cambiarlo.
            "{\"code\":\"000\",\"description\":\"OK\",\"referenceContacto\":\"R1\",\"modeCmp"
                + "\":\"M\"}");

    // Then
    assertThat(r.getCode()).isEqualTo("000");
    assertThat(r.getDescription()).isEqualTo("OK");
    assertThat(r.getCustomerReferenceNumber()).isEqualTo("R1");
    assertThat(r.getSurveyModeCode()).isEqualTo("M");
  }

  @Test
  void jsonAnidadoSeBuscaRecursivamente() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    UpdateOfferResponse r =
        mapper.fromReply("{\"response\":{\"data\":{\"Code\":\"5\",\"Description\":\"anidado\"}}}");

    // Then
    assertThat(r.getCode()).isEqualTo("5");
    assertThat(r.getDescription()).isEqualTo("anidado");
  }

  @Test
  void jsonConArreglo() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    UpdateOfferResponse r =
        mapper.fromReply("{\"items\":[{\"code\":\"9\",\"description\":\"d\"}]}");

    // Then
    assertThat(r.getCode()).isEqualTo("9");
  }

  @Test
  void jsonSinCodeUsaError() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    UpdateOfferResponse r = mapper.fromReply("{\"x\":1}");

    // Then
    assertThat(r.getCode()).isEqualTo("ERROR");
  }

  @Test
  void jsonInvalidoLanzaIllegalState() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When / Then
    assertThatThrownBy(() -> mapper.fromReply("{no es json"))
        .isInstanceOf(IllegalStateException.class);
  }

  private static final String RESPUESTA_REAL =
      "<ns0:UpdateOfferRs xmlns:ns0=\"urn:services\"><ns1:ResponseCode"
          + " xmlns:ns1=\"urn:types\">COP_UPDOF_0</ns1:ResponseCode><ns1:ResponseText"
          + " xmlns:ns1=\"urn:types\">Successfully update offer"
          + " off:mx:RETAILRS25:RH52KYVD39:116740699</ns1:ResponseText><ns1:ControlField"
          + " xmlns:ns1=\"urn:types\">2</ns1:ControlField><ns1:ControlField"
          + " xmlns:ns1=\"urn:types\">881362001797184</ns1:ControlField></ns0:UpdateOfferRs>";

  @Test
  void respuestaRealSeLeeResponseCodeResponseTextAndLosDosControlField() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    UpdateOfferResponse r = mapper.fromReply(RESPUESTA_REAL);

    // Then
    assertThat(r.getCode()).isEqualTo("COP_UPDOF_0");
    assertThat(r.getDescription())
        .isEqualTo("Successfully update offer off:mx:RETAILRS25:RH52KYVD39:116740699");
    assertThat(r.getContextType())
        .extracting(ControlFieldDto::getContextType)
        .containsExactly("2", "881362001797184");
  }

  @Test
  void respuestaRealConElSegundoControlFieldVacioLoConservaComoCadenaVacia() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    UpdateOfferResponse r =
        mapper.fromReply(
            "<UpdateOfferRs><ResponseCode>COP_UPDOF_0</ResponseCode><ResponseText>ok</ResponseText>"
                + "<ControlField>3</ControlField><ControlField/></UpdateOfferRs>");

    // Then
    assertThat(r.getContextType())
        .extracting(ControlFieldDto::getContextType)
        .containsExactly("3", "");
  }

  @Test
  void xmlEncuentraLosCamposSinImportarLaRutaNiLaProfundidad() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    UpdateOfferResponse plano =
        mapper.fromReply("<Rs><Code>7</Code><Description>desc</Description></Rs>");
    UpdateOfferResponse profundo =
        mapper.fromReply(
            "<a><b><c><d><Code>7</Code><Description>desc</Description></d></c></b></a>");
    UpdateOfferResponse conOtroNombreDeRaiz =
        mapper.fromReply(
            // TODO checkstyle: línea larga por un texto que no se puede partir sin cambiarlo.
            "<Cualquiera><Header/><Body><X><Code>7</Code><Description>desc</Description></X>"
                + "</Body></Cualquiera>");

    // Then
    for (UpdateOfferResponse r : List.of(plano, profundo, conOtroNombreDeRaiz)) {
      assertThat(r.getCode()).isEqualTo("7");
      assertThat(r.getDescription()).isEqualTo("desc");
    }
  }

  private static final String LOTE =
      "<ActivityOutputBody>"
          + "<UpdateOfferRes><ResponseCode>COP_UPDOF_0</ResponseCode><ResponseText>Successfully"
          + " update offer off:mx:C1:W1:111</ResponseText>"
          // TODO checkstyle: línea larga por un texto que no se puede partir sin cambiarlo.
          + "<ControlField>5</ControlField><ControlField>8813625550465000</ControlField></Up"
          + "dateOfferRes><UpdateOfferRes><ResponseCode>COP_UPDOF_5</ResponseCode><ResponseT"
          + "ext>Campaign"
          + " not found</ResponseText></UpdateOfferRes></ActivityOutputBody>";

  @Test
  void loteDevuelveUnaRespuestaPorCadaUpdateOfferResEnElMismoOrden() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    List<UpdateOfferResponse> r = mapper.fromReplies(LOTE);

    // Then
    assertThat(r).hasSize(2);
    assertThat(r.get(0).getCode()).isEqualTo("COP_UPDOF_0");
    assertThat(r.get(0).getDescription()).isEqualTo("Successfully update offer off:mx:C1:W1:111");
    assertThat(r.get(1).getCode()).isEqualTo("COP_UPDOF_5");
    assertThat(r.get(1).getDescription()).isEqualTo("Campaign not found");
  }

  @Test
  void loteLoCamposDeUnaRespuestaNoSeMezclanConLosDeOtra() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    List<UpdateOfferResponse> r = mapper.fromReplies(LOTE);

    // Then
    assertThat(r.get(0).getContextType())
        .extracting(ControlFieldDto::getContextType)
        .containsExactly("5", "8813625550465000");
    assertThat(r.get(1).getContextType()).isNull();
  }

  @Test
  void loteConPrefijosAndNamespacesTambienSeSeparaPorUpdateOfferRes() {
    // Given
    String xml =
        "<ns:ActivityOutputBody xmlns:ns=\"urn:a\"><p:UpdateOfferRes"
            // TODO checkstyle: línea larga por un texto que no se puede partir sin cambiarlo.
            + " xmlns:p=\"urn:b\"><p:ResponseCode>A</p:ResponseCode><p:ResponseText>uno</p:R"
            + "esponseText></p:UpdateOfferRes><p:UpdateOfferRes"
            // TODO checkstyle: línea larga por un texto que no se puede partir sin cambiarlo.
            + " xmlns:p=\"urn:b\"><p:ResponseCode>B</p:ResponseCode><p:ResponseText>dos</p:R"
            + "esponseText></p:UpdateOfferRes>"
            + "</ns:ActivityOutputBody>";

    // When / Then
    assertThat(mapper.fromReplies(xml))
        .extracting(UpdateOfferResponse::getCode)
        .containsExactly("A", "B");
  }

  @Test
  void unSoloUpdateOfferResDevuelveUnaRespuesta() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    List<UpdateOfferResponse> r =
        mapper.fromReplies(
            // TODO checkstyle: línea larga por un texto que no se puede partir sin cambiarlo.
            "<UpdateOfferRes><ResponseCode>COP_UPDOF_0</ResponseCode><ResponseText>ok</Respo"
                + "nseText></UpdateOfferRes>");

    // Then
    assertThat(r).hasSize(1);
    assertThat(r.get(0).getCode()).isEqualTo("COP_UPDOF_0");
  }

  @Test
  void sinUpdateOfferResSeLeeComoUnaSolaRespuesta() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    List<UpdateOfferResponse> r = mapper.fromReplies(RESPUESTA_REAL);

    // Then
    assertThat(r).hasSize(1);
    assertThat(r.get(0).getCode()).isEqualTo("COP_UPDOF_0");
    assertThat(r.get(0).getContextType()).hasSize(2);
  }

  @Test
  void respuestaJsonSeTrataComoUna() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    List<UpdateOfferResponse> r =
        mapper.fromReplies("{\"code\":\"COP_UPDOF_0\",\"description\":\"ok\"}");

    // Then
    assertThat(r).hasSize(1);
    assertThat(r.get(0).getCode()).isEqualTo("COP_UPDOF_0");
  }

  @Test
  void respuestaVaciaOrMalFormadaLanzaIllegalState() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When / Then
    org.assertj.core.api.Assertions.assertThatThrownBy(() -> mapper.fromReplies(" "))
        .isInstanceOf(IllegalStateException.class);
    org.assertj.core.api.Assertions.assertThatThrownBy(() -> mapper.fromReplies("<UpdateOfferRes>"))
        .isInstanceOf(IllegalStateException.class);
  }
}
