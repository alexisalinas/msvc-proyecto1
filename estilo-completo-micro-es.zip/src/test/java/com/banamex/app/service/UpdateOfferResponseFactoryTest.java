package com.banamex.app.service;

import static org.assertj.core.api.Assertions.assertThat;

import com.banamex.app.config.UpdateOfferResponseProperties;
import com.banamex.app.dto.UpdateOfferRequest;
import com.banamex.app.dto.UpdateOfferResponse;
import com.banamex.app.testutil.TestData;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

/** Pruebas unitarias de {@code UpdateOfferResponseFactory}. */
class UpdateOfferResponseFactoryTest {

  /** 2026-11-11 16:30:45 UTC = 10:30:45 en US/Central (hora estándar, UTC-6). */
  private static final Instant AHORA = Instant.parse("2026-11-11T16:30:45Z");

  private UpdateOfferResponseProperties props;
  private UpdateOfferResponseFactory factory;

  @BeforeEach
  void setUp() {
    props = new UpdateOfferResponseProperties();
    factory = new UpdateOfferResponseFactory(props);
    ReflectionTestUtils.setField(factory, "clock", Clock.fixed(AHORA, ZoneOffset.UTC));
  }

  @Test
  void exitoLlevaElCodigoAndElTextoConLaFechaDeLaZonaEcrm() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    UpdateOfferResponse r = factory.success();

    // Then
    assertThat(r.getCode()).isEqualTo("COP_UPDOF_0");
    assertThat(r.getDescription()).isEqualTo("Successfully update offer 2026/11/11 10:30:45");
  }

  @Test
  void laFechaSigueElFormatoAndYyymmddhh24Miss() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When / Then
    assertThat(factory.success().getDescription())
        .matches(".* \\d{4}/\\d{2}/\\d{2} \\d{2}:\\d{2}:\\d{2}$");
  }

  @Test
  void laFechaUsaLaZonaEcrmConfigurada() {
    // Given
    ReflectionTestUtils.setField(factory, "ecrmTimeZone", "Asia/Tokyo");

    // When
    UpdateOfferResponse r = factory.success();

    // Then
    assertThat(r.getDescription()).endsWith("2026/11/12 01:30:45");
  }

  @Test
  void elFormatoDeLaFechaEsConfigurable() {
    // Given
    props.setDateFormat("dd-MM-yyyy HH:mm");

    // When
    UpdateOfferResponse r = factory.success();

    // Then
    assertThat(r.getDescription()).endsWith("11-11-2026 10:30");
  }

  @Test
  void elCodigoAndElTextoDeExitoSonConfigurables() {
    // Given
    props.setSuccessCode("OK");
    props.setSuccessText("Hecho el {dateTime}");

    // When
    UpdateOfferResponse r = factory.success();

    // Then
    assertThat(r.getCode()).isEqualTo("OK");
    assertThat(r.getDescription()).isEqualTo("Hecho el 2026/11/11 10:30:45");
  }

  @Test
  void errorLlevaLaFechaElPasoAndLaCausa() {
    // Given
    Throwable causa = new IllegalStateException("sin conexión");

    // When
    UpdateOfferResponse r = factory.error("Envío al EMS", causa);

    // Then
    assertThat(r.getCode()).isEqualTo("ERROR");
    assertThat(r.getDescription())
        .isEqualTo("Error update offer 2026/11/11 10:30:45. Falló en Envío al EMS: sin conexión");
  }

  @Test
  void errorUsaLaCausaMasProfunda() {
    // Given
    Throwable causa =
        new RuntimeException(
            "Error enviando al EMS",
            new RuntimeException(
                "Uncategorized", new java.net.ConnectException("Connection refused")));

    // When
    UpdateOfferResponse r = factory.error("Envío al EMS", causa);

    // Then
    assertThat(r.getDescription()).endsWith("Connection refused");
  }

  @Test
  void errorSiLaCausaNoTieneMensajeUsaElNombreDeSuClase() {
    // Given
    Throwable causa = new NullPointerException();

    // When
    UpdateOfferResponse r = factory.error("Armado del XML para el EMS", causa);

    // Then
    assertThat(r.getDescription()).endsWith("NullPointerException");
  }

  @Test
  void errorSinCausaDejaElDetalleVacioSinFallar() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    UpdateOfferResponse r = factory.error("Validación de supresión", null);

    // Then
    assertThat(r.getCode()).isEqualTo("ERROR");
    assertThat(r.getDescription()).contains("Validación de supresión").doesNotContain("{detail}");
  }

  @Test
  void elCodigoAndElTextoDeErrorSonConfigurables() {
    // Given
    props.setErrorCode("COP_ERR");
    props.setErrorText("{step} falló: {detail} ({dateTime})");

    // When
    UpdateOfferResponse r = factory.error("EMS", new RuntimeException("boom"));

    // Then
    assertThat(r.getCode()).isEqualTo("COP_ERR");
    assertThat(r.getDescription()).isEqualTo("EMS falló: boom (2026/11/11 10:30:45)");
  }

  @Test
  void elTextoSinMarcadoresSeDevuelveTalCual() {
    // Given
    props.setSuccessText("Listo");

    // When / Then
    assertThat(factory.success().getDescription()).isEqualTo("Listo");
  }

  @Test
  void kafkaExitoLlevaLaFechaDeLaZonaEcrm() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When / Then
    assertThat(factory.kafkaSuccessText("Kafka"))
        .isEqualTo("Successfully send offer to Kafka 2026/11/11 10:30:45");
  }

  @Test
  void kafkaDryRunLlevaLaFecha() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When / Then
    assertThat(factory.kafkaDryRunText("Kafka"))
        .isEqualTo("Kafka en dry-run: el mensaje no se publicó 2026/11/11 10:30:45");
  }

  @Test
  void kafkaErrorLlevaLaFechaElPasoAndElDetalle() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When / Then
    assertThat(
            factory.kafkaErrorText(
                "Kafka", "Consulta a la base de datos", "no se encontró la oferta"))
        .isEqualTo(
            "Error send offer to Kafka 2026/11/11 10:30:45. Falló en Consulta a la base de datos:"
                + " no se encontró la oferta");
  }

  @Test
  void kafkaErrorConExcepcionUsaLaCausaMasProfunda() {
    // Given
    Throwable causa = new RuntimeException("envoltorio", new IllegalStateException("broker caído"));

    // When / Then
    assertThat(factory.kafkaErrorText("Kafka", "Publicación en la cola de Kafka", causa))
        .endsWith("broker caído");
  }

  @Test
  void kafkaLosTextosSonConfigurables() {
    // Given
    props.setKafkaSuccessText("Enviado {dateTime}");
    props.setKafkaErrorText("Falló {step}: {detail}");

    // When / Then
    assertThat(factory.kafkaSuccessText("Kafka")).isEqualTo("Enviado 2026/11/11 10:30:45");
    assertThat(factory.kafkaErrorText("Kafka", "X", "Y")).isEqualTo("Falló X: Y");
  }

  private UpdateOfferRequest estatusU() {
    UpdateOfferRequest rq = TestData.request();
    rq.setOfferStatus("U");
    return rq;
  }

  @Test
  void estatusUconCuentaAndTarjetaLaLlaveLasLleva() {
    // Given
    UpdateOfferRequest rq = estatusU();

    // When
    UpdateOfferResponse r = factory.success(rq);

    // Then
    assertThat(r.getCode()).isEqualTo("COP_UPDOF_0");
    assertThat(r.getDescription())
        .isEqualTo(
            "Successfully update offer"
                + " off:mx:CAMP001_WAVE01_12345678_00112233445566_1234567812345678");
  }

  @Test
  void estatusUsoloConCuentaLaLlaveLlevaLaCuenta() {
    // Given
    UpdateOfferRequest rq = estatusU();
    rq.setCardNumber(null);

    // When / Then
    assertThat(factory.success(rq).getDescription())
        .isEqualTo("Successfully update offer off:mx:CAMP001_WAVE01_12345678_00112233445566");
  }

  @Test
  void estatusUsoloConTarjetaLaLlaveLlevaLaTarjeta() {
    // Given
    UpdateOfferRequest rq = estatusU();
    rq.setAccountNumber("");

    // When / Then
    assertThat(factory.success(rq).getDescription())
        .isEqualTo("Successfully update offer off:mx:CAMP001_WAVE01_12345678_1234567812345678");
  }

  @Test
  void estatusUsinCuentaNiTarjetaLaLlaveEsCampanaOlaCliente() {
    // Given
    UpdateOfferRequest rq = estatusU();
    rq.setAccountNumber(null);
    rq.setCardNumber("");

    // When / Then
    assertThat(factory.success(rq).getDescription())
        .isEqualTo("Successfully update offer off:mx:CAMP001_WAVE01_12345678");
  }

  @Test
  void estatusUsinCampaignIdRespondeElCodigo432ConSuTexto() {
    // Given
    UpdateOfferRequest rq = estatusU();
    rq.setCampaignId("");

    // When
    UpdateOfferResponse r = factory.success(rq);

    // Then
    assertThat(r.getCode()).isEqualTo("COP_UPDOF_432");
    assertThat(r.getDescription())
        .isEqualTo("Campaign cmp:  is not present cannot proceed with the Update Offer");
  }

  @Test
  void estatusUconCampaignIdNuloTambienRespondeElCodigo432() {
    // Given
    UpdateOfferRequest rq = estatusU();
    rq.setCampaignId(null);

    // When / Then
    assertThat(factory.success(rq).getCode()).isEqualTo("COP_UPDOF_432");
  }

  @Test
  void estatusUconCampaignIdDeSoloEspaciosCuentaComoConValorComoEnXpath() {
    // Given
    UpdateOfferRequest rq = estatusU();
    rq.setCampaignId(" ");

    // When / Then
    assertThat(factory.success(rq).getCode()).isEqualTo("COP_UPDOF_0");
  }

  @Test
  void estatusUnoLlevaFecha() {
    // Given
    UpdateOfferRequest rq = estatusU();

    // When / Then
    assertThat(factory.success(rq).getDescription()).doesNotContainPattern("\\d{4}/\\d{2}/\\d{2}");
  }

  @Test
  void estatusUnoLlenaControlFieldNiLosCamposOpcionalesComoElMapDataDeBw() {
    // Given
    UpdateOfferRequest rq = estatusU();

    // When
    UpdateOfferResponse r = factory.success(rq);

    // Then
    assertThat(r.getContextType()).isNullOrEmpty();
    assertThat(r.getCustomerReferenceNumber()).isNull();
    assertThat(r.getStartDate()).isNull();
    assertThat(r.getEndDate()).isNull();
    assertThat(r.getSurveyModeCode()).isNull();
  }

  @Test
  void otroEstatusRespondeElExitoGenericoConLaFecha() {
    // Given
    UpdateOfferRequest rq = TestData.request();
    rq.setOfferStatus("H");

    // When
    UpdateOfferResponse r = factory.success(rq);

    // Then
    assertThat(r.getDescription()).isEqualTo("Successfully update offer 2026/11/11 10:30:45");
  }

  @Test
  void conElFormatoDeBwApagadoElEstatusUtambienRespondeElExitoGenerico() {
    // Given
    props.setStatusUBwFormat(false);

    // When
    UpdateOfferResponse r = factory.success(estatusU());

    // Then
    assertThat(r.getDescription()).isEqualTo("Successfully update offer 2026/11/11 10:30:45");
  }

  @Test
  void sinOfertaRespondeElExitoGenerico() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When / Then
    assertThat(factory.success((UpdateOfferRequest) null).getCode()).isEqualTo("COP_UPDOF_0");
  }

  @Test
  void estatusUloscodigosAndTextosSonConfigurables() {
    // Given
    props.setStatusUSuccessCode("OK_U");
    props.setStatusUSuccessText("Hecho {offerKey}");

    // When
    UpdateOfferResponse r = factory.success(estatusU());

    // Then
    assertThat(r.getCode()).isEqualTo("OK_U");
    assertThat(r.getDescription()).startsWith("Hecho off:mx:CAMP001_WAVE01_");
  }

  @Test
  void kafkaDesactivadoDiceQueNoSeEnvioNadaConLaFecha() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When / Then
    assertThat(factory.kafkaDisabledText())
        .isEqualTo("Envío del evento desactivado: no hay destino activo 2026/11/11 10:30:45");
  }

  private UpdateOfferResponse respuestaDelEms() {
    UpdateOfferResponse r = new UpdateOfferResponse();
    r.setCode("COP_UPDOF_0");
    r.setDescription("Successfully update offer off:mx:CAMP001:WAVE01:12345678");
    r.setContextType(
        java.util.List.of(com.banamex.app.dto.ControlFieldDto.builder().contextType("5").build()));
    return r;
  }

  @Test
  void porDefectoElOrigenEsElMicroAndIgnoraLaRespuestaDelEms() {
    // Given
    UpdateOfferRequest rq = TestData.request();

    // When
    UpdateOfferResponse r = factory.success(rq, respuestaDelEms());

    // Then
    assertThat(r.getDescription()).isEqualTo("Successfully update offer 2026/11/11 10:30:45");
    assertThat(r.getContextType()).isNullOrEmpty();
  }

  @Test
  void conOrigenEmsDevuelveLaRespuestaDelEmsTalCualConSuControlField() {
    // Given
    props.setSource("ems");
    UpdateOfferResponse ems = respuestaDelEms();

    // When
    UpdateOfferResponse r = factory.success(TestData.request(), ems);

    // Then
    assertThat(r).isSameAs(ems);
    assertThat(r.getContextType()).hasSize(1);
  }

  @Test
  void conOrigenEmsPeroSinRespuestaDelEmsUsaLaDelMicro() {
    // Given
    props.setSource("ems");

    // When
    UpdateOfferResponse r = factory.success(TestData.request(), null);

    // Then
    assertThat(r.getDescription()).isEqualTo("Successfully update offer 2026/11/11 10:30:45");
  }

  @Test
  void conOrigenEmsSiLaRespuestaDelEmsNoTraeCodigoUsaLaDelMicro() {
    // Given
    props.setSource("ems");
    UpdateOfferResponse sinCodigo = new UpdateOfferResponse();

    // When
    UpdateOfferResponse r = factory.success(TestData.request(), sinCodigo);

    // Then
    assertThat(r.getCode()).isEqualTo("COP_UPDOF_0");
    assertThat(r).isNotSameAs(sinCodigo);
  }

  @Test
  void conOrigenEmsLasOfertasUsiguenElFormatoDeMapDataDeBw() {
    // Given
    props.setSource("ems");
    UpdateOfferRequest rq = TestData.request();
    rq.setOfferStatus("U");

    // When
    UpdateOfferResponse r = factory.success(rq, respuestaDelEms());

    // Then
    assertThat(r.getDescription()).startsWith("Successfully update offer off:mx:CAMP001_WAVE01_");
  }

  @Test
  void elOrigenNoDistingueMayusculas() {
    // Given
    props.setSource("EMS");
    UpdateOfferResponse ems = respuestaDelEms();

    // When / Then
    assertThat(factory.success(TestData.request(), ems)).isSameAs(ems);
  }

  @Test
  void textosDeEnvioPorDestino() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When / Then
    assertThat(factory.kafkaSuccessText("EMS alterno"))
        .isEqualTo("Successfully send offer to EMS alterno 2026/11/11 10:30:45");
    assertThat(factory.kafkaDryRunText("EMS alterno"))
        .isEqualTo("EMS alterno en dry-run: el mensaje no se publicó 2026/11/11 10:30:45");
    assertThat(factory.kafkaErrorText("EMS alterno", "Publicación", "sin red"))
        .isEqualTo(
            "Error send offer to EMS alterno 2026/11/11 10:30:45. Falló en Publicación: sin red");
  }
}
