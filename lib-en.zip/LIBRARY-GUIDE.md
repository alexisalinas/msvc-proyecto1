# chnn-cop-lib-operation-db

Database queries shared by the COP microservices (`com.banamex.cops.app`).

## Classes

| Package | Class | Purpose |
|---|---|---|
| `model` | `CopOfferFulfillment`, `CopSuppressionChannel`, `CopSuppressionOperation` | Result records |
| `natives` | `CopQuery` | Native SQL (text blocks): offer fulfillment, suppressed channels, suppressed operations |
| `repository.consultasnativas` | `CopFulfillmentSuppressionRepository` | `JpaRepository<DOfferpalette, BigDecimal>` that runs the three native queries (`Object[]` rows). `DOfferpalette` only types the repository |
| `service` / `service.impl` | `CopOfferFulfillmentService(Impl)`, `CopSuppressionService(Impl)` | Build the model from the columns, by position |

## How it is registered

The micro registers the services and the JPA repositories (`OfferFulfillmentConfig`):

```java
@Import({CopOfferFulfillmentServiceImpl.class, CopSuppressionServiceImpl.class})
@EnableJpaRepositories(basePackages = "com.banamex.cops.app.repository")
```

- JPA repositories are **not** registered with `@Import`; they need `@EnableJpaRepositories` (and `DOfferpalette` must be in the `@EntityScan`).
- Do not declare the services with `@Bean` methods as well: it creates a second bean and fails with "expected single matching bean but found 2".
- If `CopsDbAutoConfiguration` also has `@EnableJpaRepositories` or imports the services, keep only one of the two.

## Query behavior

| Query | Timeout | Max rows |
|---|---|---|
| Offer fulfillment | 10 s (`@QueryHints`) | 100 |
| Suppressed channels / operations | 30 s (`@QueryHints`) | Set by the caller (0 = no limit) |

The `timeoutSeconds` argument of `CopSuppressionService` is kept for compatibility and is not applied.

## Build

`mvn clean install -DskipTests`, then add the jar to the micro's classpath.
