package com.banamex.cops.app.repository.consultasnativas;

import com.banamex.cops.app.entity.DOfferpalette;
import com.banamex.cops.app.natives.CopQuery;
import java.math.BigDecimal;
import java.util.List;
import javax.persistence.QueryHint;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;

/** Consultas nativas de la librería; cada fila es un {@code Object[]} con las columnas del query. */
public interface CopQueryRepository extends JpaRepository<DOfferpalette, BigDecimal> {

    /**
     * Cumplimiento de una oferta (timeout de 10 s).
     *
     * @param waveKey clave de la ola con su canal
     * @param offerKey clave de la oferta
     * @param page máximo de filas
     * @return filas del query
     */
    @Query(value = CopQuery.FIND_OFFER_FULFILLMENT, nativeQuery = true)
    @QueryHints(@QueryHint(name = "javax.persistence.query.timeout", value = "10000"))
    List<Object[]> findOfferFulfillment(
            @Param("waveKey") String waveKey, @Param("offerKey") String offerKey, Pageable page);

    /**
     * Canales suprimidos (timeout de 30 s).
     *
     * @param page máximo de filas ({@code Pageable.unpaged()} para todas)
     * @return filas del query
     */
    @Query(value = CopQuery.FIND_ALL_CHANNELS, nativeQuery = true)
    @QueryHints(@QueryHint(name = "javax.persistence.query.timeout", value = "30000"))
    List<Object[]> findAllChannels(Pageable page);

    /**
     * Operaciones suprimidas (timeout de 30 s).
     *
     * @param page máximo de filas ({@code Pageable.unpaged()} para todas)
     * @return filas del query
     */
    @Query(value = CopQuery.FIND_ALL_OPERATIONS, nativeQuery = true)
    @QueryHints(@QueryHint(name = "javax.persistence.query.timeout", value = "30000"))
    List<Object[]> findAllOperations(Pageable page);
}
