package com.banamex.cops.app.service.impl;

import com.banamex.cops.app.model.CopOfferFulfillment;
import com.banamex.cops.app.repository.consultasnativas.CopQueryRepository;
import com.banamex.cops.app.service.CopOfferFulfillmentService;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

/** Implementación de {@link CopOfferFulfillmentService}: arma el modelo con las columnas por posición. */
@Service
@RequiredArgsConstructor
public class CopOfferFulfillmentServiceImpl implements CopOfferFulfillmentService {

    static final int MAX_ROWS = 100;
    private final CopQueryRepository repository;

    /** {@inheritDoc} */
    @Override
    public List<CopOfferFulfillment> findByWaveKeyAndOfferKey(String waveKey, String offerKey) {
        return repository.findOfferFulfillment(waveKey, offerKey, PageRequest.of(0, MAX_ROWS)).stream()
                .map(r -> new CopOfferFulfillment(
                        text(r[0]), text(r[1]), text(r[2]), text(r[3]), text(r[4]), text(r[5]),
                        Arrays.stream(r, 6, 106).map(CopOfferFulfillmentServiceImpl::text).toList(),
                        (Timestamp) r[106], (Timestamp) r[107], (Timestamp) r[108], (Timestamp) r[109],
                        text(r[110]), text(r[111]), text(r[112])))
                .toList();
    }

    private static String text(Object value) {
        return Objects.toString(value, null);
    }
}
