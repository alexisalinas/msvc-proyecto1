package com.banamex.cops.app.service.impl;

import com.banamex.cops.app.model.CopSuppressionChannel;
import com.banamex.cops.app.model.CopSuppressionOperation;
import com.banamex.cops.app.repository.consultasnativas.CopQueryRepository;
import com.banamex.cops.app.service.CopSuppressionService;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

/** Implementación de {@link CopSuppressionService}: arma el modelo con las columnas por posición. */
@Service
@RequiredArgsConstructor
public class CopSuppressionServiceImpl implements CopSuppressionService {

    private final CopQueryRepository repository;

    /** {@inheritDoc} */
    @Override
    public List<CopSuppressionChannel> findAllChannels(int timeoutSeconds, int maxRows) {
        return repository.findAllChannels(limit(maxRows)).stream()
                .map(r -> new CopSuppressionChannel(
                        text(r[0]), text(r[1]), text(r[2]), text(r[3]), text(r[4]), text(r[5])))
                .toList();
    }

    /** {@inheritDoc} */
    @Override
    public List<CopSuppressionOperation> findAllOperations(int timeoutSeconds, int maxRows) {
        return repository.findAllOperations(limit(maxRows)).stream()
                .map(r -> new CopSuppressionOperation(text(r[0]), text(r[1]), text(r[2])))
                .toList();
    }

    private static Pageable limit(int maxRows) {
        return maxRows > 0 ? PageRequest.of(0, maxRows) : Pageable.unpaged();
    }

    private static String text(Object value) {
        return Objects.toString(value, null);
    }
}
