package com.banamex.cops.app.service;

import com.banamex.cops.app.model.CopSuppressionChannel;
import com.banamex.cops.app.model.CopSuppressionOperation;
import java.util.List;

/** Servicio de consulta de los datos de supresión (canales y operaciones suprimidas). */
public interface CopSuppressionService {

    /**
     * Todos los canales con su supresión (solo lectura).
     *
     * @param timeoutSeconds se conserva por compatibilidad; el tiempo máximo (30 s) lo fija la consulta del repositorio
     * @param maxRows máximo de filas; 0 = sin límite
     * @return canales con su supresión
     */
    List<CopSuppressionChannel> findAllChannels(int timeoutSeconds, int maxRows);

    /**
     * Todas las operaciones suprimidas por canal (solo lectura).
     *
     * @param timeoutSeconds se conserva por compatibilidad; el tiempo máximo (30 s) lo fija la consulta del repositorio
     * @param maxRows máximo de filas; 0 = sin límite
     * @return operaciones suprimidas
     */
    List<CopSuppressionOperation> findAllOperations(int timeoutSeconds, int maxRows);
}
