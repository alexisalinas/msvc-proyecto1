package com.banamex.app.suppressed;

import static org.assertj.core.api.Assertions.assertThat;

import com.banamex.app.dto.suppression.FilteredSuppressionList;
import com.banamex.app.dto.suppression.FilteredSuppressionResult;
import com.banamex.app.dto.suppression.OperationDetailOutput;
import com.banamex.app.dto.suppression.OperationDetailsDto;
import com.banamex.app.dto.suppression.StartRequest;
import com.banamex.app.dto.suppression.StartRequestParams;
import com.banamex.app.dto.suppression.SuppressedEntitiesListRoot;
import com.banamex.app.dto.suppression.SuppressedEntityDto;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * AJUSTAR: si tu clase del detalle de entrada no se llama OperationDetailsDto o no tiene setters
 * (operationName, reqChannel, operationFlag), cambia ese nombre en este archivo.
 */
class SuppressionCheckServiceTest {

  private final SuppressionCheckService service = new SuppressionCheckService();
  private StartRequest request;

  @BeforeEach
  void setUp() {
    request = pedido("CAT", "MX", "UpdateOffer");
  }

  private StartRequest pedido(String canal, String pais, String operacion) {
    StartRequestParams p = new StartRequestParams();
    p.setRequestingChannel(canal);
    p.setCountryCode(pais);
    p.setCurrentOperationName(operacion);
    StartRequest r = new StartRequest();
    r.setRequestParams(p);
    return r;
  }

  private OperationDetailsDto detalle(String operacion, String canal, String flag) {
    OperationDetailsDto d = new OperationDetailsDto();
    d.setOperationName(operacion);
    d.setReqChannel(canal);
    d.setOperationFlag(flag);
    return d;
  }

  private SuppressedEntityDto entidad(
      String pais,
      String canal,
      String suppFlag,
      String mode,
      String source,
      OperationDetailsDto... detalles) {
    SuppressedEntityDto e = new SuppressedEntityDto();
    e.setCountryCode(pais);
    e.setChannelId(canal);
    e.setSuppressionFlag(suppFlag);
    e.setOperationFlag("Y");
    e.setMode(mode);
    e.setSourceSystem(source);
    e.setOperationDetails(List.of(detalles));
    return e;
  }

  private SuppressedEntitiesListRoot lista(SuppressedEntityDto... entidades) {
    SuppressedEntitiesListRoot l = new SuppressedEntitiesListRoot();
    l.setSuppressedEntities(List.of(entidades));
    return l;
  }

  private SuppressedEntityDto entidadSuprimida() {
    return entidad("MX", "CAT", "Y", "RT", "ECRM", detalle("UpdateOffer", "CAT", "Y"));
  }

  @Test
  void operacionSuprimidaDevuelveIndicadorTrueConCodigoAndTexto() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    FilteredSuppressionList r = service.checkIfSuppressed(request, lista(entidadSuprimida()));

    // Then
    assertThat(r.getResults()).hasSize(1);
    FilteredSuppressionResult res = r.getResults().get(0);
    assertThat(res.getCountryCode()).isEqualTo("MX");
    assertThat(res.getChannelId()).isEqualTo("CAT");
    assertThat(res.getSuppressionFlag()).isEqualTo("Y");
    assertThat(res.getMode()).isEqualTo("RT");
    assertThat(res.getSourceSystem()).isEqualTo("ECRM");
    assertThat(res.getOperationDetails()).hasSize(1);

    OperationDetailOutput d = res.getOperationDetails().get(0);
    assertThat(d.getIndicator()).isEqualTo("true");
    assertThat(d.getResponseCode()).isEqualTo("COP_OPSUP_001");
    assertThat(d.getResponseText())
        .isEqualTo("The UpdateOffer operation is temporarily unavailable");
    assertThat(d.getCountryCode()).isEqualTo("MX");
  }

  @Test
  void canalDeLaEntidadDistintoAlSolicitadoNoCoincide() {
    // Given
    SuppressedEntityDto e =
        entidad("MX", "WEB", "Y", "RT", "ECRM", detalle("UpdateOffer", "CAT", "Y"));

    // When / Then
    assertThat(service.checkIfSuppressed(request, lista(e)).getResults()).isEmpty();
  }

  @Test
  void sinCanalSolicitadoNoCoincideNiLanzaExcepcion() {
    // Given
    StartRequest sinCanal = pedido(null, "MX", "UpdateOffer");

    // When / Then
    assertThat(service.checkIfSuppressed(sinCanal, lista(entidadSuprimida())).getResults())
        .isEmpty();
  }

  @Test
  void paisDistintoNoCoincide() {
    // Given
    SuppressedEntityDto e =
        entidad("CO", "CAT", "Y", "RT", "ECRM", detalle("UpdateOffer", "CAT", "Y"));

    // When / Then
    assertThat(service.checkIfSuppressed(request, lista(e)).getResults()).isEmpty();
  }

  @Test
  void suppressionFlagDistintoDeAndNoCoincide() {
    // Given
    SuppressedEntityDto e =
        entidad("MX", "CAT", "N", "RT", "ECRM", detalle("UpdateOffer", "CAT", "Y"));

    // When / Then
    assertThat(service.checkIfSuppressed(request, lista(e)).getResults()).isEmpty();
  }

  @Test
  void modoDistintoDeRtnoCoincide() {
    // Given
    SuppressedEntityDto e =
        entidad("MX", "CAT", "Y", "BATCH", "ECRM", detalle("UpdateOffer", "CAT", "Y"));

    // When / Then
    assertThat(service.checkIfSuppressed(request, lista(e)).getResults()).isEmpty();
  }

  @Test
  void sistemaDistintoDeEcrmnoCoincide() {
    // Given
    SuppressedEntityDto e =
        entidad("MX", "CAT", "Y", "RT", "OTRO", detalle("UpdateOffer", "CAT", "Y"));

    // When / Then
    assertThat(service.checkIfSuppressed(request, lista(e)).getResults()).isEmpty();
  }

  @Test
  void operacionNoContenidaLaEntidadCoincidePeroSinDetalles() {
    // Given
    SuppressedEntityDto e =
        entidad("MX", "CAT", "Y", "RT", "ECRM", detalle("OtraOperacion", "CAT", "Y"));

    // When
    FilteredSuppressionList r = service.checkIfSuppressed(request, lista(e));

    // Then
    assertThat(r.getResults()).hasSize(1);
    assertThat(r.getResults().get(0).getOperationDetails()).isEmpty();
  }

  @Test
  void operacionContenidaEnElNombreActualCoincide() {

    // When
    // Given
    StartRequest r2 = pedido("CAT", "MX", "UpdateOfferV2");
    FilteredSuppressionList r = service.checkIfSuppressed(r2, lista(entidadSuprimida()));

    // Then
    assertThat(r.getResults().get(0).getOperationDetails()).hasSize(1);
  }

  @Test
  void detalleConOtroCanalOrDeshabilitadoSeDescarta() {
    // Given
    SuppressedEntityDto otroCanal =
        entidad("MX", "CAT", "Y", "RT", "ECRM", detalle("UpdateOffer", "WEB", "Y"));
    SuppressedEntityDto flagN =
        entidad("MX", "CAT", "Y", "RT", "ECRM", detalle("UpdateOffer", "CAT", "N"));

    // When / Then
    assertThat(
            service
                .checkIfSuppressed(request, lista(otroCanal))
                .getResults()
                .get(0)
                .getOperationDetails())
        .isEmpty();
    assertThat(
            service
                .checkIfSuppressed(request, lista(flagN))
                .getResults()
                .get(0)
                .getOperationDetails())
        .isEmpty();
  }

  @Test
  void variasEntidadesSoloPasanLasQueCumplen() {
    // Given
    SuppressedEntityDto otraOperacion =
        entidad("MX", "CAT", "Y", "RT", "ECRM", detalle("Otra", "CAT", "Y"));
    SuppressedEntityDto otroPais =
        entidad("CO", "CAT", "Y", "RT", "ECRM", detalle("UpdateOffer", "CAT", "Y"));

    // When
    FilteredSuppressionList r =
        service.checkIfSuppressed(request, lista(entidadSuprimida(), otroPais, otraOperacion));

    // Then
    assertThat(r.getResults()).hasSize(2);
  }

  @Test
  void listaVaciaDevuelveResultadosVacios() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When / Then
    assertThat(service.checkIfSuppressed(request, lista()).getResults()).isEmpty();
  }
}
