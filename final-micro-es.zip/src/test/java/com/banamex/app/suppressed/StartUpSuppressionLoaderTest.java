package com.banamex.app.suppressed;

import static org.assertj.core.api.Assertions.assertThat;

import com.banamex.app.dto.suppression.OperationDetailsDto;
import com.banamex.app.dto.suppression.SuppressedEntitiesListRoot;
import com.banamex.app.dto.suppression.SuppressedEntityDto;
import com.banamex.cops.app.model.CopSuppressionChannel;
import com.banamex.cops.app.model.CopSuppressionOperation;
import java.util.List;
import org.junit.jupiter.api.Test;

/** Pruebas unitarias de {@code StartUpSuppressionLoader}. */
class StartUpSuppressionLoaderTest {

  private final StartUpSuppressionLoader loader = new StartUpSuppressionLoader();

  private static CopSuppressionChannel canal(String canal, String supresion, String operacion) {
    return new CopSuppressionChannel("MX", "RT", canal, supresion, operacion, "ECRM");
  }

  private static CopSuppressionOperation op(String nombre, String bandera, String canal) {
    return new CopSuppressionOperation(nombre, bandera, canal);
  }

  private SuppressedEntityDto unica(SuppressedEntitiesListRoot r) {
    assertThat(r.getSuppressedEntities()).hasSize(1);
    return r.getSuppressedEntities().get(0);
  }

  @Test
  void supresionNyOperacionNlaEntidadVaSinDetalles() {
    // Given
    List<CopSuppressionOperation> ops = List.of(op("UpdateOffer", "Y", "CAT"));

    // When
    SuppressedEntityDto e = unica(loader.build(List.of(canal("CAT", "N", "N")), ops));

    // Then
    assertThat(e.getOperationDetails()).isEmpty();
  }

  @Test
  void supresionYyOperacionAndSoloLasOperacionesDeEseCanalConLaBanderaFijaEnY() {
    // Given
    List<CopSuppressionOperation> ops =
        List.of(
            op("UpdateOffer", "N", "CAT"),
            op("GetOfferList", "Y", "CAT"),
            op("UpdateOffer", "Y", "WEB"));

    // When
    SuppressedEntityDto e = unica(loader.build(List.of(canal("CAT", "Y", "Y")), ops));

    // Then
    assertThat(e.getOperationDetails())
        .extracting(OperationDetailsDto::getOperationName)
        .containsExactly("UpdateOffer", "GetOfferList");
    assertThat(e.getOperationDetails())
        .extracting(OperationDetailsDto::getOperationFlag)
        .containsOnly("Y");
    assertThat(e.getOperationDetails())
        .extracting(OperationDetailsDto::getReqChannel)
        .containsOnly("CAT");
  }

  @Test
  void supresionYyOperacionAndUnaOperacionSinCanalNoSeIncluye() {
    // Given
    List<CopSuppressionOperation> ops = List.of(op("UpdateOffer", "Y", null));

    // When
    SuppressedEntityDto e = unica(loader.build(List.of(canal("CAT", "Y", "Y")), ops));

    // Then
    assertThat(e.getOperationDetails()).isEmpty();
  }

  @Test
  void supresionYyOperacionNtodasLasOperacionesConSuPropiaBandera() {
    // Given
    List<CopSuppressionOperation> ops =
        List.of(op("UpdateOffer", "Y", "CAT"), op("GetOfferList", "N", "WEB"));

    // When
    SuppressedEntityDto e = unica(loader.build(List.of(canal("CAT", "Y", "N")), ops));

    // Then
    assertThat(e.getOperationDetails()).hasSize(2);
    assertThat(e.getOperationDetails().get(0).getOperationFlag()).isEqualTo("Y");
    assertThat(e.getOperationDetails().get(1).getOperationFlag()).isEqualTo("N");
    assertThat(e.getOperationDetails().get(1).getReqChannel()).isEqualTo("WEB");
  }

  @Test
  void supresionNyOperacionAndEsElOtherwiseSinDetalles() {
    // Given
    List<CopSuppressionOperation> ops = List.of(op("UpdateOffer", "Y", "CAT"));

    // When
    SuppressedEntityDto e = unica(loader.build(List.of(canal("CAT", "N", "Y")), ops));

    // Then
    assertThat(e.getOperationDetails()).isEmpty();
  }

  @Test
  void banderasNulasOrConOtroValorCaenEnElOtherwiseComoEnXpath() {
    // Given
    List<CopSuppressionOperation> ops = List.of(op("UpdateOffer", "Y", "CAT"));
    List<CopSuppressionChannel> canales =
        List.of(
            new CopSuppressionChannel("MX", "RT", "CAT", null, null, "ECRM"),
            new CopSuppressionChannel("MX", "RT", "CAT", "y", "Y", "ECRM"));

    // When
    SuppressedEntitiesListRoot r = loader.build(canales, ops);

    // Then
    assertThat(r.getSuppressedEntities())
        .allSatisfy(e -> assertThat(e.getOperationDetails()).isEmpty());
  }

  @Test
  void copiaLosCamposDelCanalAndElModoSaleDeReqMode() {
    // Given
    CopSuppressionChannel c = new CopSuppressionChannel("MX", "RT", "CAT", "Y", "N", "ECRM");

    // When
    SuppressedEntityDto e = unica(loader.build(List.of(c), List.of()));

    // Then
    assertThat(e.getCountryCode()).isEqualTo("MX");
    assertThat(e.getMode()).isEqualTo("RT");
    assertThat(e.getChannelId()).isEqualTo("CAT");
    assertThat(e.getSuppressionFlag()).isEqualTo("Y");
    assertThat(e.getOperationFlag()).isEqualTo("N");
    assertThat(e.getSourceSystem()).isEqualTo("ECRM");
  }

  @Test
  void elPaisPuedeSerNulo() {
    // Given
    CopSuppressionChannel c = new CopSuppressionChannel(null, "RT", "CAT", "N", "N", "ECRM");

    // When
    SuppressedEntityDto e = unica(loader.build(List.of(c), List.of()));

    // Then
    assertThat(e.getCountryCode()).isNull();
  }

  @Test
  void unaEntidadPorCanalEnElMismoOrden() {
    // Given
    List<CopSuppressionChannel> canales =
        List.of(canal("CAT", "N", "N"), canal("WEB", "Y", "N"), canal("IVR", "N", "Y"));

    // When
    SuppressedEntitiesListRoot r = loader.build(canales, List.of());

    // Then
    assertThat(r.getSuppressedEntities())
        .extracting(SuppressedEntityDto::getChannelId)
        .containsExactly("CAT", "WEB", "IVR");
  }

  @Test
  void sinCanalesLaListaVaVacia() {
    // Given
    // (sin precondiciones propias)

    // When / Then
    assertThat(
            loader.build(List.of(), List.of(op("UpdateOffer", "Y", "CAT"))).getSuppressedEntities())
        .isEmpty();
    assertThat(loader.build(null, null).getSuppressedEntities()).isEmpty();
  }

  @Test
  void sinOperacionesLasEntidadesVanSinDetalles() {
    // Given
    List<CopSuppressionChannel> canales = List.of(canal("CAT", "Y", "Y"), canal("WEB", "Y", "N"));

    // When
    SuppressedEntitiesListRoot r = loader.build(canales, null);

    // Then
    assertThat(r.getSuppressedEntities())
        .allSatisfy(e -> assertThat(e.getOperationDetails()).isEmpty());
  }
}
