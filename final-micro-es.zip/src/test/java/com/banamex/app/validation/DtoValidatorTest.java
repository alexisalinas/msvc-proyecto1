package com.banamex.app.validation;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.banamex.app.dto.suppression.StartRequest;
import com.banamex.app.dto.suppression.StartRequestParams;
import com.banamex.app.dto.suppression.SuppressedEntityDto;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import java.util.Collections;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.ObjectProvider;

/** Pruebas unitarias de {@code DtoValidator}. */
class DtoValidatorTest {

  private DtoValidator validator;

  @BeforeEach
  void setUp() {
    validator = new DtoValidator(Validation.buildDefaultValidatorFactory().getValidator());
  }

  private StartRequest valido() {
    return StartRequest.builder()
        .requestParams(
            StartRequestParams.builder()
                .countryCode("MX")
                .currentOperationName("UpdateOffer")
                .build())
        .build();
  }

  @Test
  void dtoValidoNoTieneViolacionesNiLanzaExcepcion() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When / Then
    assertThat(validator.violations(valido())).isEmpty();
    assertThatCode(() -> validator.validateOrThrow(valido())).doesNotThrowAnyException();
  }

  @Test
  void violationsListaRutaAndMensajeOrdenados() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When / Then
    assertThat(validator.violations(new SuppressedEntityDto()))
        .contains(
            "mode: El campo Mode es obligatorio",
            "sourceSystem: El campo SourceSystem es obligatorio")
        .hasSize(4)
        .isSorted();
  }

  @Test
  void validateOrThrowLanzaIllegalArgumentConElNombreDelDtoAndElDetalle() {
    // Given
    StartRequest malo = StartRequest.builder().requestParams(new StartRequestParams()).build();

    // When / Then
    assertThatThrownBy(() -> validator.validateOrThrow(malo))
        .isInstanceOf(IllegalArgumentException.class)
        .hasMessageStartingWith("Datos inválidos en StartRequest")
        .hasMessageContaining("requestParams.countryCode")
        .hasMessageContaining("requestParams.currentOperationName");
  }

  @Test
  void validaLosElementosAnidados() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When / Then
    assertThat(validator.violations(new StartRequest()))
        .hasSize(1)
        .first()
        .asString()
        .startsWith("requestParams:");
  }

  @SuppressWarnings("unchecked")
  @Test
  void usaElValidatorDeSpringSiExiste() {
    // Given
    ObjectProvider<Validator> provider = mock(ObjectProvider.class);
    Validator spring = mock(Validator.class);
    when(spring.validate(org.mockito.ArgumentMatchers.any())).thenReturn(Collections.emptySet());
    when(provider.getIfAvailable()).thenReturn(spring);

    // When / Then
    new DtoValidator(provider).validateOrThrow(new SuppressedEntityDto());

    verify(spring).validate(org.mockito.ArgumentMatchers.any());
  }

  @SuppressWarnings("unchecked")
  @Test
  void sinValidatorEnSpringUsaUnoPorDefecto() {
    // Given
    ObjectProvider<Validator> provider = mock(ObjectProvider.class);
    when(provider.getIfAvailable()).thenReturn(null);

    // When / Then
    assertThat(new DtoValidator(provider).violations(new SuppressedEntityDto())).hasSize(4);
  }
}
