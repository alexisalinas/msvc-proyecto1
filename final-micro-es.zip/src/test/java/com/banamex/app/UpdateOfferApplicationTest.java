package com.banamex.app;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/** Pruebas unitarias de {@code UpdateOfferApplication}. */
class UpdateOfferApplicationTest {

  @Test
  void escaneaSoloLosBeansDelMicroNoLosDeLaLibreria() {
    // Given
    SpringBootApplication anotacion =
        UpdateOfferApplication.class.getAnnotation(SpringBootApplication.class);

    // When / Then
    assertThat(anotacion.scanBasePackages()).containsExactly("com.banamex.app");
  }
}
