package com.banamex.app.mapper;

import static org.assertj.core.api.Assertions.assertThat;

import com.banamex.app.config.OfferJmsProperties;
import com.banamex.app.dto.UpdateOfferRequest;
import com.banamex.app.dto.timezonevalidation.DateGrpDto;
import com.banamex.app.dto.timezonevalidation.MapRequestResultDto;
import com.banamex.app.dto.timezonevalidation.TimeGrpDto;
import com.banamex.app.testutil.TestData;
import com.fasterxml.jackson.databind.json.JsonMapper;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

/** Pruebas unitarias de {@code OfferEventMapper}. */
class OfferEventMapperTest {

  private OfferJmsProperties props;
  private OfferEventMapper mapper;

  @BeforeEach
  void setUp() {
    props = new OfferJmsProperties();
    props.setCustomerPadding(true);
    props.setCustomerPaddingLength(10);
    props.setCustomerPaddingChar('0');
    mapper = new OfferEventMapper(props, new UserTextParser(JsonMapper.builder().build()));
    ReflectionTestUtils.setField(mapper, "translateTimeZone", false);
    ReflectionTestUtils.setField(mapper, "ecrmTimeZone", "America/Mexico_City");
  }

  private MapRequestResultDto tzResult() {
    MapRequestResultDto tz = new MapRequestResultDto();
    tz.getDateGrp().add(new DateGrpDto("2026-10-25T00:00:00-0600", "", "AppointmentDate"));
    tz.getTimeGrp().add(new TimeGrpDto("10:31:00", "", "AppointmentStartTime"));
    tz.getTimeGrp().add(new TimeGrpDto("11:01:00", "", "AppointmentEndTime"));
    return tz;
  }

  @Test
  void camposObligatoriosSiempreSeEscribenVaciosSiNoHayDato() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    Map<String, String> m = mapper.map(TestData.minimalRequest(), null, null, null, null);

    // Then
    assertThat(m)
        .containsEntry("RequestingChannel", "CAT")
        .containsEntry("CampaignID", "CAMP001")
        .containsEntry("WaveID", "WAVE01");
    for (String k :
        List.of(
            "AccountNO",
            "CardNO",
            "AssignedBy",
            "ApptStartTime",
            "ApptEndTime",
            "ReasonCode",
            "ReasonDescription",
            "Comments",
            "ContactNumber",
            "OfferStatus",
            "SysVersion",
            "OfferSource",
            "UserField1",
            "UserField20",
            "UserField29",
            "OfferAction",
            "GiftCode",
            "GiftConfirmationNO",
            "ContactReference",
            "LVCode",
            "UpdatedBy",
            "UpdateTime",
            "ContactType",
            "ContactInfo",
            "DepartmentName")) {
      assertThat(m).as(k).containsEntry(k, "");
    }
  }

  @Test
  void camposOpcionalesNoSeEscribenSinValor() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    Map<String, String> m = mapper.map(TestData.minimalRequest(), null, null, null, null);

    // Then
    assertThat(m)
        .doesNotContainKeys(
            "AgentID",
            "ApptDate",
            "ApptConfirmation",
            "FulfillmentReferencedNO",
            "ProbabilityAmount",
            "Department",
            "Branch",
            "Priority",
            "Workgroup",
            "ControlField",
            "LocationIndicator",
            "AreaID",
            "DivisionID",
            "RegionID",
            "AgentName",
            "OfferCategory",
            "BranchName",
            "ChannelResponse",
            "Purpose",
            "CustomerEmail",
            "FulfillmentScript",
            "UserField21",
            "UserField100");
  }

  @Test
  void losNombresNuevosSeMapeanAlCampoDelEvento() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    Map<String, String> m =
        mapper.map(TestData.request(), TestData.requestTime(), null, null, null);

    // Then
    assertThat(m)
        .containsEntry("RequestingChannel", "CAT")
        .containsEntry("AccountNO", "00112233445566")
        .containsEntry("CardNO", "1234567812345678")
        .containsEntry("AgentID", "AGENT1")
        .containsEntry("ApptConfirmation", "Y")
        .containsEntry("ContactNumber", "5555555555")
        .containsEntry("ContactInfo", "5555555555")
        .containsEntry("SysVersion", "1.0")
        .containsEntry("OfferAction", "UPD")
        .containsEntry("GiftConfirmationNO", "GC1")
        .containsEntry("FulfillmentReferencedNO", "FT1")
        .containsEntry("ProbabilityAmount", "100.50")
        .containsEntry("Department", "DEP1")
        .containsEntry("Branch", "BR1")
        .containsEntry("ContactReference", "REF123")
        .containsEntry("Priority", "1")
        .containsEntry("Workgroup", "WG1")
        .containsEntry("LVCode", "LV1")
        .containsEntry("AreaID", "AREA1")
        .containsEntry("DivisionID", "DIV1")
        .containsEntry("RegionID", "REG1")
        .containsEntry("AgentName", "Agente Uno")
        .containsEntry("ChannelResponse", "SMS")
        .containsEntry("CustomerEmail", "a@b.com")
        .containsEntry("FulfillmentScript", "SCRIPT1")
        .containsEntry("Purpose", "Proposito");
  }

  @Test
  void controlFieldAndLocationIndicatorSalenDeContextType() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    Map<String, String> m =
        mapper.map(TestData.request(), TestData.requestTime(), null, null, null);

    // Then
    assertThat(m)
        .containsEntry("ControlField", "controlField1")
        .containsEntry("LocationIndicator", "controlField2");
  }

  @Test
  void contextTypeConUnSoloElementoNoEscribeLocationIndicator() {
    // Given
    UpdateOfferRequest r = TestData.request();
    r.setContextType(List.of(r.getContextType().get(0)));

    // When
    Map<String, String> m = mapper.map(r, TestData.requestTime(), null, null, null);

    // Then
    assertThat(m)
        .containsEntry("ControlField", "controlField1")
        .doesNotContainKey("LocationIndicator");
  }

  @Test
  void userFieldsVienenDeUserTextAndSalenCorridos() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    Map<String, String> m =
        mapper.map(TestData.request(), TestData.requestTime(), null, null, null);

    // Then
    assertThat(m)
        .containsEntry("UserField1", "valor 1")
        .containsEntry("UserField2", "valor 2")
        .containsEntry("UserField3", "")
        .containsEntry("UserField30", "valor 30")
        .containsEntry("UserField100", "valor 100")
        .doesNotContainKeys("UserField21", "UserField99");

    List<String> esperado = new ArrayList<>();
    for (int i = 1; i <= 20; i++) {
      esperado.add("UserField" + i);
    }
    esperado.add("UserField29");
    esperado.add("UserField30");
    esperado.add("UserField100");
    List<String> keys = new ArrayList<>(m.keySet());
    int first = keys.indexOf("UserField1");
    int last = keys.indexOf("UserField100");
    assertThat(keys.subList(first, last + 1)).containsExactlyElementsOf(esperado);
  }

  @Test
  void elElementoUserField29SiempreSeEscribe() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    Map<String, String> m = mapper.map(TestData.minimalRequest(), null, null, null, null);

    // Then
    assertThat(m).containsEntry("UserField29", "");
  }

  @Test
  void horasSinZonaHorariaQuitanLosSegundosCuandoVienenTresPartes() {
    // Given
    UpdateOfferRequest r = TestData.request();
    r.setAppointmentStartTime("10:30:00");
    r.setAppointmentEndTime("11:00");

    // When
    Map<String, String> m = mapper.map(r, TestData.requestTime(), null, null, null);

    // Then
    assertThat(m).containsEntry("ApptStartTime", "10:30").containsEntry("ApptEndTime", "11:00");
  }

  @Test
  void fechaSinZonaHorariaSeEnviaTalCual() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    Map<String, String> m =
        mapper.map(TestData.request(), TestData.requestTime(), null, null, null);

    // Then
    assertThat(m).containsEntry("ApptDate", "2026-10-25");
  }

  @Test
  void sinFechaDeCitaNoSeEscribeApptDate() {
    // Given
    UpdateOfferRequest r = TestData.request();
    r.setAppointmentDate("  ");

    // When
    Map<String, String> m = mapper.map(r, TestData.requestTime(), null, null, null);

    // Then
    assertThat(m).doesNotContainKey("ApptDate");
  }

  @Test
  void customerNoConPaddingRellenaAlaIzquierda() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    Map<String, String> m =
        mapper.map(TestData.request(), TestData.requestTime(), null, null, null);

    // Then
    assertThat(m).containsEntry("CustomerNO", "0012345678");
  }

  @Test
  void customerNoSinPaddingQuedaIgual() {
    // Given
    props.setCustomerPadding(false);

    // When
    Map<String, String> m =
        mapper.map(TestData.request(), TestData.requestTime(), null, null, null);

    // Then
    assertThat(m).containsEntry("CustomerNO", "12345678");
  }

  @Test
  void customerNoVacioQuedaVacioAunConPadding() {
    // Given
    UpdateOfferRequest r = TestData.request();
    r.setCustomerId("");

    // When
    Map<String, String> m = mapper.map(r, TestData.requestTime(), null, null, null);

    // Then
    assertThat(m).containsEntry("CustomerNO", "");
  }

  @Test
  void customerNoMasLargoQueLaLongitudNoSeCorta() {
    // Given
    props.setCustomerPaddingLength(4);

    // When
    Map<String, String> m =
        mapper.map(TestData.request(), TestData.requestTime(), null, null, null);

    // Then
    assertThat(m).containsEntry("CustomerNO", "12345678");
  }

  @Test
  void sinZonaHorariaUpdateTimeEsLaFechaDelHeader() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    Map<String, String> m =
        mapper.map(TestData.request(), TestData.requestTime(), null, null, null);

    // Then
    assertThat(m).containsEntry("UpdateTime", "2026-10-26T10:54:55.852");
  }

  @Test
  void conZonaHorariaActivaUsaLosValoresConvertidos() {
    // Given
    ReflectionTestUtils.setField(mapper, "translateTimeZone", true);

    // When
    Map<String, String> m =
        mapper.map(TestData.request(), TestData.requestTime(), null, "COP_TZCOD_000", tzResult());

    // Then
    assertThat(m)
        .containsEntry("ApptDate", "2026-10-25T00:00:00-0600")
        .containsEntry("ApptStartTime", "10:31:00")
        .containsEntry("ApptEndTime", "11:01:00");
    assertThat(m.get("UpdateTime"))
        .matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}([+-]\\d{2}:\\d{2}|Z)");
  }

  @Test
  void conCodigoQueNoTerminaEnCeroNoUsaLaZonaHoraria() {
    // Given
    ReflectionTestUtils.setField(mapper, "translateTimeZone", true);

    // When
    Map<String, String> m =
        mapper.map(TestData.request(), TestData.requestTime(), null, "COP_TZCOD_114", tzResult());

    // Then
    assertThat(m)
        .containsEntry("ApptDate", "2026-10-25")
        .containsEntry("ApptStartTime", "10:30")
        .containsEntry("UpdateTime", "2026-10-26T10:54:55.852");
  }

  @Test
  void conTranslateTimeZoneApagadoNoUsaLaZonaHorariaAunqueElCodigoSeaCorrecto() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    Map<String, String> m =
        mapper.map(TestData.request(), TestData.requestTime(), null, "COP_TZCOD_000", tzResult());

    // Then
    assertThat(m).containsEntry("ApptDate", "2026-10-25").containsEntry("ApptStartTime", "10:30");
  }

  @Test
  void conZonaHorariaActivaPeroSinResultadoUsaLosValoresOriginales() {
    // Given
    ReflectionTestUtils.setField(mapper, "translateTimeZone", true);

    // When
    Map<String, String> m =
        mapper.map(TestData.request(), TestData.requestTime(), null, "COP_TZCOD_000", null);

    // Then
    assertThat(m).containsEntry("ApptDate", "2026-10-25").containsEntry("ApptStartTime", "10:30");
  }

  @Test
  void elOrdenInicialEsElDelMapperDeBw() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    List<String> keys =
        new ArrayList<>(
            mapper.map(TestData.request(), TestData.requestTime(), null, null, null).keySet());

    // Then
    assertThat(keys.subList(0, 8))
        .containsExactly(
            "RequestingChannel",
            "CampaignID",
            "WaveID",
            "AccountNO",
            "CardNO",
            "AssignedBy",
            "AgentID",
            "ApptDate");
    assertThat(keys.indexOf("CustomerNO")).isLessThan(keys.indexOf("UserField1"));
    assertThat(keys.indexOf("UserField100")).isLessThan(keys.indexOf("OfferAction"));
  }

  @Test
  void ningunaClaveSeRepite() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    Map<String, String> m =
        mapper.map(TestData.request(), TestData.requestTime(), null, null, null);

    // Then
    assertThat(new ArrayList<>(m.keySet())).doesNotHaveDuplicates();
  }

  @Test
  void updatedByLlevaElClientIdDelHeader() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    Map<String, String> m =
        mapper.map(TestData.request(), TestData.requestTime(), "client-123", null, null);

    // Then
    assertThat(m.get("UpdatedBy")).isEqualTo("client-123");
  }

  @Test
  void sinClientIdUpdatedByVaVacioPeroElElementoSiSeEscribe() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    Map<String, String> m =
        mapper.map(TestData.request(), TestData.requestTime(), null, null, null);

    // Then
    assertThat(m).containsKey("UpdatedBy");
    assertThat(m.get("UpdatedBy")).isNullOrEmpty();
  }
}
