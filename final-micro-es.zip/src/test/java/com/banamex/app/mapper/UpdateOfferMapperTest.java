package com.banamex.app.mapper;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.banamex.app.dto.UpdateOfferResponse;
import com.banamex.app.dto.timezonevalidation.MapRequestResultDto;
import com.banamex.app.testutil.TestData;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/** Pruebas unitarias de {@code UpdateOfferMapper}. */
@ExtendWith(MockitoExtension.class)
class UpdateOfferMapperTest {

  @Mock UpdateOfferRequestXmlMapper requestXmlMapper;
  @Mock UpdateOfferResponseXmlMapper responseXmlMapper;
  @InjectMocks UpdateOfferMapper mapper;

  @Test
  void toEmsXmlDelegaEnElMapperDeRequest() {
    // Given
    var rq = TestData.request();
    var requestTime = TestData.requestTime();
    var tz = new MapRequestResultDto();
    when(requestXmlMapper.toEmsXml(rq, requestTime, "client-1", "COP_TZCOD_000", tz))
        .thenReturn("<xml/>");

    // When / Then
    assertThat(mapper.toEmsXml(rq, requestTime, "client-1", "COP_TZCOD_000", tz))
        .isEqualTo("<xml/>");
  }

  @Test
  void toRestResponseDelegaEnElMapperDeRespuesta() {
    // Given
    UpdateOfferResponse rs = new UpdateOfferResponse();
    when(responseXmlMapper.fromReply("<r/>")).thenReturn(rs);

    // When / Then
    assertThat(mapper.toRestResponse("<r/>")).isSameAs(rs);
  }

  @Test
  void toRestResponsesDelegaEnElMapperDeRespuesta() {
    // Given
    List<UpdateOfferResponse> lista = List.of(new UpdateOfferResponse(), new UpdateOfferResponse());
    when(responseXmlMapper.fromReplies("<x/>")).thenReturn(lista);

    // When / Then
    assertThat(mapper.toRestResponses("<x/>")).isSameAs(lista);
    verify(responseXmlMapper).fromReplies("<x/>");
  }

  @Test
  void emsPropertiesDelegaEnElMapperDelXml() {
    // Given
    var rq = TestData.request();
    var requestTime = TestData.requestTime();
    var tz = new MapRequestResultDto();
    var esperadas = java.util.Map.of("_nm_", "UpdateOffer");
    when(requestXmlMapper.toEmsProperties(rq, requestTime, "client-1", "COP_TZCOD_000", tz))
        .thenReturn(esperadas);

    // When / Then
    assertThat(mapper.toEmsProperties(rq, requestTime, "client-1", "COP_TZCOD_000", tz))
        .isSameAs(esperadas);
  }
}
