package com.banamex.app.service.timezonevalidation;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.banamex.app.dto.timezonevalidation.DateGrpDto;
import com.banamex.app.dto.timezonevalidation.DateTimeGrpDto;
import com.banamex.app.dto.timezonevalidation.MapRequestResultDto;
import com.banamex.app.dto.timezonevalidation.TimeGrpDto;
import com.banamex.app.dto.timezonevalidation.TimeZoneValidationResult;
import com.banamex.app.dto.timezonevalidation.TimeZoneValidationStartDto;
import com.banamex.app.dto.timezonevalidation.TzFormatsDto;
import com.banamex.app.dto.timezonevalidation.TzLookUpDto;
import com.banamex.app.dto.timezonevalidation.ValueItemDto;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

/** Pruebas unitarias de {@code TimeZoneValidationService}. */
@ExtendWith(MockitoExtension.class)
class TimeZoneValidationServiceTest {

  @Mock TimeZoneLookupClient lookupClient;
  @Mock TimeZoneMapRequest mapRequest;

  private TimeZoneValidationService service;
  private final List<ValueItemDto> dates =
      List.of(new ValueItemDto("2026-10-25", "AppointmentDate"));

  @BeforeEach
  void setUp() {
    service = new TimeZoneValidationService(new InitTz(), lookupClient, mapRequest);
    ReflectionTestUtils.setField(service, "invalidCode", "COP_TZCOD_101");
  }

  private TzLookUpDto fila() {
    TzLookUpDto l = new TzLookUpDto();
    l.setSystemName("COPS");
    l.setMode("RT");
    l.setType("Request");
    l.setTimeOffset("-05:00");
    l.setDateFormat("yyyy-MM-dd");
    return l;
  }

  @Test
  void sinConfiguracionEnLaBddevuelve114() {
    // Given
    when(lookupClient.find("COPS", "RT", "Request")).thenReturn(List.of());

    // When
    TimeZoneValidationResult r =
        service.validate("COPS", "RT", "Request", dates, List.of(), List.of());

    // Then
    assertThat(r.getResponseCode()).isEqualTo("COP_TZCOD_114");
    assertThat(r.getResponseText()).isEqualTo("TimeZone not configured");
    assertThat(r.getFormats()).isNotNull();
    assertThat(r.getFormats().getTimeZoneOffset()).isEmpty();
    assertThat(r.getFormats().getDateFormat()).isEmpty();
    assertThat(r.getFormats().getTimeFormat()).isEmpty();
    assertThat(r.getFormats().getDateTimeFormat()).isEmpty();
    assertThat(r.getFormats().getTimeZone()).isEmpty();
    assertThat(r.getMapResult().getDateGrp()).isEmpty();
    verify(mapRequest, never()).map(any(), any(), any(), any(), any());
  }

  @Test
  void consultaNulaDeLaBdtambienEs114() {
    // Given
    when(lookupClient.find("COPS", "RT", "Request")).thenReturn(null);

    // When / Then
    assertThat(
            service
                .validate("COPS", "RT", "Request", dates, List.of(), List.of())
                .getResponseCode())
        .isEqualTo("COP_TZCOD_114");
  }

  @Test
  void conConfiguracionAndFechasValidasDevuelve000() {
    // Given
    when(lookupClient.find("COPS", "RT", "Request")).thenReturn(List.of(fila()));
    MapRequestResultDto ok = new MapRequestResultDto();
    ok.getDateGrp().add(new DateGrpDto("2026-10-25T00:00:00-0600", "", "AppointmentDate"));
    when(mapRequest.map(eq("Request"), any(TzFormatsDto.class), eq(dates), any(), any()))
        .thenReturn(ok);

    // When
    TimeZoneValidationResult r =
        service.validate("COPS", "RT", "Request", dates, List.of(), List.of());

    // Then
    assertThat(r.getResponseCode()).isEqualTo("COP_TZCOD_000");
    assertThat(r.getResponseText()).isEqualTo("Success");
    assertThat(r.getMapResult()).isSameAs(ok);
    assertThat(r.getFormats().getTimeZoneOffset()).isEqualTo("-05:00");
  }

  @Test
  void fechaInvalidaDevuelveElCodigoDeInvalido() {
    // Given
    when(lookupClient.find("COPS", "RT", "Request")).thenReturn(List.of(fila()));
    MapRequestResultDto malo = new MapRequestResultDto();
    malo.getDateGrp().add(new DateGrpDto("xx", "Invalid TimeZone", null));
    when(mapRequest.map(any(), any(), any(), any(), any())).thenReturn(malo);

    // When
    TimeZoneValidationResult r =
        service.validate("COPS", "RT", "Request", dates, List.of(), List.of());

    // Then
    assertThat(r.getResponseCode()).isEqualTo("COP_TZCOD_101");
    assertThat(r.getResponseText()).isEqualTo("Invalid TimeZone");
  }

  @Test
  void horaInvalidaDevuelveElCodigoDeInvalido() {
    // Given
    when(lookupClient.find(any(), any(), any())).thenReturn(List.of(fila()));
    MapRequestResultDto malo = new MapRequestResultDto();
    malo.getTimeGrp().add(new TimeGrpDto("99:99", "Invalid TimeZone", null));
    when(mapRequest.map(any(), any(), any(), any(), any())).thenReturn(malo);

    // When / Then
    assertThat(
            service
                .validate("COPS", "RT", "Request", List.of(), List.of(), List.of())
                .getResponseCode())
        .isEqualTo("COP_TZCOD_101");
  }

  @Test
  void fechaHoraInvalidaDevuelveElCodigoDeInvalido() {
    // Given
    when(lookupClient.find(any(), any(), any())).thenReturn(List.of(fila()));
    MapRequestResultDto malo = new MapRequestResultDto();
    malo.getDateTimeGrp().add(new DateTimeGrpDto("zz", "Invalid TimeZone", null));
    when(mapRequest.map(any(), any(), any(), any(), any())).thenReturn(malo);

    // When / Then
    assertThat(
            service
                .validate("COPS", "RT", "Request", List.of(), List.of(), List.of())
                .getResponseCode())
        .isEqualTo("COP_TZCOD_101");
  }

  @Test
  void laConfiguracionSeGuardaEnCacheLaBdsoloSeConsultaUnaVez() {
    // Given
    when(lookupClient.find("COPS", "RT", "Request")).thenReturn(List.of(fila()));
    when(mapRequest.map(any(), any(), any(), any(), any())).thenReturn(new MapRequestResultDto());

    // When
    service.validate("COPS", "RT", "Request", dates, List.of(), List.of());
    service.validate("COPS", "RT", "Request", dates, List.of(), List.of());

    // Then
    verify(lookupClient, times(1)).find("COPS", "RT", "Request");
  }

  @Test
  void sinConfiguracionLaBdseVuelveAconsultarEnLaSiguienteLlamada() {
    // Given
    when(lookupClient.find("COPS", "RT", "Request")).thenReturn(List.of());

    // When
    service.validate("COPS", "RT", "Request", dates, List.of(), List.of());
    service.validate("COPS", "RT", "Request", dates, List.of(), List.of());

    // Then
    verify(lookupClient, times(2)).find("COPS", "RT", "Request");
  }

  @Test
  void elCodigoDeInvalidoEsConfigurable() {
    // Given
    ReflectionTestUtils.setField(service, "invalidCode", "COP_TZCOD_999");
    when(lookupClient.find(any(), any(), any())).thenReturn(List.of(fila()));
    MapRequestResultDto malo = new MapRequestResultDto();
    malo.getDateGrp().add(new DateGrpDto("xx", "Invalid TimeZone", null));
    when(mapRequest.map(any(), any(), any(), any(), any())).thenReturn(malo);

    // When / Then
    assertThat(
            service
                .validate("COPS", "RT", "Request", dates, List.of(), List.of())
                .getResponseCode())
        .isEqualTo("COP_TZCOD_999");
  }

  @Test
  void validateConElNodoStartEquivaleAlosParametrosSueltos() {
    // Given
    when(lookupClient.find("COPS", "RT", "Request")).thenReturn(List.of());

    TimeZoneValidationStartDto start =
        TimeZoneValidationStartDto.builder()
            .system("COPS")
            .sysMode("RT")
            .type("Request")
            .date(dates)
            .build();

    // When
    TimeZoneValidationResult r = service.validate(start);

    // Then
    assertThat(r.getResponseCode()).isEqualTo("COP_TZCOD_114");
    verify(lookupClient).find("COPS", "RT", "Request");
  }
}
