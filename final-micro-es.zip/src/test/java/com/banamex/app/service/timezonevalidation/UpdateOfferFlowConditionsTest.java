package com.banamex.app.service.timezonevalidation;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

/** Pruebas unitarias de {@code UpdateOfferFlowConditions}. */
class UpdateOfferFlowConditionsTest {

  @Test
  void translateTimeZoneSoloEsTrueConLaPalabraTrueSinImportarMayusculas() {
    // Given
    // (sin precondiciones)

    // When / Then
    assertThat(UpdateOfferFlowConditions.translateTimeZone("true")).isTrue();
    assertThat(UpdateOfferFlowConditions.translateTimeZone("TRUE")).isTrue();
    assertThat(UpdateOfferFlowConditions.translateTimeZone("True")).isTrue();
    assertThat(UpdateOfferFlowConditions.translateTimeZone("false")).isFalse();
    assertThat(UpdateOfferFlowConditions.translateTimeZone("")).isFalse();
    assertThat(UpdateOfferFlowConditions.translateTimeZone(null)).isFalse();
  }

  @Test
  void continueToSuppressionContinuaSiElCodigoTerminaEnCero() {
    // Given
    // (sin precondiciones)

    // When / Then
    assertThat(UpdateOfferFlowConditions.continueToSuppression("COP_TZCOD_000")).isTrue();
    assertThat(UpdateOfferFlowConditions.continueToSuppression("COP_TZCOD_110")).isTrue();
    assertThat(UpdateOfferFlowConditions.continueToSuppression("0")).isTrue();
  }

  @Test
  void continueToSuppressionContinuaConElCodigo114() {
    // Given
    // (sin precondiciones)

    // When / Then
    assertThat(UpdateOfferFlowConditions.continueToSuppression("COP_TZCOD_114")).isTrue();
  }

  @Test
  void continueToSuppressionSeDetieneConCualquierOtroCodigo() {
    // Given
    // (sin precondiciones)

    // When / Then
    assertThat(UpdateOfferFlowConditions.continueToSuppression("COP_TZCOD_101")).isFalse();
    assertThat(UpdateOfferFlowConditions.continueToSuppression("COP_TZCOD_113")).isFalse();
    assertThat(UpdateOfferFlowConditions.continueToSuppression("ERROR")).isFalse();
  }

  @Test
  void continueToSuppressionNuloOrVacioSeDetiene() {
    // Given
    // (sin precondiciones)

    // When / Then
    assertThat(UpdateOfferFlowConditions.continueToSuppression(null)).isFalse();
    assertThat(UpdateOfferFlowConditions.continueToSuppression("")).isFalse();
  }
}
