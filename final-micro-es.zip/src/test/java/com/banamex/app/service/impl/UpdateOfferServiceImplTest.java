package com.banamex.app.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import com.banamex.app.audit.AuditLogService;
import com.banamex.app.dto.UpdateOfferHeaders;
import com.banamex.app.dto.UpdateOfferRequest;
import com.banamex.app.dto.UpdateOfferResponse;
import com.banamex.app.dto.suppression.FilteredSuppressionList;
import com.banamex.app.dto.suppression.FilteredSuppressionResult;
import com.banamex.app.dto.suppression.OperationDetailOutput;
import com.banamex.app.dto.suppression.StartRequest;
import com.banamex.app.dto.timezonevalidation.MapRequestResultDto;
import com.banamex.app.dto.timezonevalidation.TimeZoneValidationResult;
import com.banamex.app.dto.timezonevalidation.TimeZoneValidationStartDto;
import com.banamex.app.dto.timezonevalidation.ValueItemDto;
import com.banamex.app.kafka.KafkaSenderDashboard;
import com.banamex.app.kafka.OfferInput;
import com.banamex.app.mapper.UpdateOfferMapper;
import com.banamex.app.sender.EmsSender;
import com.banamex.app.sender.OfferFulfillmentEmsSender;
import com.banamex.app.service.UpdateOfferResponseFactory;
import com.banamex.app.service.timezonevalidation.TimeZoneValidationService;
import com.banamex.app.suppressed.PerformSuppressionCheckService;
import com.banamex.app.testutil.TestData;
import com.banamex.app.validation.DtoValidator;
import java.time.LocalDateTime;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.test.util.ReflectionTestUtils;

/** Pruebas unitarias de {@code UpdateOfferServiceImpl}. */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class UpdateOfferServiceImplTest {

  private static final java.util.Map<String, String> PROPIEDADES =
      java.util.Map.of("_nm_", "UpdateOffer", "CampaignID", "CAMP001");

  @Mock EmsSender emsSender;
  @Mock UpdateOfferMapper updateOfferMapper;
  @Mock AuditLogService auditLogService;
  @Mock PerformSuppressionCheckService suppressionCheckService;
  @Mock TimeZoneValidationService timeZoneValidationService;
  @Mock KafkaSenderDashboard kafkaSenderDashboard;
  @Mock OfferFulfillmentEmsSender offerFulfillmentEmsSender;
  @Mock DtoValidator dtoValidator;
  @Mock UpdateOfferResponseFactory responses;
  @InjectMocks UpdateOfferServiceImpl service;

  private final UpdateOfferHeaders headers = TestData.headers();
  private UpdateOfferResponse emsResponse;
  private UpdateOfferResponse exito;
  private final OfferInput kafkaInput = new OfferInput();

  @BeforeEach
  void setUp() {
    ReflectionTestUtils.setField(service, "translateTimeZone", false);
    ReflectionTestUtils.setField(service, "tzSysMode", "RealTime");

    emsResponse = new UpdateOfferResponse();
    emsResponse.setCode("000");
    emsResponse.setDescription("OK");

    exito = new UpdateOfferResponse();
    exito.setCode("COP_UPDOF_0");
    exito.setDescription("Successfully update offer 2026/11/11 10:00:00");
    when(responses.success(any(UpdateOfferRequest.class), any())).thenReturn(exito);
    when(responses.error(anyString(), any(Throwable.class)))
        .thenAnswer(
            inv -> {
              UpdateOfferResponse r = new UpdateOfferResponse();
              r.setCode("ERROR");
              Throwable causa = inv.getArgument(1);
              r.setDescription(inv.getArgument(0) + ": " + causa.getMessage());
              return r;
            });

    when(updateOfferMapper.toEmsXml(any(), any(), any(), any(), any())).thenReturn("<ems/>");
    when(updateOfferMapper.toEmsProperties(any(), any(), any(), any(), any()))
        .thenReturn(PROPIEDADES);
    when(emsSender.send(eq("<ems/>"), any())).thenReturn("<reply/>");
    when(updateOfferMapper.toRestResponse("<reply/>")).thenReturn(emsResponse);
    when(suppressionCheckService.perform(any())).thenReturn(sinSupresion());
    when(offerFulfillmentEmsSender.isEnabled()).thenReturn(true);
    when(kafkaSenderDashboard.build(any(), any(), any(), any())).thenReturn(kafkaInput);
  }

  private FilteredSuppressionList sinSupresion() {
    FilteredSuppressionList l = new FilteredSuppressionList();
    l.setResults(List.of());
    return l;
  }

  private FilteredSuppressionList conSupresion(String indicator) {
    OperationDetailOutput d = new OperationDetailOutput();
    d.setIndicator(indicator);
    d.setResponseCode("COP_OPSUP_001");
    d.setResponseText("The UpdateOffer operation is temporarily unavailable");
    FilteredSuppressionResult r = new FilteredSuppressionResult();
    r.setOperationDetails(List.of(d));
    FilteredSuppressionList l = new FilteredSuppressionList();
    l.setResults(List.of(r));
    return l;
  }

  @Test
  void flujoNormalEnviaAlEmsAndDevuelveLaRespuestaDeExitoQueArmaElMicro() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    List<UpdateOfferResponse> out = service.updateOffer(List.of(TestData.request()), headers);

    // Then
    assertThat(out).containsExactly(exito);
    verify(emsSender).send(eq("<ems/>"), any());
  }

  @Test
  void flujoNormalEscribeLogDeRequestAntesAndLogDeResponseDespues() {
    // Given
    List<UpdateOfferRequest> requests = List.of(TestData.request());

    // When
    service.updateOffer(requests, headers);

    // Then
    InOrder o = inOrder(auditLogService, emsSender);
    o.verify(auditLogService).logRequest(headers, requests);
    o.verify(emsSender).send(eq("<ems/>"), any());
    o.verify(auditLogService).logResponse(headers, List.of(exito));
  }

  @Test
  void conVariasOfertasElLogDeRequestAndDeResponseSeEscribeUnaSolaVezPorLlamada() {
    // Given
    List<UpdateOfferRequest> requests = List.of(TestData.request(), TestData.request());

    // When
    List<UpdateOfferResponse> out = service.updateOffer(requests, headers);

    // Then
    verify(auditLogService, org.mockito.Mockito.times(1)).logRequest(headers, requests);
    verify(auditLogService, org.mockito.Mockito.times(1)).logResponse(headers, out);
    assertThat(out).hasSize(2);
  }

  @Test
  void sinZonaHorariaNoLlamaAlaValidacionAndPasaNullAlMapper() {
    // Given
    UpdateOfferRequest rq = TestData.request();

    // When
    service.updateOffer(List.of(rq), headers);

    // Then
    verifyNoInteractions(timeZoneValidationService);
    verify(updateOfferMapper)
        .toEmsXml(
            eq(rq),
            any(LocalDateTime.class),
            eq("client-123"),
            org.mockito.ArgumentMatchers.isNull(),
            org.mockito.ArgumentMatchers.isNull());
  }

  @Test
  void variasPeticionesDevuelveUnaRespuestaPorCada() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    List<UpdateOfferResponse> out =
        service.updateOffer(List.of(TestData.request(), TestData.request()), headers);

    // Then
    assertThat(out).hasSize(2);
    verify(emsSender, org.mockito.Mockito.times(2)).send(eq("<ems/>"), any());
  }

  @Test
  void operacionSuprimidaRespondeSinLlamarAlEms() {
    // Given
    when(suppressionCheckService.perform(any())).thenReturn(conSupresion("true"));

    // When
    List<UpdateOfferResponse> out = service.updateOffer(List.of(TestData.request()), headers);

    // Then
    assertThat(out.get(0).getCode()).isEqualTo("COP_OPSUP_001");
    assertThat(out.get(0).getDescription()).contains("temporarily unavailable");
    verifyNoInteractions(emsSender);
    verify(auditLogService)
        .logResponse(
            eq(headers),
            org.mockito.ArgumentMatchers.<List<UpdateOfferResponse>>argThat(
                l -> l.size() == 1 && "COP_OPSUP_001".equals(l.get(0).getCode())));
  }

  @Test
  void indicadorFalseNoSuprime() {
    // Given
    when(suppressionCheckService.perform(any())).thenReturn(conSupresion("false"));

    // When
    List<UpdateOfferResponse> out = service.updateOffer(List.of(TestData.request()), headers);

    // Then
    assertThat(out.get(0)).isSameAs(exito);
  }

  @Test
  void laSupresionSeConsultaConCanalPaisAndNombreDeOperacion() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    service.updateOffer(List.of(TestData.request()), headers);

    // Then
    ArgumentCaptor<StartRequest> c = ArgumentCaptor.forClass(StartRequest.class);
    verify(suppressionCheckService).perform(c.capture());
    assertThat(c.getValue().getRequestParams().getRequestingChannel()).isEqualTo("CAT");
    assertThat(c.getValue().getRequestParams().getCountryCode()).isEqualTo("MX");
    assertThat(c.getValue().getRequestParams().getCurrentOperationName()).isEqualTo("UpdateOffer");
  }

  @Test
  void supresionNulaOrSinResultadosNoSuprime() {
    // Given
    when(suppressionCheckService.perform(any())).thenReturn(null);

    // When / Then
    assertThat(service.updateOffer(List.of(TestData.request()), headers).get(0)).isSameAs(exito);

    FilteredSuppressionList sinLista = new FilteredSuppressionList();
    sinLista.setResults(null);
    when(suppressionCheckService.perform(any())).thenReturn(sinLista);
    assertThat(service.updateOffer(List.of(TestData.request()), headers).get(0)).isSameAs(exito);
  }

  private TimeZoneValidationResult validacion(String code, String text) {
    TimeZoneValidationResult v = new TimeZoneValidationResult();
    v.setResponseCode(code);
    v.setResponseText(text);
    v.setMapResult(new MapRequestResultDto());
    return v;
  }

  @Test
  void zonaHorariaInvalidaRespondeConElCodigoDeLaValidacionAndNoLlamaAlEms() {
    // Given
    ReflectionTestUtils.setField(service, "translateTimeZone", true);
    when(timeZoneValidationService.validate(any(TimeZoneValidationStartDto.class)))
        .thenReturn(validacion("COP_TZCOD_115", "Invalid TimeZone"));

    // When
    UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

    // Then
    assertThat(out.getCode()).isEqualTo("COP_TZCOD_115");
    assertThat(out.getDescription()).isEqualTo("Invalid TimeZone");
    assertThat(out.getContextType()).isNullOrEmpty();
    verifyNoInteractions(emsSender, suppressionCheckService);
  }

  @Test
  void zonaHorariaCorrectaPasaCodigoAndResultadoAlMapper() {
    // Given
    ReflectionTestUtils.setField(service, "translateTimeZone", true);
    TimeZoneValidationResult v = validacion("COP_TZCOD_000", "Success");
    when(timeZoneValidationService.validate(any(TimeZoneValidationStartDto.class))).thenReturn(v);
    UpdateOfferRequest rq = TestData.request();

    // When
    service.updateOffer(List.of(rq), headers);

    // Then
    verify(updateOfferMapper)
        .toEmsXml(
            eq(rq),
            any(LocalDateTime.class),
            eq("client-123"),
            eq("COP_TZCOD_000"),
            eq(v.getMapResult()));
  }

  @Test
  void zonaHorariaNoConfigurada114ContinuaConElFlujo() {
    // Given
    ReflectionTestUtils.setField(service, "translateTimeZone", true);
    when(timeZoneValidationService.validate(any(TimeZoneValidationStartDto.class)))
        .thenReturn(validacion("COP_TZCOD_114", "TimeZone not configured"));

    // When
    UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

    // Then
    assertThat(out).isSameAs(exito);
    verify(emsSender).send(eq("<ems/>"), any());
  }

  @Test
  void zonaHorariaEnviaElNodoStartConFechaAndAmbasHorasConSusNombres() {
    // Given
    ReflectionTestUtils.setField(service, "translateTimeZone", true);
    when(timeZoneValidationService.validate(any(TimeZoneValidationStartDto.class)))
        .thenReturn(validacion("COP_TZCOD_000", "Success"));

    // When
    service.updateOffer(List.of(TestData.request()), headers);

    // Then
    ArgumentCaptor<TimeZoneValidationStartDto> c =
        ArgumentCaptor.forClass(TimeZoneValidationStartDto.class);
    verify(timeZoneValidationService).validate(c.capture());
    TimeZoneValidationStartDto start = c.getValue();

    assertThat(start.getSystem()).isEqualTo(headers.getChannelId());
    assertThat(start.getSysMode()).isEqualTo("RealTime");
    assertThat(start.getType()).isEqualTo("Request");
    assertThat(start.getDateTime()).isEmpty();
    assertThat(start.getDate())
        .extracting(ValueItemDto::getName, ValueItemDto::getValue)
        .containsExactly(org.assertj.core.groups.Tuple.tuple("AppointmentDate", "2026-10-25"));
    assertThat(start.getTime())
        .extracting(ValueItemDto::getName, ValueItemDto::getValue)
        .containsExactly(
            org.assertj.core.groups.Tuple.tuple("AppointmentStartTime", "10:30:00"),
            org.assertj.core.groups.Tuple.tuple("AppointmentEndTime", "11:00:00"));
    verify(dtoValidator).validateOrThrow(start);
  }

  @Test
  void zonaHorariaSinFechaNiHorasEnviaListasVacias() {
    // Given
    ReflectionTestUtils.setField(service, "translateTimeZone", true);
    when(timeZoneValidationService.validate(any(TimeZoneValidationStartDto.class)))
        .thenReturn(validacion("COP_TZCOD_000", "Success"));

    // When
    service.updateOffer(List.of(TestData.minimalRequest()), headers);

    // Then
    ArgumentCaptor<TimeZoneValidationStartDto> c =
        ArgumentCaptor.forClass(TimeZoneValidationStartDto.class);
    verify(timeZoneValidationService).validate(c.capture());
    assertThat(c.getValue().getDate()).isEmpty();
    assertThat(c.getValue().getTime()).isEmpty();
  }

  @Test
  void errorDelEmsDevuelveRespuestaErroryaunAsiEscribeElLogDeRespuesta() {
    // Given
    when(emsSender.send(eq("<ems/>"), any()))
        .thenThrow(new RuntimeException("Timeout esperando respuesta del EMS"));

    // When
    UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

    // Then
    assertThat(out.getCode()).isEqualTo("ERROR");
    assertThat(out.getDescription()).contains("Timeout esperando respuesta del EMS");
    verify(auditLogService)
        .logResponse(
            eq(headers),
            org.mockito.ArgumentMatchers.<List<UpdateOfferResponse>>argThat(
                l -> l.size() == 1 && "ERROR".equals(l.get(0).getCode())));
  }

  @Test
  void siNoSePuedeLeerLaRespuestaDelEmsNoEsErrorAndKafkaSeLlamaSinLaRespuesta() {
    // Given
    UpdateOfferRequest rq = TestData.request();
    when(updateOfferMapper.toRestResponse("<reply/>"))
        .thenThrow(new IllegalStateException("respuesta ilegible"));

    // When
    UpdateOfferResponse out = service.updateOffer(List.of(rq), headers).get(0);

    // Then
    assertThat(out).isSameAs(exito);
    verify(kafkaSenderDashboard).build(eq(rq), eq(headers), any(LocalDateTime.class), isNull());
  }

  @Test
  void siElJmsNoContestaEsExitoAndKafkaSeLlamaSinLaRespuesta() {
    // Given
    UpdateOfferRequest rq = TestData.request();
    when(emsSender.send(eq("<ems/>"), any())).thenReturn(null);

    // When
    UpdateOfferResponse out = service.updateOffer(List.of(rq), headers).get(0);

    // Then
    assertThat(out).isSameAs(exito);
    verify(updateOfferMapper, never()).toRestResponse(any());
    verify(kafkaSenderDashboard).build(eq(rq), eq(headers), any(LocalDateTime.class), isNull());
  }

  @Test
  void siElEmsContestaUnErrorDeNegocioElMicroRespondeExitoAndKafkaRecibeElCodigoDelEms() {
    // Given
    UpdateOfferRequest rq = TestData.request();
    emsResponse.setCode("COP_UPDOF_1");
    emsResponse.setDescription("campaña no existe");

    // When
    UpdateOfferResponse out = service.updateOffer(List.of(rq), headers).get(0);

    // Then
    assertThat(out).isSameAs(exito);
    verify(kafkaSenderDashboard)
        .build(eq(rq), eq(headers), any(LocalDateTime.class), eq(emsResponse));
  }

  @Test
  void siFallaElEnvioAlEmsRespondeErrorIndicandoElPaso() {
    // Given
    when(emsSender.send(eq("<ems/>"), any())).thenThrow(new RuntimeException("sin conexión"));

    // When
    UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

    // Then
    verify(responses).error(eq("Envío al EMS"), any(Throwable.class));
    assertThat(out.getCode()).isEqualTo("ERROR");
    assertThat(out.getDescription()).contains("Envío al EMS").contains("sin conexión");
  }

  @Test
  void siFallaElArmadoDelXmlRespondeErrorIndicandoElPaso() {
    // Given
    when(updateOfferMapper.toEmsXml(any(), any(), any(), any(), any()))
        .thenThrow(new IllegalStateException("campo inválido"));

    // When
    UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

    // Then
    verify(responses).error(eq("Armado del XML para el EMS"), any(Throwable.class));
    assertThat(out.getDescription()).contains("campo inválido");
    verifyNoInteractions(emsSender);
  }

  @Test
  void siFallaLaSupresionRespondeErrorIndicandoElPaso() {
    // Given
    when(suppressionCheckService.perform(any())).thenThrow(new IllegalStateException("sin lista"));

    // When
    UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

    // Then
    verify(responses).error(eq("Validación de supresión"), any(Throwable.class));
    assertThat(out.getDescription()).contains("sin lista");
    verifyNoInteractions(emsSender);
  }

  @Test
  void siFallaLaZonaHorariaRespondeErrorIndicandoElPaso() {
    // Given
    ReflectionTestUtils.setField(service, "translateTimeZone", true);
    when(timeZoneValidationService.validate(any(TimeZoneValidationStartDto.class)))
        .thenThrow(new IllegalStateException("BD no disponible"));

    // When
    UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

    // Then
    verify(responses).error(eq("Validación de zona horaria"), any(Throwable.class));
    assertThat(out.getDescription()).contains("BD no disponible");
    verifyNoInteractions(emsSender);
  }

  @Test
  void unaPeticionConErrorNoImpideProcesarLasDemas() {
    // Given
    UpdateOfferRequest mala = TestData.request();
    mala.setCampaignId("MALA");
    when(updateOfferMapper.toEmsXml(eq(mala), any(), any(), any(), any()))
        .thenThrow(new RuntimeException("fallo"));

    // When
    List<UpdateOfferResponse> out = service.updateOffer(List.of(mala, TestData.request()), headers);

    // Then
    assertThat(out.get(0).getCode()).isEqualTo("ERROR");
    assertThat(out.get(1)).isSameAs(exito);
  }

  @Test
  void exitoDelEmsEncolaElEnvioAkafkaConLaRespuestaDelEms() {
    // Given
    UpdateOfferRequest rq = TestData.request();

    // When
    service.updateOffer(List.of(rq), headers);

    // Then
    verify(kafkaSenderDashboard)
        .build(eq(rq), eq(headers), any(LocalDateTime.class), eq(emsResponse));
    verify(offerFulfillmentEmsSender).sendAsync(kafkaInput);
  }

  @Test
  void kafkaDeshabilitadoNoArmaNiEncolaNadaPeroEscribeElResultado() {
    // Given
    when(offerFulfillmentEmsSender.isEnabled()).thenReturn(false);
    when(responses.kafkaDisabledText())
        .thenReturn("Envío del evento desactivado: no hay destino activo 2026/11/11 10:30:45");
    var appender = escucharElLog();

    // When
    try {
      service.updateOffer(List.of(TestData.request()), headers);
    } finally {
      dejarDeEscucharElLog(appender);
    }

    // Then
    verifyNoInteractions(kafkaSenderDashboard);
    verify(offerFulfillmentEmsSender, never()).sendAsync(any());
    assertThat(appender.list)
        .anyMatch(
            e ->
                e.getFormattedMessage()
                    .startsWith("[KAFKA] Resultado: Envío del evento desactivado"));
  }

  @Test
  void operacionSuprimidaNoEnviaAkafka() {
    // Given
    when(suppressionCheckService.perform(any())).thenReturn(conSupresion("true"));

    // When
    service.updateOffer(List.of(TestData.request()), headers);

    // Then
    verify(offerFulfillmentEmsSender, never()).sendAsync(any());
  }

  @Test
  void zonaHorariaInvalidaNoEnviaAkafka() {
    // Given
    ReflectionTestUtils.setField(service, "translateTimeZone", true);
    when(timeZoneValidationService.validate(any(TimeZoneValidationStartDto.class)))
        .thenReturn(validacion("COP_TZCOD_115", "Invalid TimeZone"));

    // When
    service.updateOffer(List.of(TestData.request()), headers);

    // Then
    verify(offerFulfillmentEmsSender, never()).sendAsync(any());
  }

  @Test
  void errorDelEmsElEventoSeEnviaIgualSinRespuestaDelEms() {
    // Given
    when(emsSender.send(eq("<ems/>"), any())).thenThrow(new RuntimeException("timeout"));

    // When
    UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

    // Then
    verify(kafkaSenderDashboard).build(any(), any(), any(), org.mockito.ArgumentMatchers.isNull());
    verify(offerFulfillmentEmsSender).sendAsync(any());
    assertThat(out.getCode()).isEqualTo("ERROR"); // la respuesta sigue diciendo que falló el EMS
  }

  @Test
  void fallaAlEncolarEnKafkaNoAfectaLaRespuesta() {
    // Given
    org.mockito.Mockito.doThrow(new RuntimeException("cola llena"))
        .when(offerFulfillmentEmsSender)
        .sendAsync(any());

    // When
    UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

    // Then
    assertThat(out).isSameAs(exito);
  }

  @Test
  void fallaAlArmarElEventoDeKafkaNoAfectaLaRespuesta() {
    // Given
    when(kafkaSenderDashboard.build(any(), any(), any(), any()))
        .thenThrow(new IllegalStateException("sin datos"));

    // When
    UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

    // Then
    assertThat(out).isSameAs(exito);
    verify(auditLogService).logResponse(eq(headers), anyList());
  }

  @Test
  void startDeZonaHorariaInvalidoRespondeErrorynoLlamaAlaValidacion() {
    // Given
    ReflectionTestUtils.setField(service, "translateTimeZone", true);
    org.mockito.Mockito.doThrow(
            new IllegalArgumentException("Datos inválidos en TimeZoneValidationStartDto: system"))
        .when(dtoValidator)
        .validateOrThrow(any(TimeZoneValidationStartDto.class));

    // When
    UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

    // Then
    assertThat(out.getCode()).isEqualTo("ERROR");
    assertThat(out.getDescription()).contains("TimeZoneValidationStartDto");
    verifyNoInteractions(timeZoneValidationService, emsSender);
  }

  @Test
  void startDeSupresionInvalidoRespondeErrorynoLlamaAlEms() {
    // Given
    org.mockito.Mockito.doThrow(
            new IllegalArgumentException(
                "Datos inválidos en StartRequest: requestParams.countryCode"))
        .when(dtoValidator)
        .validateOrThrow(any(StartRequest.class));

    // When
    UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

    // Then
    assertThat(out.getCode()).isEqualTo("ERROR");
    assertThat(out.getDescription()).contains("countryCode");
    verifyNoInteractions(suppressionCheckService, emsSender);
  }

  @Test
  void validaElStartDeSupresionAntesDeConsultar() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    service.updateOffer(List.of(TestData.request()), headers);

    // Then
    ArgumentCaptor<StartRequest> c = ArgumentCaptor.forClass(StartRequest.class);
    verify(dtoValidator).validateOrThrow(c.capture());
    assertThat(c.getValue().getRequestParams().getCountryCode()).isEqualTo("MX");
  }

  @Test
  void laMismaHoraDeLaPeticionSePasaAlXmlDelEmsAndAlEventoDeKafka() {
    // Given
    UpdateOfferRequest rq = TestData.request();

    // When
    service.updateOffer(List.of(rq), headers);

    // Then
    ArgumentCaptor<LocalDateTime> alXml = ArgumentCaptor.forClass(LocalDateTime.class);
    ArgumentCaptor<LocalDateTime> kafkaTime = ArgumentCaptor.forClass(LocalDateTime.class);
    verify(updateOfferMapper).toEmsXml(eq(rq), alXml.capture(), any(), any(), any());
    verify(kafkaSenderDashboard).build(eq(rq), eq(headers), kafkaTime.capture(), any());
    assertThat(alXml.getValue()).isNotNull().isEqualTo(kafkaTime.getValue());
  }

  @Test
  void updatedBySalDelHeaderClientId() {
    // Given
    UpdateOfferRequest rq = TestData.request();

    // When
    service.updateOffer(List.of(rq), headers);

    // Then
    verify(updateOfferMapper)
        .toEmsXml(eq(rq), any(LocalDateTime.class), eq("client-123"), any(), any());
  }

  @Test
  void sinHeaderClientIdUpdatedByVaNulo() {
    // Given
    UpdateOfferRequest rq = TestData.request();
    UpdateOfferHeaders sinClientId = TestData.headers();
    sinClientId.getAll().remove("client_id");

    // When
    service.updateOffer(List.of(rq), sinClientId);

    // Then
    verify(updateOfferMapper)
        .toEmsXml(
            eq(rq), any(LocalDateTime.class), org.mockito.ArgumentMatchers.isNull(), any(), any());
  }

  private ch.qos.logback.core.read.ListAppender<ch.qos.logback.classic.spi.ILoggingEvent>
      escucharElLog() {
    ch.qos.logback.classic.Logger logger =
        (ch.qos.logback.classic.Logger)
            org.slf4j.LoggerFactory.getLogger(UpdateOfferServiceImpl.class);
    ch.qos.logback.core.read.ListAppender<ch.qos.logback.classic.spi.ILoggingEvent> appender =
        new ch.qos.logback.core.read.ListAppender<>();
    appender.start();
    logger.addAppender(appender);
    return appender;
  }

  private void dejarDeEscucharElLog(
      ch.qos.logback.core.read.ListAppender<ch.qos.logback.classic.spi.ILoggingEvent> appender) {
    ((ch.qos.logback.classic.Logger)
            org.slf4j.LoggerFactory.getLogger(UpdateOfferServiceImpl.class))
        .detachAppender(appender);
  }

  @Test
  void abInitioTestEnNnoAvisaNadaAndSiguePorElJms() {
    // Given
    ReflectionTestUtils.setField(service, "abInitioTest", "N");
    var appender = escucharElLog();

    // When
    UpdateOfferResponse out;
    try {
      out = service.updateOffer(List.of(TestData.request()), headers).get(0);
    } finally {
      dejarDeEscucharElLog(appender);
    }

    // Then
    assertThat(out).isSameAs(exito);
    verify(emsSender).send(eq("<ems/>"), any());
    assertThat(appender.list).noneMatch(e -> e.getFormattedMessage().contains("AbInitioTest"));
  }

  @Test
  void abInitioTestEnAndAvisaQueElCaminoNoEstaMigradoAndSiguePorElJms() {
    // Given
    ReflectionTestUtils.setField(service, "abInitioTest", "Y");
    var appender = escucharElLog();

    // When
    UpdateOfferResponse out;
    try {
      out = service.updateOffer(List.of(TestData.request()), headers).get(0);
    } finally {
      dejarDeEscucharElLog(appender);
    }

    // Then
    assertThat(out).isSameAs(exito);
    verify(emsSender).send(eq("<ems/>"), any());
    assertThat(appender.list)
        .anyMatch(
            e ->
                e.getLevel() == ch.qos.logback.classic.Level.WARN
                    && e.getFormattedMessage().contains("AbInitioTest = Y")
                    && e.getFormattedMessage().contains("uuid-1"));
  }

  @Test
  void abInitioTestComparaIgualQueBwSoloLaAndMayusculaCuenta() {
    // Given
    ReflectionTestUtils.setField(service, "abInitioTest", "y");
    var appender = escucharElLog();

    // When
    try {
      service.updateOffer(List.of(TestData.request()), headers);
    } finally {
      dejarDeEscucharElLog(appender);
    }

    // Then
    assertThat(appender.list).noneMatch(e -> e.getFormattedMessage().contains("AbInitioTest"));
  }

  @Test
  void laRespuestaDeExitoSePideConLaOfertaQueSeProceso() {
    // Given
    UpdateOfferRequest rq = TestData.request();

    // When
    service.updateOffer(List.of(rq), headers);

    // Then
    verify(responses).success(eq(rq), any());
  }

  @Test
  void alEmsVaElXmlAndLasPropiedadesDelMensaje() {
    // Given
    UpdateOfferRequest rq = TestData.request();

    // When
    service.updateOffer(List.of(rq), headers);

    // Then
    verify(emsSender).send("<ems/>", PROPIEDADES);
    verify(updateOfferMapper)
        .toEmsProperties(eq(rq), any(LocalDateTime.class), eq("client-123"), any(), any());
  }

  @Test
  void siFallaElArmadoDeLasPropiedadesRespondeErrorIndicandoElPasoAndNoEnviaAlEms() {
    // Given
    when(updateOfferMapper.toEmsProperties(any(), any(), any(), any(), any()))
        .thenThrow(new IllegalStateException("campo inválido"));

    // When
    UpdateOfferResponse out = service.updateOffer(List.of(TestData.request()), headers).get(0);

    // Then
    verify(responses).error(eq("Armado de las propiedades del mensaje"), any(Throwable.class));
    assertThat(out.getDescription()).contains("campo inválido");
    verifyNoInteractions(emsSender);
  }

  @Test
  void laRespuestaDelEmsSePasaAlaFabricaParaQuePuedaDevolverlaSiSeConfiguraAsi() {
    // Given
    UpdateOfferRequest rq = TestData.request();

    // When
    service.updateOffer(List.of(rq), headers);

    // Then
    verify(responses).success(rq, emsResponse);
  }
}
