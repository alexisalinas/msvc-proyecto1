package com.banamex.app.service.timezonevalidation;

import static org.assertj.core.api.Assertions.assertThat;

import com.banamex.app.dto.timezonevalidation.TzFormatsDto;
import com.banamex.app.dto.timezonevalidation.TzLookUpDto;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;

/** Pruebas unitarias de {@code InitTz}. */
class InitTzTest {

  private final InitTz initTz = new InitTz();

  private TzLookUpDto lookUp(String system, String mode, String type, String offset) {
    TzLookUpDto l = new TzLookUpDto();
    l.setSystemName(system);
    l.setMode(mode);
    l.setType(type);
    l.setTimeOffset(offset);
    l.setDateFormat("yyyy-MM-dd");
    l.setTimeFormat("HH:mm:ss");
    l.setDateTimeFormat("yyyy-MM-dd'T'HH:mm:ss");
    l.setTimeZone("America/Bogota");
    return l;
  }

  @Test
  void conCoincidenciaDevuelveLosFormatosConLosNombresDeBw() {
    // Given
    // (sin precondiciones)

    // When
    Optional<TzFormatsDto> r =
        initTz.execute(
            "COPS",
            "RT",
            "Request",
            List.of(
                lookUp("OTRO", "RT", "Request", "+01:00"),
                lookUp("COPS", "RT", "Request", "-05:00")));

    // Then
    assertThat(r).isPresent();
    assertThat(r.get().getTimeZoneOffset()).isEqualTo("-05:00");
    assertThat(r.get().getDateFormat()).isEqualTo("yyyy-MM-dd");
    assertThat(r.get().getTimeFormat()).isEqualTo("HH:mm:ss");
    assertThat(r.get().getDateTimeFormat()).isEqualTo("yyyy-MM-dd'T'HH:mm:ss");
    assertThat(r.get().getTimeZone()).isEqualTo("America/Bogota");
  }

  @Test
  void sinCoincidenciaDevuelveVacio() {
    // Given
    // (sin precondiciones)

    // When / Then
    assertThat(
            initTz.execute(
                "COPS", "RT", "Response", List.of(lookUp("COPS", "RT", "Request", "-05:00"))))
        .isEmpty();
    assertThat(
            initTz.execute(
                "COPS", "BATCH", "Request", List.of(lookUp("COPS", "RT", "Request", "-05:00"))))
        .isEmpty();
    assertThat(
            initTz.execute(
                "XXXX", "RT", "Request", List.of(lookUp("COPS", "RT", "Request", "-05:00"))))
        .isEmpty();
  }

  @Test
  void listaNulaOrVaciaDevuelveVacio() {
    // Given
    // (sin precondiciones)

    // When / Then
    assertThat(initTz.execute("COPS", "RT", "Request", null)).isEmpty();
    assertThat(initTz.execute("COPS", "RT", "Request", List.of())).isEmpty();
  }

  @Test
  void conVariasCoincidenciasTomaLaPrimera() {
    // Given
    // (sin precondiciones)

    // When
    Optional<TzFormatsDto> r =
        initTz.execute(
            "COPS",
            "RT",
            "Request",
            List.of(
                lookUp("COPS", "RT", "Request", "-05:00"),
                lookUp("COPS", "RT", "Request", "+09:00")));

    // Then
    assertThat(r.get().getTimeZoneOffset()).isEqualTo("-05:00");
  }

  @Test
  void valoresNulosEnLaConsultaNoLanzanExcepcion() {
    // Given
    // (sin precondiciones)

    // When / Then
    assertThat(initTz.execute(null, null, null, List.of(lookUp("COPS", "RT", "Request", "-05:00"))))
        .isEmpty();
  }
}
