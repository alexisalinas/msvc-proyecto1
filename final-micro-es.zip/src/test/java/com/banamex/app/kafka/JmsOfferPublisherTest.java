package com.banamex.app.kafka;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.banamex.app.testutil.XmlTestUtil;
import jakarta.jms.DeliveryMode;
import jakarta.jms.MessageProducer;
import jakarta.jms.Queue;
import jakarta.jms.Session;
import jakarta.jms.TextMessage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.SessionCallback;
import org.w3c.dom.Document;

/** Pruebas unitarias de {@code JmsOfferPublisher}. */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class JmsOfferPublisherTest {

  @Mock JmsTemplate jms;

  private JmsOfferPublisher publisher;
  private Session session;
  private MessageProducer producer;
  private TextMessage message;

  @BeforeEach
  @SuppressWarnings("unchecked")
  void setUp() throws Exception {
    publisher = new JmsOfferPublisher(() -> jms, "cola.bridge", "json", 0);

    session = mock(Session.class);
    Queue queue = mock(Queue.class);
    producer = mock(MessageProducer.class);
    message = mock(TextMessage.class);
    when(session.createQueue("cola.bridge")).thenReturn(queue);
    when(session.createProducer(queue)).thenReturn(producer);
    when(session.createTextMessage(anyString())).thenReturn(message);
    when(message.getJMSMessageID()).thenReturn("ID:123");

    when(jms.execute(ArgumentMatchers.<SessionCallback<String>>any(), eq(true)))
        .thenAnswer(inv -> ((SessionCallback<String>) inv.getArgument(0)).doInJms(session));
  }

  @Test
  void conFormatoEnvelopeEnviaUnXmlRootConRefIdAndJsonStringAlaCola() throws Exception {
    // Given
    publisher = new JmsOfferPublisher(() -> jms, "cola.bridge", "envelope", 0);

    // When
    publisher.publish("ref1", "{\"event\":{}}");

    // Then
    ArgumentCaptor<String> body = ArgumentCaptor.forClass(String.class);
    verify(session).createTextMessage(body.capture());
    Document doc = XmlTestUtil.parse(body.getValue());
    assertThat(doc.getDocumentElement().getNodeName()).isEqualTo("root");
    assertThat(XmlTestUtil.childNames(doc, "root")).containsExactly("RefId", "jsonString");
    assertThat(doc.getElementsByTagName("RefId").item(0).getTextContent()).isEqualTo("ref1");
    assertThat(doc.getElementsByTagName("jsonString").item(0).getTextContent())
        .isEqualTo("{\"event\":{}}");
    verify(producer).send(message);
  }

  @Test
  void conFormatoEnvelopeEscapaLosCaracteresEspecialesDeXmlEnElJson() throws Exception {
    // Given
    publisher = new JmsOfferPublisher(() -> jms, "cola.bridge", "envelope", 0);
    String json = "{\"texto\":\"a & b < c > d\"}";

    // When
    publisher.publish("ref&1", json);

    // Then
    ArgumentCaptor<String> body = ArgumentCaptor.forClass(String.class);
    verify(session).createTextMessage(body.capture());
    assertThat(body.getValue()).contains("&amp;", "&lt;", "&gt;").doesNotContain("a & b");
    Document doc = XmlTestUtil.parse(body.getValue());
    assertThat(doc.getElementsByTagName("jsonString").item(0).getTextContent()).isEqualTo(json);
    assertThat(doc.getElementsByTagName("RefId").item(0).getTextContent()).isEqualTo("ref&1");
  }

  @Test
  void porDefectoElMensajeEsElJsonDelEventoTodoJuntoSinEnvoltorio() throws Exception {
    // Given
    String json =
        "{\"event\":{\"header\":{\"name\":\"Updateofferrequest\"},\"body\":{\"RefID\":\"ref1\"}}}";

    // When
    publisher.publish("ref1", json);

    // Then
    ArgumentCaptor<String> body = ArgumentCaptor.forClass(String.class);
    verify(session).createTextMessage(body.capture());
    assertThat(body.getValue()).isEqualTo(json);
    assertThat(body.getValue()).doesNotContain("<root>", "<RefId>", "<jsonString>");
  }

  @Test
  void conFormatoJsonElRefIdVaComoPropiedadAndComoCorrelationId() throws Exception {
    // Given
    publisher = new JmsOfferPublisher(() -> jms, "cola.bridge", "json", 0);

    // When
    publisher.publish("ref1", "{}");

    // Then
    verify(message).setStringProperty("RefId", "ref1");
    verify(message).setJMSCorrelationID("ref1");
  }

  @Test
  void elFormatoNoDistingueMayusculas() throws Exception {
    // Given
    publisher = new JmsOfferPublisher(() -> jms, "cola.bridge", "ENVELOPE", 0);

    // When
    publisher.publish("ref1", "{}");

    // Then
    ArgumentCaptor<String> body = ArgumentCaptor.forClass(String.class);
    verify(session).createTextMessage(body.capture());
    assertThat(body.getValue()).startsWith("<root>");
  }

  @Test
  void poneElRefIdComoCorrelationId() throws Exception {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    publisher.publish("ref1", "{}");

    // Then
    verify(message).setJMSCorrelationID("ref1");
  }

  @Test
  void devuelveElMessageIdAsignadoPorElDestino() throws Exception {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When / Then
    assertThat(publisher.publish("ref1", "{}")).isEqualTo("ID:123");
  }

  @Test
  void laEntregaEsNoPersistenteComoEnElEms() throws Exception {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    publisher.publish("ref1", "{}");

    // Then
    verify(producer).setDeliveryMode(DeliveryMode.NON_PERSISTENT);
  }

  @Test
  void conExpiracionConfiguradaLaAplicaAlProductor() throws Exception {
    // Given
    publisher = new JmsOfferPublisher(() -> jms, "cola.bridge", "json", 30);

    // When
    publisher.publish("ref1", "{}");

    // Then
    verify(producer).setTimeToLive(30L);
  }

  @Test
  void sinExpiracionNoLaAplica() throws Exception {
    // Given
    publisher = new JmsOfferPublisher(() -> jms, "cola.bridge", "json", 0);

    // When
    publisher.publish("ref1", "{}");

    // Then
    verify(producer, never()).setTimeToLive(anyLong());
  }

  @Test
  void siempreCierraElProductor() throws Exception {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When
    publisher.publish("ref1", "{}");

    // Then
    verify(producer).close();
  }

  @Test
  @SuppressWarnings("unchecked")
  void siFallaElEnvioPropagaLaExcepcionParaQueSeReintente() {
    // Given
    when(jms.execute(ArgumentMatchers.<SessionCallback<String>>any(), eq(true)))
        .thenThrow(new org.springframework.jms.UncategorizedJmsException("broker caído"));

    // When / Then
    assertThatThrownBy(() -> publisher.publish("ref1", "{}"))
        .isInstanceOf(org.springframework.jms.JmsException.class);
  }

  @Test
  void siFallaElProductorPropagaLaExcepcion() throws Exception {
    // Given
    org.mockito.Mockito.doThrow(new jakarta.jms.JMSException("sin permiso"))
        .when(producer)
        .send(message);

    // When / Then
    assertThatThrownBy(() -> publisher.publish("ref1", "{}"))
        .isInstanceOf(jakarta.jms.JMSException.class)
        .hasMessageContaining("sin permiso");
    verify(producer).close();
  }

  @Test
  void sinColaFallaConUnMensajeClaroAndNoConectaAlEms() {
    // Given
    publisher = new JmsOfferPublisher(() -> jms, " ", "json", 0);

    // When / Then
    assertThatThrownBy(() -> publisher.publish("ref1", "{}"))
        .isInstanceOf(IllegalStateException.class)
        .hasMessageContaining("no hay cola configurada");
    org.mockito.Mockito.verifyNoInteractions(jms);
  }
}
