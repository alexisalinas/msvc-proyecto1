package com.banamex.app.kafka;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

/** Pruebas unitarias de los valores por defecto de {@code OfferKafkaProps}. */
class OfferKafkaPropsTest {

  @Test
  void sinConfiguracionKafkaEstaActivoPeroEnDryRun() {
    // Given
    OfferKafkaProps props = new OfferKafkaProps();

    // When / Then
    assertThat(props.isEnabled()).isTrue();
    assertThat(props.getMode()).isEqualTo("dry-run");
  }

  @Test
  void sinConfiguracionElMensajeAlaColaEsElJsonTodoJunto() {
    // Given
    OfferKafkaProps props = new OfferKafkaProps();

    // When / Then
    assertThat(props.getMessageFormat()).isEqualTo("json");
  }

  @Test
  void sinConfiguracionElEventoSeLlamaUpdateofferrequest() {
    // Given
    OfferKafkaProps props = new OfferKafkaProps();

    // When / Then
    assertThat(props.getEventName()).isEqualTo("Updateofferrequest");
  }

  @Test
  void sinConfiguracionLaColaDelBridgeDeKafkaEstaApagada() {
    // Given
    OfferKafkaProps props = new OfferKafkaProps();

    // When / Then
    assertThat(props.isBridgeEnabled()).isFalse();
  }

  @Test
  void sinConfiguracionElEventoSeEnviaAunqueLaBdnoTraigaLaOferta() {
    // Given
    OfferKafkaProps props = new OfferKafkaProps();

    // When / Then
    assertThat(props.isSendWithoutDbRows()).isTrue();
  }

  @Test
  void sinConfiguracionElEmsAlternoEstaApagado() {
    // Given
    AlternateEmsProps props = new AlternateEmsProps();

    // When / Then
    assertThat(props.isEnabled()).isFalse();
    assertThat(props.getJmsTemplateName()).isEqualTo("alternateEmsJmsTemplate");
    assertThat(props.getMessageFormat()).isEqualTo("json");
  }
}
