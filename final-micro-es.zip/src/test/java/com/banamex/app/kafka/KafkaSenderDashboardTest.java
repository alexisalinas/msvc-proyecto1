package com.banamex.app.kafka;

import static org.assertj.core.api.Assertions.assertThat;

import com.banamex.app.dto.UpdateOfferResponse;
import com.banamex.app.testutil.TestData;
import org.junit.jupiter.api.Test;

/** Pruebas unitarias de {@code KafkaSenderDashboard}. */
class KafkaSenderDashboardTest {

  private final KafkaSenderDashboard dashboard =
      new KafkaSenderDashboard(new OfferKeyBuilder(new OfferKafkaProps()));

  private UpdateOfferResponse respuesta() {
    UpdateOfferResponse r = new UpdateOfferResponse();
    r.setCode("COP_UPDOF_0");
    r.setDescription("Successfully update offer");
    return r;
  }

  @Test
  void armaElEventoDeEntradaConLosDatosDelRequestLosHeadersAndLaRespuesta() {
    // Given
    // (sin precondiciones)

    // When
    OfferInput in =
        dashboard.build(
            TestData.request(), TestData.headers(), TestData.requestTime(), respuesta());

    // Then
    assertThat(in.getUuid()).isEqualTo("uuid-1");
    assertThat(in.getChannel()).isEqualTo("CAT");
    assertThat(in.getCampaignId()).isEqualTo("CAMP001");
    assertThat(in.getWaveId()).isEqualTo("WAVE01");
    assertThat(in.getCustomerNo()).isEqualTo("12345678");
    assertThat(in.getAccountNo()).isEqualTo("00112233445566");
    assertThat(in.getCardNumber()).isEqualTo("1234567812345678");
    assertThat(in.getOfferStatus()).isEqualTo("01");
    assertThat(in.getResponseCode()).isEqualTo("COP_UPDOF_0");
    assertThat(in.getResponseText()).isEqualTo("Successfully update offer");
  }

  @Test
  void refIdLlevaLaTarjetaPeroLaClaveDeLaOfertaNo() {
    // Given
    // (sin precondiciones)

    // When
    OfferInput in =
        dashboard.build(
            TestData.request(), TestData.headers(), TestData.requestTime(), respuesta());

    // Then
    assertThat(in.getRefId()).isEqualTo("CAMP001_WAVE01_12345678_00112233445566_1234567812345678");
    assertThat(in.getOfferKey()).isEqualTo("off:mx:CAMP001:WAVE01:12345678:00112233445566");
  }

  @Test
  void actionIdEsElOfferActionDelRequest() {
    // Given
    // (sin precondiciones)

    // When
    OfferInput in =
        dashboard.build(
            TestData.request(), TestData.headers(), TestData.requestTime(), respuesta());

    // Then
    assertThat(in.getActionId()).isEqualTo("UPD");

    var rq = TestData.request();
    rq.setOfferActionCode(null);
    assertThat(
            dashboard
                .build(rq, TestData.headers(), TestData.requestTime(), respuesta())
                .getActionId())
        .isNull();
  }

  @Test
  void transactionTimeEsLaHoraDeLaPeticionConMilisegundosAndSinOffset() {
    // Given
    // (sin precondiciones)

    // When
    OfferInput in =
        dashboard.build(
            TestData.request(), TestData.headers(), TestData.requestTime(), respuesta());

    // Then
    assertThat(in.getTransactionTime()).isEqualTo("2026-10-26T10:54:55.852");
  }

  @Test
  void sinHoraDeLaPeticionTransactionTimeUsaLaHoraActual() {
    // Given
    // (sin precondiciones)

    // When / Then
    assertThat(
            dashboard
                .build(TestData.request(), TestData.headers(), null, respuesta())
                .getTransactionTime())
        .matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}");
  }

  @Test
  void responseTimeLlevaMilisegundosAndOffset() {
    // Given
    // (sin precondiciones)

    // When
    OfferInput in =
        dashboard.build(
            TestData.request(), TestData.headers(), TestData.requestTime(), respuesta());

    // Then
    assertThat(in.getResponseTime())
        .matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}([+-]\\d{2}:\\d{2}|Z)");
  }

  @Test
  void sinRespuestaElCodigoAndElTextoQuedanNulos() {
    // Given
    // (sin precondiciones)

    // When
    OfferInput in =
        dashboard.build(TestData.request(), TestData.headers(), TestData.requestTime(), null);

    // Then
    assertThat(in.getResponseCode()).isNull();
    assertThat(in.getResponseText()).isNull();
  }

  @Test
  void responseTimeUsaLaZonaEcrmConfigurada() {
    // Given
    org.springframework.test.util.ReflectionTestUtils.setField(
        dashboard, "ecrmTimeZone", "Pacific/Honolulu");

    // When
    OfferInput in =
        dashboard.build(
            TestData.request(), TestData.headers(), TestData.requestTime(), respuesta());

    // Then
    assertThat(in.getResponseTime()).endsWith("-10:00");
  }

  @Test
  void responseTimePorDefectoUsaUsCentral() {
    // Given
    // (sin precondiciones: la zona por defecto es la de las globales)

    // When
    OfferInput in =
        dashboard.build(
            TestData.request(), TestData.headers(), TestData.requestTime(), respuesta());

    // Then
    assertThat(in.getResponseTime()).matches(".*(-05:00|-06:00)$");
  }

  @Test
  void esbUuidSeGeneraComoGuidAndEsDistintoEnCadaEvento() {
    // Given
    // (sin precondiciones propias: se usa el generador por defecto)

    // When
    OfferInput a =
        dashboard.build(
            TestData.request(), TestData.headers(), TestData.requestTime(), respuesta());
    OfferInput b =
        dashboard.build(
            TestData.request(), TestData.headers(), TestData.requestTime(), respuesta());

    // Then
    assertThat(a.getEsbUuid())
        .matches("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}");
    assertThat(b.getEsbUuid()).isNotEqualTo(a.getEsbUuid());
    assertThat(a.getEsbUuid()).isNotEqualTo(a.getUuid());
  }

  @Test
  void esbUuidUsaElGeneradorConfigurado() {
    // Given
    org.springframework.test.util.ReflectionTestUtils.setField(
        dashboard, "esbUuidGenerator", (java.util.function.Supplier<String>) () -> "esb-fijo");

    // When
    OfferInput in =
        dashboard.build(
            TestData.request(), TestData.headers(), TestData.requestTime(), respuesta());

    // Then
    assertThat(in.getEsbUuid()).isEqualTo("esb-fijo");
  }
}
