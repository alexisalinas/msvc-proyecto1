package com.banamex.app.kafka;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

/** Pruebas unitarias de {@code KafkaMetrics}. */
class KafkaMetricsTest {

  @Test
  void empiezanEnCeroAndCadaContadorEsIndependiente() {
    // Given
    KafkaMetrics m = new KafkaMetrics();

    // When / Then
    assertThat(m.getSent() + m.getNoRows() + m.getInvalid() + m.getFailed() + m.getRejected())
        .isZero();

    m.incSent();
    m.incSent();
    m.incNoRows();
    m.incInvalid();
    m.incFailed();
    m.incRejected();
    m.incRejected();
    m.incRejected();

    assertThat(m.getSent()).isEqualTo(2);
    assertThat(m.getNoRows()).isEqualTo(1);
    assertThat(m.getInvalid()).isEqualTo(1);
    assertThat(m.getFailed()).isEqualTo(1);
    assertThat(m.getRejected()).isEqualTo(3);
  }
}
