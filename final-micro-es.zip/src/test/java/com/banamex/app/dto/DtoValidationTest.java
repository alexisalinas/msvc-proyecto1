package com.banamex.app.dto;

import static org.assertj.core.api.Assertions.assertThat;

import com.banamex.app.dto.suppression.FilteredSuppressionList;
import com.banamex.app.dto.suppression.FilteredSuppressionResult;
import com.banamex.app.dto.suppression.OperationDetailOutput;
import com.banamex.app.dto.suppression.OperationDetailsDto;
import com.banamex.app.dto.suppression.StartRequest;
import com.banamex.app.dto.suppression.StartRequestParams;
import com.banamex.app.dto.suppression.SuppressedEntitiesListRoot;
import com.banamex.app.dto.suppression.SuppressedEntityDto;
import com.banamex.app.dto.timezonevalidation.DateGrpDto;
import com.banamex.app.dto.timezonevalidation.DateTimeGrpDto;
import com.banamex.app.dto.timezonevalidation.MapRequestResultDto;
import com.banamex.app.dto.timezonevalidation.TimeGrpDto;
import com.banamex.app.dto.timezonevalidation.TimeZoneValidationResult;
import com.banamex.app.dto.timezonevalidation.TimeZoneValidationStartDto;
import com.banamex.app.dto.timezonevalidation.TzFormatsDto;
import com.banamex.app.dto.timezonevalidation.TzLookUpDto;
import com.banamex.app.dto.timezonevalidation.ValueItemDto;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

/** Reglas de los esquemas de BW: sin símbolo = obligatorio, ? = opcional, * = lista. */
class DtoValidationTest {

  private static Validator validator;

  @BeforeAll
  static void init() {
    validator = Validation.buildDefaultValidatorFactory().getValidator();
  }

  private static Set<String> paths(Object o) {
    return validator.validate(o).stream()
        .map(ConstraintViolation::getPropertyPath)
        .map(Object::toString)
        .collect(Collectors.toSet());
  }

  @Nested
  class Suppression {
    @Test
    void startRequestParamsRequestingChannelEsOpcional() {
      // Given
      // (sin precondiciones)

      // When / Then
      assertThat(paths(new StartRequestParams()))
          .containsExactlyInAnyOrder("countryCode", "currentOperationName");
      assertThat(
              paths(
                  StartRequestParams.builder()
                      .countryCode("MX")
                      .currentOperationName("UpdateOffer")
                      .build()))
          .isEmpty();
    }

    @Test
    void startRequestExigeParamsAndLosValidaAdentro() {
      // Given
      // (sin precondiciones)

      // When / Then
      assertThat(paths(new StartRequest())).containsExactly("requestParams");
      assertThat(paths(StartRequest.builder().requestParams(new StartRequestParams()).build()))
          .contains("requestParams.countryCode", "requestParams.currentOperationName");
    }

    @Test
    void operationDetailsLostresCamposSonObligatorios() {
      // Given
      // (sin precondiciones)

      // When / Then
      assertThat(paths(new OperationDetailsDto()))
          .containsExactlyInAnyOrder("operationName", "operationFlag", "reqChannel");
    }

    @Test
    void suppressedEntityObligatoriosOpcionalesAndLista() {
      // Given
      // (sin precondiciones)

      // When / Then
      assertThat(paths(new SuppressedEntityDto()))
          .containsExactlyInAnyOrder("mode", "suppressionFlag", "operationFlag", "sourceSystem");
      assertThat(new SuppressedEntityDto().getOperationDetails()).isNotNull().isEmpty();

      SuppressedEntityDto e =
          SuppressedEntityDto.builder()
              .mode("RT")
              .suppressionFlag("Y")
              .operationFlag("Y")
              .sourceSystem("ECRM")
              .operationDetails(List.of(new OperationDetailsDto()))
              .build();
      assertThat(paths(e)).contains("operationDetails[0].operationName");
    }

    @Test
    void suppressedEntitiesListEsListaAndValidaCadaElemento() {
      // Given
      SuppressedEntitiesListRoot r =
          SuppressedEntitiesListRoot.builder()
              .suppressedEntities(List.of(new SuppressedEntityDto()))
              .build();

      // When / Then
      assertThat(paths(r)).contains("suppressedEntities[0].mode");
      assertThat(new SuppressedEntitiesListRoot().getSuppressedEntities()).isNotNull().isEmpty();
    }

    @Test
    void operationDetailOutputIndicatorEsOpcional() {
      // Given
      // (sin precondiciones)

      // When / Then
      assertThat(paths(new OperationDetailOutput()))
          .containsExactlyInAnyOrder(
              "operationName",
              "reqChannel",
              "operationFlag",
              "countryCode",
              "responseCode",
              "responseText");
    }

    @Test
    void filteredSuppressionResultCamposObligatoriosAndListaDeDetalles() {
      // Given
      // (sin precondiciones)

      // When / Then
      assertThat(paths(new FilteredSuppressionResult()))
          .containsExactlyInAnyOrder(
              "countryCode",
              "channelId",
              "suppressionFlag",
              "operationFlag",
              "mode",
              "sourceSystem");
      assertThat(new FilteredSuppressionResult().getOperationDetails()).isNotNull().isEmpty();
    }

    @Test
    void filteredSuppressionListEsListaAndValidaCadaResultado() {
      // Given
      FilteredSuppressionList l =
          FilteredSuppressionList.builder()
              .results(List.of(new FilteredSuppressionResult()))
              .build();

      // When / Then
      assertThat(paths(l)).contains("results[0].countryCode", "results[0].mode");
      assertThat(new FilteredSuppressionList().getResults()).isNotNull().isEmpty();
    }
  }

  @Nested
  class TimeZone {
    @Test
    void startObligatoriosAndListasNoNulas() {
      // Given
      // (sin precondiciones)

      // When / Then
      assertThat(paths(new TimeZoneValidationStartDto()))
          .containsExactlyInAnyOrder("system", "sysMode", "type");
      TimeZoneValidationStartDto s = new TimeZoneValidationStartDto();
      assertThat(s.getDate()).isNotNull().isEmpty();
      assertThat(s.getTime()).isNotNull().isEmpty();
      assertThat(s.getDateTime()).isNotNull().isEmpty();
    }

    @Test
    void startValidaCadaElementoDeLasListas() {
      // Given
      TimeZoneValidationStartDto s =
          TimeZoneValidationStartDto.builder()
              .system("COPS")
              .sysMode("RT")
              .type("Request")
              .date(List.of(new ValueItemDto("2026-10-25", null)))
              .time(List.of(new ValueItemDto("10:30:00", "T")))
              .build();

      // When / Then
      assertThat(paths(s)).containsExactly("date[0].name");
    }

    @Test
    void valueItemElValorEsOpcionalAndElNombreObligatorio() {
      // Given
      // (sin precondiciones)

      // When / Then
      assertThat(paths(new ValueItemDto())).containsExactly("name");
      assertThat(paths(new ValueItemDto(null, "AppointmentDate"))).isEmpty();
    }

    @Test
    void formatsAndLookUpTodosObligatorios() {
      // Given
      // (sin precondiciones)

      // When / Then
      assertThat(paths(new TzFormatsDto())).hasSize(5);
      assertThat(paths(new TzLookUpDto())).hasSize(8);
    }

    @Test
    void gruposStatusObligatorioPeroPuedeIrVacioAndNameOpcional() {
      // Given
      // (sin precondiciones)

      // When / Then
      assertThat(paths(new DateGrpDto())).containsExactlyInAnyOrder("date", "dateStatus");
      assertThat(paths(new TimeGrpDto())).containsExactlyInAnyOrder("time", "timeStatus");
      assertThat(paths(new DateTimeGrpDto()))
          .containsExactlyInAnyOrder("dateTime", "dateTimeStatus");
      assertThat(paths(new DateGrpDto("2026-10-25T00:00:00-0600", "", null))).isEmpty();
    }

    @Test
    void mapRequestResultListasNoNulasAndValidaCadaGrupo() {
      // Given
      // (sin precondiciones)

      // When / Then
      assertThat(paths(new MapRequestResultDto())).isEmpty();
      MapRequestResultDto r = new MapRequestResultDto();
      r.getDateGrp().add(new DateGrpDto());
      r.getTimeGrp().add(new TimeGrpDto());
      assertThat(paths(r)).contains("dateGrp[0].date", "timeGrp[0].timeStatus");
    }

    @Test
    void resultadoCodeAndTextObligatoriosFormatsAndDetalleOpcionales() {
      // Given
      // (sin precondiciones)

      // When / Then
      assertThat(paths(new TimeZoneValidationResult()))
          .containsExactlyInAnyOrder("responseCode", "responseText");
      TimeZoneValidationResult ok = new TimeZoneValidationResult();
      ok.setResponseCode("COP_TZCOD_000");
      ok.setResponseText("Success");
      assertThat(paths(ok)).isEmpty();
    }
  }
}
