package com.banamex.app.sender;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import jakarta.jms.BytesMessage;
import jakarta.jms.DeliveryMode;
import jakarta.jms.Destination;
import jakarta.jms.JMSException;
import jakarta.jms.MapMessage;
import jakarta.jms.Message;
import jakarta.jms.MessageConsumer;
import jakarta.jms.MessageProducer;
import jakarta.jms.Queue;
import jakarta.jms.Session;
import jakarta.jms.TemporaryQueue;
import jakarta.jms.TextMessage;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.SessionCallback;
import org.springframework.test.util.ReflectionTestUtils;

/** Pruebas unitarias de {@code EmsSender}. */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class EmsSenderTest {

  @Mock JmsTemplate jmsTemplate;

  private EmsSender sender;
  private Session session;
  private TemporaryQueue replyQueue;
  private MessageProducer producer;
  private MessageConsumer consumer;
  private TextMessage sent;

  @BeforeEach
  @SuppressWarnings("unchecked")
  void setUp() throws Exception {
    sender = new EmsSender(jmsTemplate);
    ReflectionTestUtils.setField(sender, "queueName", "cola.test");
    ReflectionTestUtils.setField(sender, "timeoutSeconds", 1L);
    ReflectionTestUtils.setField(sender, "timeToLiveMs", 0L);
    ReflectionTestUtils.setField(sender, "dryRun", false);

    session = mock(Session.class);
    replyQueue = mock(TemporaryQueue.class);
    producer = mock(MessageProducer.class);
    consumer = mock(MessageConsumer.class);
    sent = mock(TextMessage.class);

    when(session.createTemporaryQueue()).thenReturn(replyQueue);
    Queue queue = mock(Queue.class);
    when(session.createQueue("cola.test")).thenReturn(queue);
    when(session.createProducer(queue)).thenReturn(producer);
    when(session.createConsumer(replyQueue)).thenReturn(consumer);
    when(session.createTextMessage(anyString())).thenReturn(sent);

    when(jmsTemplate.execute(ArgumentMatchers.<SessionCallback<String>>any(), eq(true)))
        .thenAnswer(inv -> ((SessionCallback<String>) inv.getArgument(0)).doInJms(session));
  }

  private TextMessage textReply(String text) throws JMSException {
    TextMessage reply = mock(TextMessage.class);
    when(reply.getText()).thenReturn(text);
    when(reply.getPropertyNames()).thenAnswer(i -> Collections.enumeration(List.of()));
    when(consumer.receive(anyLong())).thenReturn(reply);
    return reply;
  }

  private static Map<String, String> propiedades() {
    Map<String, String> p = new LinkedHashMap<>();
    p.put("_nm_", "UpdateOffer");
    p.put("_ns_", "www.tibco.com/be/ontology/OfferEngine/Events/UpdateOffer");
    p.put("CampaignID", "CAMP001");
    p.put("UserField3", "");
    p.put("SinValor", null);
    return p;
  }

  @Test
  void conFormatoBothEnviaElXmlEnElCuerpoAndLosCamposComoPropiedadesDelMensaje() throws Exception {
    // Given
    ReflectionTestUtils.setField(sender, "messageFormat", "both");

    // When
    sender.send("<Envelope/>", propiedades());

    // Then
    verify(session).createTextMessage("<Envelope/>");
    verify(sent).setStringProperty("_nm_", "UpdateOffer");
    verify(sent)
        .setStringProperty("_ns_", "www.tibco.com/be/ontology/OfferEngine/Events/UpdateOffer");
    verify(sent).setStringProperty("CampaignID", "CAMP001");
    verify(sent).setStringProperty("UserField3", "");
    verify(sent, never()).setStringProperty(eq("SinValor"), any());
  }

  @Test
  void porDefectoSoloVanLasPropiedadesAndElCuerpoVaVacio() throws Exception {
    // Given

    // When
    sender.send("<Envelope/>", propiedades());

    // Then
    verify(session).createTextMessage("");
    verify(sent).setStringProperty("_nm_", "UpdateOffer");
    verify(sent).setStringProperty("CampaignID", "CAMP001");
  }

  @Test
  void conFormatoPropertiesPeroSinPropiedadesElCuerpoLlevaElXmlParaNoMandarUnMensajeVacio()
      throws Exception {
    // Given
    ReflectionTestUtils.setField(sender, "messageFormat", "properties");

    // When
    sender.send("<Envelope/>", Map.of());

    // Then
    verify(session).createTextMessage("<Envelope/>");
  }

  @Test
  void conFormatoXmlNoPoneNingunaPropiedad() throws Exception {
    // Given
    ReflectionTestUtils.setField(sender, "messageFormat", "xml");

    // When
    sender.send("<Envelope/>", propiedades());

    // Then
    verify(session).createTextMessage("<Envelope/>");
    verify(sent, never()).setStringProperty(anyString(), any());
  }

  @Test
  void elFormatoNoDistingueMayusculas() throws Exception {
    // Given
    ReflectionTestUtils.setField(sender, "messageFormat", "PROPERTIES");

    // When
    sender.send("<Envelope/>", propiedades());

    // Then
    verify(session).createTextMessage("");
  }

  @Test
  void sinPropiedadesElEnvioDeSoloXmlSigueIgual() throws Exception {
    // Given
    // (sin precondiciones propias)

    // When
    sender.send("<Envelope/>");

    // Then
    verify(session).createTextMessage("<Envelope/>");
    verify(sent, never()).setStringProperty(anyString(), any());
  }

  @Test
  void elLogMuestraElXmlConLaTarjetaEnmascaradaAndCuantasPropiedadesSon() throws Exception {
    // Given
    ReflectionTestUtils.setField(sender, "messageFormat", "both");
    textReply("<Response/>");
    var appender = escucharElLog();

    // When
    try {
      sender.send("<Envelope><CardNO>1234567812345678</CardNO></Envelope>", propiedades());
    } finally {
      dejarDeEscucharElLog(appender);
    }

    // Then
    String log = appender.list.get(0).getFormattedMessage();
    assertThat(log).contains("(5 propiedades)", "<CardNO>************5678</CardNO>");
    assertThat(log).doesNotContain("1234567812345678").doesNotContain("CampaignID=CAMP001");
  }

  private ch.qos.logback.core.read.ListAppender<ch.qos.logback.classic.spi.ILoggingEvent>
      escucharElLog() {
    ch.qos.logback.classic.Logger logger =
        (ch.qos.logback.classic.Logger) org.slf4j.LoggerFactory.getLogger(EmsSender.class);
    ch.qos.logback.core.read.ListAppender<ch.qos.logback.classic.spi.ILoggingEvent> appender =
        new ch.qos.logback.core.read.ListAppender<>();
    appender.start();
    logger.addAppender(appender);
    return appender;
  }

  private void dejarDeEscucharElLog(
      ch.qos.logback.core.read.ListAppender<ch.qos.logback.classic.spi.ILoggingEvent> appender) {
    ((ch.qos.logback.classic.Logger) org.slf4j.LoggerFactory.getLogger(EmsSender.class))
        .detachAppender(appender);
  }

  @Test
  void dryRunNoTocaElEmsAndDevuelveUnaRespuestaSimulada() {
    // Given
    ReflectionTestUtils.setField(sender, "dryRun", true);

    // When
    String reply = sender.send("<Envelope/>");

    // Then
    assertThat(reply).contains("<Code>DRY-RUN</Code>", "dry-run");
    verifyNoInteractions(jmsTemplate);
  }

  @Test
  void enviaElXmlComoTextMessageConReplyToAndDevuelveLaRespuesta() throws Exception {
    // Given
    textReply("<Response><Code>000</Code></Response>");

    // When
    String reply = sender.send("<Envelope/>");

    // Then
    assertThat(reply).isEqualTo("<Response><Code>000</Code></Response>");
    verify(session).createTextMessage("<Envelope/>");
    verify(sent).setJMSReplyTo(replyQueue);
    verify(producer).setDeliveryMode(DeliveryMode.NON_PERSISTENT);
    verify(producer).send(sent);
  }

  @Test
  void siempreBorraLaColaTemporalDeRespuesta() throws Exception {
    // Given
    textReply("<ok/>");

    // When
    sender.send("<Envelope/>");

    // Then
    verify(replyQueue).delete();
  }

  @Test
  void esperaLaRespuestaElTiempoConfigurado() throws Exception {
    // Given
    textReply("<ok/>");

    // When
    sender.send("<Envelope/>");

    // Then
    verify(consumer).receive(1000L);
  }

  @Test
  void conTimeToLiveLoAplicaAlProductor() throws Exception {
    // Given
    ReflectionTestUtils.setField(sender, "timeToLiveMs", 5000L);
    textReply("<ok/>");

    // When
    sender.send("<Envelope/>");

    // Then
    verify(producer).setTimeToLive(5000L);
  }

  @Test
  void sinTimeToLiveNoLoAplica() throws Exception {
    // Given
    textReply("<ok/>");

    // When
    sender.send("<Envelope/>");

    // Then
    verify(producer, never()).setTimeToLive(anyLong());
  }

  @Test
  void sinRespuestaEnElTiempoConfiguradoDevuelveNullAndBorraLaCola() throws Exception {
    // Given
    when(consumer.receive(anyLong())).thenReturn(null);

    // When
    String reply = sender.send("<Envelope/>");

    // Then
    assertThat(reply).isNull();
    verify(producer).send(sent);
    verify(replyQueue).delete();
  }

  @Test
  void conTimeoutCeroEnviaSinEsperarRespuestaNiCrearLaColaTemporal() throws Exception {
    // Given
    ReflectionTestUtils.setField(sender, "timeoutSeconds", 0L);

    // When
    String reply = sender.send("<Envelope/>");

    // Then
    assertThat(reply).isNull();
    verify(producer).send(sent);
    verify(session, never()).createTemporaryQueue();
    verify(session, never()).createConsumer(any(Destination.class));
    verify(sent, never()).setJMSReplyTo(any());
  }

  @Test
  void falloAlEnviarSeEnvuelveEnRuntimeException() throws Exception {
    // Given
    doAnswer(
            inv -> {
              throw new JMSException("broker caído");
            })
        .when(producer)
        .send(any(Message.class));
    textReply("<ok/>");

    // When / Then
    assertThatThrownBy(() -> sender.send("<Envelope/>"))
        .isInstanceOf(RuntimeException.class)
        .hasMessageContaining("broker caído");
  }

  @Test
  void respuestaConCuerpoVacioAndPropiedadesSeArmaDesdeLasPropiedades() throws Exception {
    // Given
    TextMessage reply = mock(TextMessage.class);
    when(reply.getText()).thenReturn("");
    when(reply.getPropertyNames())
        .thenAnswer(i -> Collections.enumeration(List.of("Code", "Description")));
    when(reply.getObjectProperty("Code")).thenReturn("000");
    when(reply.getObjectProperty("Description")).thenReturn("OK");
    when(consumer.receive(anyLong())).thenReturn(reply);

    // When / Then
    assertThat(sender.send("<Envelope/>"))
        .isEqualTo("<Response><Code>000</Code><Description>OK</Description></Response>");
  }

  @Test
  void respuestaMapMessageSeConvierteAxml() throws Exception {
    // Given
    MapMessage reply = mock(MapMessage.class);
    when(reply.getPropertyNames()).thenAnswer(i -> Collections.enumeration(List.of()));
    when(reply.getMapNames()).thenAnswer(i -> Collections.enumeration(List.of("Code")));
    when(reply.getObject("Code")).thenReturn("000");
    when(consumer.receive(anyLong())).thenReturn(reply);

    // When / Then
    assertThat(sender.send("<Envelope/>")).isEqualTo("<Response><Code>000</Code></Response>");
  }

  @Test
  void respuestaBytesMessageSeLeeComoUtf8() throws Exception {
    // Given
    byte[] data = "<Response><Code>5</Code></Response>".getBytes(StandardCharsets.UTF_8);
    BytesMessage reply = mock(BytesMessage.class);
    when(reply.getPropertyNames()).thenAnswer(i -> Collections.enumeration(List.of()));
    when(reply.getBodyLength()).thenReturn((long) data.length);
    doAnswer(
            inv -> {
              byte[] target = inv.getArgument(0);
              System.arraycopy(data, 0, target, 0, data.length);
              return data.length;
            })
        .when(reply)
        .readBytes(any(byte[].class));
    when(consumer.receive(anyLong())).thenReturn(reply);

    // When / Then
    assertThat(sender.send("<Envelope/>")).isEqualTo("<Response><Code>5</Code></Response>");
  }

  @Test
  void enviaAlaColaConfigurada() throws Exception {
    // Given
    textReply("<ok/>");

    // When
    sender.send("<Envelope/>");

    // Then
    verify(session).createQueue("cola.test");
  }

  @Test
  void rootCauseDevuelveLaCausaMasProfunda() {
    // Given
    Exception e =
        new RuntimeException(
            "Uncategorized exception occurred during JMS processing",
            new IllegalStateException(
                "capa intermedia", new java.net.ConnectException("Connection refused")));

    // When / Then
    assertThat(EmsSender.rootCause(e)).isEqualTo("ConnectException: Connection refused");
  }

  @Test
  void causeChainListaTodasLasCausasEnUnaLinea() {
    // Given
    Exception e =
        new RuntimeException("A", new IllegalStateException("B", new java.io.IOException("C")));

    // When / Then
    assertThat(EmsSender.causeChain(e))
        .isEqualTo("RuntimeException: A <- IllegalStateException: B <- IOException: C");
  }

  @Test
  void sinCausaRootCauseEsElPropioError() {
    // Given
    // (sin precondiciones propias: se usan los datos de setUp)

    // When / Then
    assertThat(EmsSender.rootCause(new IllegalStateException("solo")))
        .isEqualTo("IllegalStateException: solo");
  }

  @Test
  void laRespuestaDelErrorIncluyeLaCausaRealAndNoSoloElMensajeGenerico() {
    // Given
    when(jmsTemplate.execute(any(org.springframework.jms.core.SessionCallback.class), anyBoolean()))
        .thenThrow(
            new org.springframework.jms.UncategorizedJmsException(
                "Uncategorized exception occurred during JMS processing",
                new javax.net.ssl.SSLHandshakeException("PKIX path building failed")));

    // When / Then
    assertThatThrownBy(() -> sender.send("<Envelope/>"))
        .isInstanceOf(RuntimeException.class)
        .hasMessageContaining("Error enviando al EMS")
        .hasMessageContaining("SSLHandshakeException: PKIX path building failed");
  }
}
