package com.banamex.app.config;

import static org.assertj.core.api.Assertions.assertThat;

import com.banamex.cops.app.repository.CopFulfillmentSuppressionRepository;
import com.banamex.cops.app.service.impl.CopOfferFulfillmentServiceImpl;
import com.banamex.cops.app.service.impl.CopSuppressionServiceImpl;
import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/** Unit tests for {@code OfferFulfillmentConfig}. */
class OfferFulfillmentConfigTest {

  @Test
  void registraLosDosServiciosDeLaLibreria() {
    // Given
    Import importa = OfferFulfillmentConfig.class.getAnnotation(Import.class);

    // When / Then
    assertThat(importa.value())
        .containsExactlyInAnyOrder(
            CopOfferFulfillmentServiceImpl.class, CopSuppressionServiceImpl.class);
  }

  @Test
  void activaLosRepositoriosJpaDeLaLibreriaIncluidoElSubpaqueteDeConsultasNativas() {
    // Given
    EnableJpaRepositories jpa =
        OfferFulfillmentConfig.class.getAnnotation(EnableJpaRepositories.class);

    // When / Then
    assertThat(jpa.basePackages()).containsExactly("com.banamex.cops.app.repository");
    assertThat(CopFulfillmentSuppressionRepository.class.getPackageName())
        .startsWith(jpa.basePackages()[0]);
  }
}
