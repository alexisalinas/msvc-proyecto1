package com.banamex.app.config;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.regex.Pattern;
import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;

/** Pruebas unitarias de {@code LibraryRepositoryFragmentsConfig}. */
class LibraryRepositoryFragmentsConfigTest {

  private final ComponentScan scan =
      LibraryRepositoryFragmentsConfig.class.getAnnotation(ComponentScan.class);

  private boolean incluye(String clase) {
    return Pattern.matches(scan.includeFilters()[0].pattern()[0], clase);
  }

  @Test
  void soloEscaneaLaLibreriaSinLosFiltrosPorDefecto() {
    // Given
    // (sin precondiciones propias)

    // When / Then
    assertThat(scan.basePackages()).containsExactly("com.banamex.cops.app");
    assertThat(scan.useDefaultFilters()).isFalse();
    assertThat(scan.includeFilters()[0].type()).isEqualTo(FilterType.REGEX);
  }

  @Test
  void incluyeLasImplementacionesPersonalizadasDeRepositorios() {
    // Given
    // (sin precondiciones propias)

    // When / Then
    assertThat(incluye("com.banamex.cops.app.repository.impl.DOfferpaletteRepositoryCustomImpl"))
        .isTrue();
    assertThat(incluye("com.banamex.cops.app.repository.DOfferpaletteRepositoryImpl")).isTrue();
  }

  @Test
  void noIncluyeServiciosNiRepositoriosNormalesParaNoDuplicarlos() {
    // Given
    // (sin precondiciones propias)

    // When / Then
    assertThat(incluye("com.banamex.cops.app.service.impl.CopTimezoneLookupServiceImpl")).isFalse();
    assertThat(incluye("com.banamex.cops.app.repository.CopTimezoneLookupRepository")).isFalse();
    assertThat(incluye("com.banamex.cops.app.repository.CopFulfillmentSuppressionRepository"))
        .isFalse();
    assertThat(incluye("com.banamex.cops.app.service.impl.CopSuppressionServiceImpl")).isFalse();
  }
}
