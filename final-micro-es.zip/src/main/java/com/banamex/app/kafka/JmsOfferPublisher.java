package com.banamex.app.kafka;

import com.banamex.app.mapper.XmlUtil;
import jakarta.jms.DeliveryMode;
import jakarta.jms.MessageProducer;
import jakarta.jms.TextMessage;
import java.util.function.Supplier;
import org.springframework.jms.core.JmsTemplate;

/** Deja el evento en una cola JMS: la del puente a Kafka o la del EMS alterno. */
public class JmsOfferPublisher implements OfferPublisher {

  /** Proveedor de la plantilla JMS. */
  private final Supplier<JmsTemplate> jms;

  /** Cola destino. */
  private final String queue;

  /** Formato del mensaje: {@code json} o {@code envelope}. */
  private final String messageFormat;

  /** Vigencia del mensaje en milisegundos; 0 = no expira. */
  private final long timeToLiveMs;

  /**
   * Crea el publicador. La plantilla se pide al publicar, así la conexión solo se crea si el
   * destino se usa.
   *
   * @param jms proveedor de la plantilla JMS
   * @param queue cola destino
   * @param messageFormat formato del mensaje
   * @param timeToLiveMs vigencia en milisegundos
   */
  public JmsOfferPublisher(
      Supplier<JmsTemplate> jms, String queue, String messageFormat, long timeToLiveMs) {
    this.jms = jms;
    this.queue = queue;
    this.messageFormat = messageFormat;
    this.timeToLiveMs = timeToLiveMs;
  }

  /**
   * Envía el JSON tal cual, o dentro de {@code <root><RefId/><jsonString/></root>} con el formato
   * {@code envelope}.
   *
   * @param refId referencia del evento
   * @param json evento serializado
   * @return resultado del envío
   * @throws Exception si falla la publicación
   */
  @Override
  public String publish(String refId, String json) throws Exception {
    if (queue == null || queue.isBlank()) {
      throw new IllegalStateException("no hay cola configurada para este destino");
    }
    String body =
        "envelope".equalsIgnoreCase(messageFormat)
            ? "<root><RefId>"
                + XmlUtil.esc(refId)
                + "</RefId><jsonString>"
                + XmlUtil.esc(json)
                + "</jsonString></root>"
            : json;
    return jms.get()
        .execute(
            session -> {
              try (MessageProducer producer = session.createProducer(session.createQueue(queue))) {
                TextMessage message = session.createTextMessage(body);
                message.setJMSCorrelationID(refId);
                message.setStringProperty("RefId", refId);
                producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
                if (timeToLiveMs > 0) {
                  producer.setTimeToLive(timeToLiveMs);
                }
                producer.send(message);
                return message.getJMSMessageID();
              }
            },
            true);
  }
}
