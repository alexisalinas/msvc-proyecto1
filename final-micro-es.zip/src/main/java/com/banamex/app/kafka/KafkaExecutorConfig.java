package com.banamex.app.kafka;

import java.util.concurrent.ThreadPoolExecutor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/**
 * Configura el ejecutor del envío del evento, con cola acotada: si se llena, se rechaza (y se
 * cuenta) en vez de acumular tareas sin límite.
 */
@Configuration
public class KafkaExecutorConfig {

  /**
   * Crea el ejecutor donde corre {@link com.banamex.app.sender.OfferFulfillmentEmsSender}.
   *
   * @param props tamaños del ejecutor y de su cola
   * @return ejecutor configurado
   */
  @Bean(name = "offerFulfillmentExecutor")
  public ThreadPoolTaskExecutor offerFulfillmentExecutor(OfferKafkaProps props) {
    ThreadPoolTaskExecutor e = new ThreadPoolTaskExecutor();
    e.setThreadNamePrefix("offer-fulfillment-");
    e.setCorePoolSize(props.getExecutorCoreSize());
    e.setMaxPoolSize(props.getExecutorMaxSize());
    e.setQueueCapacity(props.getExecutorQueueCapacity());
    e.setRejectedExecutionHandler(new ThreadPoolExecutor.AbortPolicy());
    e.setWaitForTasksToCompleteOnShutdown(true);
    e.setAwaitTerminationSeconds(5);
    return e;
  }
}
