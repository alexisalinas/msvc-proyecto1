package com.banamex.app.kafka;

import java.util.concurrent.atomic.AtomicLong;
import org.springframework.stereotype.Component;

/**
 * Contadores simples del envío del evento: enviados, sin datos en la base, inválidos, fallidos y
 * rechazados.
 */
@Component
public class KafkaMetrics {

  /** Eventos publicados. */
  private final AtomicLong sent = new AtomicLong();

  /** Ofertas que no se encontraron en la base. */
  private final AtomicLong noRows = new AtomicLong();

  /** Eventos descartados por faltarles datos obligatorios. */
  private final AtomicLong invalid = new AtomicLong();

  /** Envíos que fallaron después de los reintentos. */
  private final AtomicLong failed = new AtomicLong();

  /** Envíos rechazados porque la cola del ejecutor estaba llena. */
  private final AtomicLong rejected = new AtomicLong();

  /** Suma un envío publicado. */
  public void incSent() {
    sent.incrementAndGet();
  }

  /** Suma una oferta que no se encontró en la base de datos. */
  public void incNoRows() {
    noRows.incrementAndGet();
  }

  /** Suma una entrada descartada por faltarle datos obligatorios. */
  public void incInvalid() {
    invalid.incrementAndGet();
  }

  /** Suma un envío que falló después de los reintentos. */
  public void incFailed() {
    failed.incrementAndGet();
  }

  /** Suma un envío rechazado porque la cola del ejecutor estaba llena. */
  public void incRejected() {
    rejected.incrementAndGet();
  }

  /**
   * Cantidad de eventos publicados.
   *
   * @return eventos publicados
   */
  public long getSent() {
    return sent.get();
  }

  /**
   * Cantidad de ofertas sin datos en la base.
   *
   * @return ofertas sin datos en la base
   */
  public long getNoRows() {
    return noRows.get();
  }

  /**
   * Cantidad de eventos inválidos.
   *
   * @return eventos inválidos
   */
  public long getInvalid() {
    return invalid.get();
  }

  /**
   * Cantidad de envíos fallidos.
   *
   * @return envíos fallidos
   */
  public long getFailed() {
    return failed.get();
  }

  /**
   * Cantidad de envíos rechazados.
   *
   * @return envíos rechazados
   */
  public long getRejected() {
    return rejected.get();
  }
}
