package com.banamex.app.kafka;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Evento de entrada del envío de cumplimiento: lo que el micro ya sabe de la oferta antes de
 * consultar la base.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OfferInput {

  /** Identificador de la transacción (header {@code uuid}). */
  private String uuid;

  /** Identificador ESB generado para el evento. */
  private String esbUuid;

  /** Canal que invocó la operación. */
  private String channel;

  /** Hora en que se empezó a procesar la oferta. */
  private String transactionTime;

  /** Referencia del evento: {@code campaña_ola_cliente[_cuenta_tarjeta]}. */
  private String refId;

  /** Llave de la oferta en la base: {@code off:mx:campaña:ola:cliente[:cuenta]}. */
  private String offerKey;

  /** Campaña. */
  private String campaignId;

  /** Ola. */
  private String waveId;

  /** Número de cliente. */
  private String customerNo;

  /** Número de cuenta. */
  private String accountNo;

  /** Número de tarjeta. */
  private String cardNumber;

  /** Estado de la oferta. */
  private String offerStatus;

  /** Acción de la oferta. */
  private String actionId;

  /** Hora de la respuesta del EMS. */
  private String responseTime;

  /** Código de la respuesta del EMS. */
  private String responseCode;

  /** Texto de la respuesta del EMS. */
  private String responseText;
}
