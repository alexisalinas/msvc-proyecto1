package com.banamex.app.kafka;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/** Configuración del evento de cumplimiento de la oferta ({@code offer.kafka.*}). */
@Data
@Component
@ConfigurationProperties(prefix = "offer.kafka")
public class OfferKafkaProps {

  /** Si es {@code false}, no se arma ni se envía ningún evento. */
  private boolean enabled = true;

  /** {@code jms} envía a los destinos activos; {@code dry-run} solo escribe el JSON en el log. */
  private String mode = "dry-run";

  /** Si es {@code true}, el evento se publica en la cola del puente a Kafka. */
  private boolean bridgeEnabled = false;

  /**
   * Si es {@code true}, cuando la consulta no trae la oferta el evento se envía igual, con los
   * campos de la base vacíos.
   */
  private boolean sendWithoutDbRows = true;

  /** Espera en milisegundos antes de consultar la base. */
  private long delayMs = 200;

  /** Cola del puente a Kafka. */
  private String queue;

  /** Prefijo de la llave de la oferta. */
  private String offerPrefix = "off:mx:";

  /** Prefijo de la llave de la ola. */
  private String wavePrefix = "wvch:";

  /** Separador de las partes de las llaves. */
  private String keySeparator = ":";

  /** Si es {@code true}, los campos nulos no se escriben en el JSON. */
  private boolean omitNulls = true;

  /** Si es {@code true}, {@code CardNumber} sale con solo los últimos 4 dígitos en el mensaje. */
  private boolean maskCardNumber = false;

  /** Intentos máximos de cada consulta o publicación. */
  private int maxAttempts = 3;

  /** Espera inicial entre intentos en milisegundos; se duplica en cada intento. */
  private long retryBackoffMs = 500;

  /** Vigencia del mensaje en la cola del puente, en milisegundos; 0 = no expira. */
  private long timeToLiveMs = 0;

  /** Formato del mensaje a la cola del puente: {@code json} o {@code envelope}. */
  private String messageFormat = "json";

  /** CSI del productor del evento. */
  private String producerCsi = "163621";

  /** Nombre del evento. */
  private String eventName = "Updateofferrequest";

  /** Versión del evento. */
  private String eventVersion = "1.0";

  /** Código de país del evento. */
  private String countryCode = "MX";

  /** Código de negocio del evento. */
  private String businessCode = "DM";

  /** Hilos base del ejecutor. */
  private int executorCoreSize = 2;

  /** Hilos máximos del ejecutor. */
  private int executorMaxSize = 4;

  /** Capacidad de la cola del ejecutor. */
  private int executorQueueCapacity = 100;
}
