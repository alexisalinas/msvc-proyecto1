package com.banamex.app.kafka;

/** Publica el evento en un destino. */
public interface OfferPublisher {
  /**
   * Publica el evento.
   *
   * @param refId referencia del evento
   * @param json evento serializado
   * @return resultado de la publicación
   * @throws Exception si falla la publicación
   */
  String publish(String refId, String json) throws Exception;
}
