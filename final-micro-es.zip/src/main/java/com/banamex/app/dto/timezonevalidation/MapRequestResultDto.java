package com.banamex.app.dto.timezonevalidation;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Resultado de la conversión: fechas, horas y fechas-horas. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MapRequestResultDto {

  /** Fechas convertidas. */
  @NotNull @Valid @Builder.Default private List<DateGrpDto> dateGrp = new ArrayList<>();

  /** Horas convertidas. */
  @NotNull @Valid @Builder.Default private List<TimeGrpDto> timeGrp = new ArrayList<>();

  /** Fechas-horas convertidas. */
  @NotNull @Valid @Builder.Default private List<DateTimeGrpDto> dateTimeGrp = new ArrayList<>();
}
