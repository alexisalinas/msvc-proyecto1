package com.banamex.app.dto.suppression;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Datos que identifican la operación a revisar. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StartRequestParams {

  /** Canal que solicita la operación. */
  private String requestingChannel;

  /** País. */
  @NotBlank(message = "El campo CountryCode es obligatorio")
  private String countryCode;

  /** Nombre de la operación en curso. */
  @NotBlank(message = "El campo CurrentOperationName es obligatorio")
  private String currentOperationName;
}
