package com.banamex.app.dto.suppression;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Una operación de un canal en la lista de entidades suprimidas. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OperationDetailsDto {

  /** Nombre de la operación. */
  @NotBlank(message = "El campo OperationName es obligatorio")
  @JsonProperty("OperationName")
  private String operationName;

  /** Bandera de la operación. */
  @NotBlank(message = "El campo Operation_Flag es obligatorio")
  @JsonProperty("Operation_Flag")
  private String operationFlag;

  /** Canal que solicita la operación. */
  @NotBlank(message = "El campo Req_Channel es obligatorio")
  @JsonProperty("Req_Channel")
  private String reqChannel;
}
