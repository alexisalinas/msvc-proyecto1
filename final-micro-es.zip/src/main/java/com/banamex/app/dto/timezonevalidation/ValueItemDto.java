package com.banamex.app.dto.timezonevalidation;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Un valor a convertir (fecha, hora o fecha-hora) con el nombre con el que se identifica. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ValueItemDto {

  /** Valor a convertir; si viene vacío se ignora. */
  private String value;

  /** Nombre del valor, por ejemplo {@code AppointmentDate}. */
  @NotBlank(message = "El nombre del valor es obligatorio")
  private String name;
}
