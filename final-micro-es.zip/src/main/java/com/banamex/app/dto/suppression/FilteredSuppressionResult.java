package com.banamex.app.dto.suppression;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Una entidad suprimida que coincide con la petición. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FilteredSuppressionResult {

  /** País. */
  @NotBlank(message = "El campo CountryCode es obligatorio")
  private String countryCode;

  /** Canal. */
  @NotBlank(message = "El campo ChannelID es obligatorio")
  private String channelId;

  /** Bandera de supresión del canal. */
  @NotBlank(message = "El campo SuppressionFlag es obligatorio")
  private String suppressionFlag;

  /** Bandera de operaciones del canal. */
  @NotBlank(message = "El campo OperationFlag es obligatorio")
  private String operationFlag;

  /** Modo de la supresión. */
  @NotBlank(message = "El campo Mode es obligatorio")
  private String mode;

  /** Sistema origen de la supresión. */
  @NotBlank(message = "El campo SourceSystem es obligatorio")
  private String sourceSystem;

  /** Operaciones suprimidas que coinciden. */
  @NotNull @Valid @Builder.Default
  private List<OperationDetailOutput> operationDetails = new ArrayList<>();
}
