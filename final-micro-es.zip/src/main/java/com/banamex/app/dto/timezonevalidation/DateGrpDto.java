package com.banamex.app.dto.timezonevalidation;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Fecha convertida o inválida de la validación de zona horaria. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DateGrpDto {

  /** Fecha resultante. */
  @NotNull private String date;

  /** Vacío si todo está bien; {@code Invalid TimeZone} si la fecha es inválida. */
  @NotNull private String dateStatus;

  /** Nombre con el que se identifica la fecha. */
  private String dateName;
}
