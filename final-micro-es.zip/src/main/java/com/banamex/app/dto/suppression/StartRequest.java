package com.banamex.app.dto.suppression;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Petición de la revisión de supresión. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StartRequest {

  /** Datos de la petición. */
  @NotNull(message = "El nodo RequestParams es obligatorio")
  @Valid
  private StartRequestParams requestParams;
}
