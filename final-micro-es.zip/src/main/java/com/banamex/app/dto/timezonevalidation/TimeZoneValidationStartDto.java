package com.banamex.app.dto.timezonevalidation;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Datos de entrada de la validación de zona horaria: sistema, modo, tipo y los valores a convertir.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TimeZoneValidationStartDto {

  /** Sistema o canal cuya zona horaria se busca. */
  @NotBlank(message = "El campo System es obligatorio")
  private String system;

  /** Modo del sistema. */
  @NotBlank(message = "El campo SysMode es obligatorio")
  private String sysMode;

  /**
   * {@code Request} para llevar los valores del cliente al backend, {@code Response} para el camino
   * contrario.
   */
  @NotBlank(message = "El campo Type es obligatorio")
  private String type;

  /** Fechas a convertir. */
  @NotNull @Valid @Builder.Default private List<ValueItemDto> date = new ArrayList<>();

  /** Horas a convertir. */
  @NotNull @Valid @Builder.Default private List<ValueItemDto> time = new ArrayList<>();

  /** Fechas-horas a convertir. */
  @NotNull @Valid @Builder.Default private List<ValueItemDto> dateTime = new ArrayList<>();
}
