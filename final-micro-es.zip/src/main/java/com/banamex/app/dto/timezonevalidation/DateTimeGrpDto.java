package com.banamex.app.dto.timezonevalidation;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Fecha-hora convertida o inválida de la validación de zona horaria. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DateTimeGrpDto {

  /** Fecha-hora resultante. */
  @NotNull private String dateTime;

  /** Vacío si todo está bien; {@code Invalid TimeZone} si es inválida. */
  @NotNull private String dateTimeStatus;

  /** Nombre con el que se identifica la fecha-hora. */
  private String dateTimeName;
}
