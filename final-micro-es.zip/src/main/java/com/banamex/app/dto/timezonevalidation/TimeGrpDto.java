package com.banamex.app.dto.timezonevalidation;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Hora convertida o inválida de la validación de zona horaria. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TimeGrpDto {

  /** Hora resultante. */
  @NotNull private String time;

  /** Vacío si todo está bien; {@code Invalid TimeZone} si la hora es inválida. */
  @NotNull private String timeStatus;

  /** Nombre con el que se identifica la hora. */
  private String timeName;
}
