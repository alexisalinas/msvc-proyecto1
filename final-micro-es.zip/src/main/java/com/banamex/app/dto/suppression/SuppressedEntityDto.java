package com.banamex.app.dto.suppression;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Un canal con sus banderas de supresión y las operaciones que afecta. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SuppressedEntityDto {

  /** País. */
  @JsonProperty("CountryCode")
  private String countryCode;

  /** Canal. */
  @JsonProperty("ChannelId")
  private String channelId;

  /** Modo de la supresión. */
  @NotBlank(message = "El campo Mode es obligatorio")
  @JsonProperty("Mode")
  private String mode;

  /** Bandera de supresión. */
  @NotBlank(message = "El campo Suppression_Flag es obligatorio")
  @JsonProperty("Suppression_Flag")
  private String suppressionFlag;

  /** Bandera de operaciones. */
  @NotBlank(message = "El campo Operation_Flag es obligatorio")
  @JsonProperty("Operation_Flag")
  private String operationFlag;

  /** Sistema origen. */
  @NotBlank(message = "El campo SourceSystem es obligatorio")
  @JsonProperty("SourceSystem")
  private String sourceSystem;

  /** Operaciones del canal. */
  @NotNull
  @Valid
  @Builder.Default
  @JsonProperty("OperationDetails")
  private List<OperationDetailsDto> operationDetails = new ArrayList<>();
}
