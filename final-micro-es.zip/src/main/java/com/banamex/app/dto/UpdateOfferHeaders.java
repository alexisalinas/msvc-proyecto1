package com.banamex.app.dto;

import java.util.Map;
import java.util.TreeMap;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Headers HTTP de la petición que usa el flujo. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateOfferHeaders {
  /** Identificador de la transacción. */
  private String uuid;

  /** Host de origen (opcional). */
  private String host;

  /** Canal que invoca la operación. */
  private String channelId;

  /** Código de país de 2 letras. */
  private String countryCode;

  /** Código de negocio. */
  private String businessCode;

  /** Identificador de sesión. */
  private String sid;

  /** Idioma preferido. */
  private String acceptLanguage;

  /** Todos los headers recibidos, sin distinguir mayúsculas. */
  @Builder.Default private Map<String, String> all = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);

  /**
   * Valor del header con ese nombre, sin distinguir mayúsculas.
   *
   * @param name nombre del header
   * @return valor, o {@code null} si no llegó
   */
  public String get(String name) {
    return name == null || all == null ? null : all.get(name);
  }
}
