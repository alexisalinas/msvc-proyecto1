package com.banamex.app.dto.suppression;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Resultado de la revisión de supresión: las entidades que coinciden con la petición. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FilteredSuppressionList {

  /** Entidades que coinciden. */
  @NotNull @Valid @Builder.Default
  private List<FilteredSuppressionResult> results = new ArrayList<>();
}
