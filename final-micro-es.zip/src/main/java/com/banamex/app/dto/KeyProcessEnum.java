package com.banamex.app.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/** Versiones de ejecución permitidas para {@code keyProcess}. */
public enum KeyProcessEnum {
  /** Versión 1. */
  V1("V1"),
  /** Versión 2. */
  V2("V2"),
  /** Versión 3. */
  V3("V3");

  /** Texto con el que se envía y se recibe en el JSON. */
  private final String value;

  /**
   * Crea la versión con su texto.
   *
   * @param value texto de la versión
   */
  KeyProcessEnum(String value) {
    this.value = value;
  }

  /**
   * Valor de texto con el que se serializa el proceso en el JSON.
   *
   * @return texto de la versión
   */
  @JsonValue
  public String getValue() {
    return value;
  }

  /**
   * Convierte el texto recibido en la versión correspondiente, sin distinguir mayúsculas.
   *
   * @param value texto recibido
   * @return versión
   * @throws IllegalArgumentException si el texto no es una versión válida
   */
  @JsonCreator
  public static KeyProcessEnum fromValue(String value) {
    for (KeyProcessEnum process : KeyProcessEnum.values()) {
      if (process.value.equalsIgnoreCase(value)) {
        return process;
      }
    }
    throw new IllegalArgumentException("Valor inválido para KeyProcessEnum: " + value);
  }
}
