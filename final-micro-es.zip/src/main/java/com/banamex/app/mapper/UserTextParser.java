package com.banamex.app.mapper;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Lee el JSON de {@code userText} y devuelve los campos {@code UserField1} a {@code UserField100}.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class UserTextParser {

  /**
   * Nombre de un campo de usuario: {@code userfield} seguido de 1 a 3 dígitos, sin importar
   * mayúsculas.
   */
  private static final Pattern USER_FIELD = Pattern.compile("(?i)^userfield(\\d{1,3})$");

  /** Lee el JSON. */
  private final ObjectMapper jsonMapper;

  /**
   * Convierte el JSON de {@code userText} en los campos de usuario.
   *
   * @param userText JSON recibido en la oferta
   * @return mapa de número de campo (1 a 100) a valor; vacío si no hay o no se puede leer
   */
  public Map<Integer, String> parse(String userText) {
    Map<Integer, String> out = new TreeMap<>();
    if (userText == null || userText.isBlank()) {
      return out;
    }
    try {
      JsonNode root = jsonMapper.readTree(userText);
      if (root.isArray()) {
        root.forEach(n -> collect(n, out));
      } else {
        collect(root, out);
      }
    } catch (Exception e) {
      log.warn("userText no es un JSON válido; se ignoran los UserFields: {}", e.getMessage());
    }
    return out;
  }

  /**
   * Recorre el JSON y toma los campos {@code UserFieldN}.
   *
   * @param n nodo actual
   * @param out campos encontrados
   */
  private void collect(JsonNode n, Map<Integer, String> out) {
    if (n.hasNonNull("parameterName")) {
      add(out, n.get("parameterName").asText(), n.path("parameterValue").asText(""));
      return;
    }
    for (java.util.Iterator<String> it = n.fieldNames(); it.hasNext(); ) {
      String key = it.next();
      add(out, key, n.get(key).asText(""));
    }
  }

  /**
   * Guarda el campo si su nombre es válido y el número está entre 1 y 100.
   *
   * @param out campos encontrados
   * @param name nombre del campo
   * @param value valor
   */
  private void add(Map<Integer, String> out, String name, String value) {
    Matcher m = USER_FIELD.matcher(name == null ? "" : name.trim());
    if (m.matches()) {
      int i = Integer.parseInt(m.group(1));
      if (i >= 1 && i <= 100) {
        out.put(i, value);
      }
    }
  }
}
