package com.banamex.app.mapper;

import com.banamex.app.dto.ControlFieldDto;
import com.banamex.app.dto.UpdateOfferResponse;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import javax.xml.parsers.DocumentBuilderFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 * Convierte la respuesta del EMS (XML o JSON) en {@code UpdateOfferResponse}. Acepta varios nombres
 * de campo para el código, la descripción y la referencia; si faltan, el código es {@code ERROR}.
 */
@Component
@RequiredArgsConstructor
public class UpdateOfferResponseXmlMapper {

  /** Lee las respuestas en JSON. */
  private final ObjectMapper jsonMapper;

  /**
   * Convierte la respuesta del EMS en una sola respuesta REST.
   *
   * @param reply respuesta cruda del EMS
   * @return respuesta REST
   * @throws IllegalStateException si la respuesta está vacía o no se puede leer
   */
  public UpdateOfferResponse fromReply(String reply) {
    if (reply == null || reply.isBlank()) {
      throw new IllegalStateException("Respuesta vacía del EMS");
    }
    return reply.trim().startsWith("{") ? fromJson(reply) : fromXml(reply);
  }

  /**
   * Una respuesta por oferta: si el XML trae varios {@code UpdateOfferRes}, devuelve uno por cada
   * uno, en el mismo orden.
   *
   * @param reply respuesta cruda del EMS
   * @return respuestas leídas
   * @throws IllegalStateException si la respuesta está vacía o no se puede leer
   */
  public List<UpdateOfferResponse> fromReplies(String reply) {
    if (reply == null || reply.isBlank()) {
      throw new IllegalStateException("Respuesta vacía del EMS");
    }
    if (reply.trim().startsWith("{")) {
      return List.of(fromJson(reply));
    }
    try {
      Document doc = parse(reply);
      List<Element> items = elements(doc, "UpdateOfferRes");
      if (items.isEmpty()) {
        return List.of(fromNode(doc));
      }
      List<UpdateOfferResponse> out = new ArrayList<>();
      for (Element item : items) {
        out.add(fromNode(item));
      }
      return out;
    } catch (Exception e) {
      throw new IllegalStateException(
          "No se pudo leer la respuesta XML del EMS: " + e.getMessage(), e);
    }
  }

  /**
   * Lee una respuesta en XML.
   *
   * @param xml respuesta
   * @return respuesta REST
   */
  private UpdateOfferResponse fromXml(String xml) {
    try {
      return fromNode(parse(xml));
    } catch (Exception e) {
      throw new IllegalStateException(
          "No se pudo leer la respuesta XML del EMS: " + e.getMessage(), e);
    }
  }

  /**
   * Lee los campos de un documento completo o de un solo {@code UpdateOfferRes}.
   *
   * @param root nodo raíz
   * @return respuesta REST
   */
  private UpdateOfferResponse fromNode(Node root) {
    List<ControlFieldDto> controlFields = new ArrayList<>();
    for (Element e : elements(root, "ControlField")) {
      controlFields.add(ControlFieldDto.builder().contextType(e.getTextContent()).build());
    }
    return build(
        xmlFirst(root, "Code", "ResponseCode", "ReturnCode"),
        xmlFirst(root, "Description", "ResponseText", "Message"),
        xmlFirst(root, "CustomerReferenceNumber", "ReferenceContacto", "ContactReference"),
        xmlFirst(root, "StartDate"),
        xmlFirst(root, "EndDate"),
        xmlFirst(root, "SurveyModeCode", "ModeCmp"),
        controlFields);
  }

  /**
   * Lee una respuesta en JSON.
   *
   * @param json respuesta
   * @return respuesta REST
   */
  private UpdateOfferResponse fromJson(String json) {
    try {
      JsonNode root = jsonMapper.readTree(json);
      return build(
          jsonFirst(root, "code", "responseCode", "returnCode"),
          jsonFirst(root, "description", "responseText", "message"),
          jsonFirst(root, "customerReferenceNumber", "referenceContacto", "contactReference"),
          jsonFirst(root, "startDate"),
          jsonFirst(root, "endDate"),
          jsonFirst(root, "surveyModeCode", "modeCmp"),
          List.of());
    } catch (Exception e) {
      throw new IllegalStateException(
          "No se pudo leer la respuesta JSON del EMS: " + e.getMessage(), e);
    }
  }

  /**
   * Arma la respuesta; sin código usa {@code ERROR} y sin descripción un texto genérico.
   *
   * @param code código
   * @param description descripción
   * @param reference referencia del cliente
   * @param start fecha de inicio
   * @param end fecha de fin
   * @param surveyMode modo de encuesta
   * @param controlFields campos de control
   * @return respuesta REST
   */
  private UpdateOfferResponse build(
      String code,
      String description,
      String reference,
      String start,
      String end,
      String surveyMode,
      List<ControlFieldDto> controlFields) {
    return UpdateOfferResponse.builder()
        .code(code != null ? code : "ERROR")
        .description(description != null ? description : "Respuesta del EMS sin descripción")
        .customerReferenceNumber(reference)
        .startDate(start)
        .endDate(end)
        .surveyModeCode(surveyMode)
        .contextType(controlFields.isEmpty() ? null : controlFields)
        .build();
  }

  /**
   * Convierte el texto en un documento XML.
   *
   * @param xml texto XML
   * @return documento
   * @throws Exception si el XML no es válido
   */
  private Document parse(String xml) throws Exception {
    DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
    f.setNamespaceAware(true);
    f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
    f.setXIncludeAware(false);
    f.setExpandEntityReferences(false);
    return f.newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
  }

  /**
   * Primer valor de los elementos con alguno de esos nombres.
   *
   * @param root nodo raíz
   * @param names nombres posibles
   * @return valor, o {@code null}
   */
  private String xmlFirst(Node root, String... names) {
    for (String name : names) {
      List<Element> found = elements(root, name);
      if (!found.isEmpty()) {
        String t = found.get(0).getTextContent();
        if (t != null && !t.trim().isEmpty()) {
          return t.trim();
        }
      }
    }
    return null;
  }

  /**
   * Elementos con ese nombre local, sin importar el prefijo.
   *
   * @param root nodo raíz
   * @param localName nombre local
   * @return elementos encontrados
   */
  private List<Element> elements(Node root, String localName) {
    List<Element> out = new ArrayList<>();
    NodeList all =
        root instanceof Document d
            ? d.getElementsByTagName("*")
            : ((Element) root).getElementsByTagName("*");
    for (int i = 0; i < all.getLength(); i++) {
      Element e = (Element) all.item(i);
      String ln = e.getLocalName() != null ? e.getLocalName() : e.getTagName();
      if (ln.equalsIgnoreCase(localName)) {
        out.add(e);
      }
    }
    return out;
  }

  /**
   * Busca recursivamente el primer valor simple cuyo nombre coincida, sin importar mayúsculas.
   *
   * @param root nodo raíz
   * @param names nombres posibles
   * @return valor, o {@code null}
   */
  private String jsonFirst(JsonNode root, String... names) {
    for (String name : names) {
      AtomicReference<String> found = new AtomicReference<>();
      search(root, name, found);
      if (found.get() != null) {
        return found.get();
      }
    }
    return null;
  }

  /**
   * Recorre el árbol JSON hasta encontrar un valor simple con ese nombre.
   *
   * @param n nodo actual
   * @param name nombre buscado
   * @param found valor encontrado
   */
  private void search(JsonNode n, String name, AtomicReference<String> found) {
    if (found.get() != null || n == null) {
      return;
    }
    if (n.isObject()) {
      for (java.util.Iterator<String> it = n.fieldNames(); it.hasNext(); ) {
        String key = it.next();
        JsonNode value = n.get(key);
        if (found.get() != null) {
          return;
        }
        if (key.equalsIgnoreCase(name) && value.isValueNode() && !value.isNull()) {
          found.set(value.asText());
        } else {
          search(value, name, found);
        }
      }
    } else if (n.isArray()) {
      n.forEach(c -> search(c, name, found));
    }
  }
}
