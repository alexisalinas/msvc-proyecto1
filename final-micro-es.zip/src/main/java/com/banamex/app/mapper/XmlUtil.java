package com.banamex.app.mapper;

/** Utilidades para escribir XML a mano. */
public final class XmlUtil {

  /** No se instancia. */
  private XmlUtil() {}

  /**
   * Escapa los caracteres especiales de XML para usar el texto dentro de un elemento.
   *
   * @param s texto
   * @return texto escapado
   */
  public static String esc(String s) {
    if (s == null) {
      return "";
    }
    return s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;");
  }

  /**
   * Escribe {@code <name>value</name>}.
   *
   * @param x destino
   * @param indent sangría
   * @param name nombre del elemento
   * @param value valor
   */
  static void tag(StringBuilder x, String indent, String name, String value) {
    if (value == null) {
      return;
    }
    x.append(indent)
        .append('<')
        .append(name)
        .append('>')
        .append(esc(value))
        .append("</")
        .append(name)
        .append(">\n");
  }

  /**
   * Igual que {@code tag}, pero un valor nulo o vacío se escribe como {@code <name/>}.
   *
   * @param x destino
   * @param indent sangría
   * @param name nombre del elemento
   * @param value valor
   */
  static void tagOrEmpty(StringBuilder x, String indent, String name, String value) {
    if (value == null || value.isEmpty()) {
      x.append(indent).append('<').append(name).append("/>\n");
    } else {
      tag(x, indent, name, value);
    }
  }
}
