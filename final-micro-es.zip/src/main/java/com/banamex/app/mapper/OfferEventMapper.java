package com.banamex.app.mapper;

import com.banamex.app.config.OfferJmsProperties;
import com.banamex.app.dto.UpdateOfferRequest;
import com.banamex.app.dto.timezonevalidation.DateGrpDto;
import com.banamex.app.dto.timezonevalidation.MapRequestResultDto;
import com.banamex.app.dto.timezonevalidation.TimeGrpDto;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Convierte la oferta recibida en los campos del evento {@code UpdateOffer} que se manda al EMS.
 * Los campos obligatorios siempre se escriben (vacíos si no hay dato) y los opcionales solo si
 * traen valor. Si la zona horaria está activa y la validación fue correcta, la fecha y las horas de
 * la cita salen ya convertidas.
 */
@Component
@RequiredArgsConstructor
public class OfferEventMapper {

  /** Formato de la hora de actualización sin offset. */
  private static final DateTimeFormatter TS =
      DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");

  /** Formato de la hora de actualización con offset. */
  private static final DateTimeFormatter TS_OFFSET =
      DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

  /** Configuración del relleno del número de cliente. */
  private final OfferJmsProperties props;

  /** Extrae los campos de usuario del {@code userText}. */
  private final UserTextParser userTextParser;

  /** Si es {@code true}, se usan la fecha y las horas convertidas. */
  @Value("${update-offer.timezone.translate-time-zone:true}")
  private boolean translateTimeZone;

  /** Zona en la que se escribe la hora de actualización cuando la zona horaria está activa. */
  @Value("${update-offer.timezone.ecrm-time-zone:US/Central}")
  private String ecrmTimeZone;

  /**
   * Convierte la oferta en los campos del evento, en el orden en que se envían.
   *
   * @param rq oferta recibida
   * @param requestTime hora en que se empezó a procesar la oferta
   * @param updatedBy valor del header {@code client_id}
   * @param tzResponseCode código de la validación de zona horaria, o {@code null} si no se validó
   * @param tz fechas y horas convertidas, o {@code null} si no se validó
   * @return campos del evento, de nombre a valor
   */
  public Map<String, String> map(
      UpdateOfferRequest rq,
      LocalDateTime requestTime,
      String updatedBy,
      String tzResponseCode,
      MapRequestResultDto tz) {
    Map<String, String> o = new LinkedHashMap<>();

    req(o, "RequestingChannel", rq.getChannelCode());
    req(o, "CampaignID", rq.getCampaignId());
    req(o, "WaveID", rq.getWaveId());
    req(o, "AccountNO", rq.getAccountNumber());
    req(o, "CardNO", rq.getCardNumber());
    req(o, "AssignedBy", rq.getAssignedBy());
    opt(o, "AgentID", rq.getAssignedTo());

    boolean tzActive = translateTimeZone && tz != null && tzOk(tzResponseCode);
    if (hasText(rq.getAppointmentDate())) {
      String tzDate = tzActive ? tzDate(tz, "AppointmentDate") : null;
      o.put("ApptDate", tzDate != null ? tzDate : rq.getAppointmentDate());
    }
    String tzStart = tzActive ? tzTime(tz, "AppointmentStartTime") : null;
    req(
        o,
        "ApptStartTime",
        tzStart != null ? tzStart : withoutSeconds(rq.getAppointmentStartTime()));
    String tzEnd = tzActive ? tzTime(tz, "AppointmentEndTime") : null;
    req(o, "ApptEndTime", tzEnd != null ? tzEnd : withoutSeconds(rq.getAppointmentEndTime()));

    opt(o, "ApptConfirmation", rq.getOfferedNumber());
    req(o, "ReasonCode", rq.getReasonCode());
    req(o, "ReasonDescription", rq.getReasonDescription());
    req(o, "Comments", rq.getComments());
    req(o, "ContactNumber", rq.getContactIndicatorNumber());
    req(o, "OfferStatus", rq.getOfferStatus());
    req(o, "SysVersion", rq.getSchemaVersion());

    req(o, "CustomerNO", customerNo(rq.getCustomerId()));
    req(o, "OfferSource", rq.getOfferSource());
    Map<Integer, String> uf = userTextParser.parse(rq.getUserText());
    for (int i = 1; i <= 100; i++) {
      if (i <= 20 || i == 29) {
        req(o, "UserField" + i, uf.get(i));
      } else {
        opt(o, "UserField" + i, uf.get(i));
      }
    }
    req(o, "OfferAction", rq.getOfferActionCode());
    req(o, "GiftCode", rq.getGiftCode());
    req(o, "GiftConfirmationNO", rq.getGiftConfirmationNumber());
    opt(o, "FulfillmentReferencedNO", rq.getFulfillmentTrackerFlag());
    opt(o, "ProbabilityAmount", rq.getAmount());
    opt(o, "Department", rq.getDepartmentId());
    opt(o, "Branch", rq.getBranchId());
    req(o, "ContactReference", rq.getCustomerReferenceNumber());
    opt(o, "Priority", rq.getOfferPriority());
    opt(o, "Workgroup", rq.getWorkgroupId());
    req(o, "LVCode", rq.getLevelCode());
    req(o, "UpdatedBy", updatedBy);
    req(
        o,
        "UpdateTime",
        tzActive
            ? OffsetDateTime.now(ZoneId.of(ecrmTimeZone)).format(TS_OFFSET)
            : (requestTime != null ? requestTime.format(TS) : null));
    opt(o, "ControlField", contextTypeAt(rq, 0));

    opt(o, "AreaID", rq.getAreaIdentifier());
    opt(o, "DivisionID", rq.getDivisionCode());
    opt(o, "RegionID", rq.getBranchRegionIdentifier());
    opt(o, "AgentName", rq.getAgentName());
    req(o, "ContactType", rq.getContactType());
    req(o, "ContactInfo", rq.getContactIndicatorNumber());
    opt(o, "OfferCategory", rq.getOfferCategory());
    opt(o, "BranchName", rq.getBranchName());
    req(o, "DepartmentName", rq.getDepartmentName());
    opt(o, "ChannelResponse", rq.getResponseChannel());
    opt(o, "Purpose", rq.getPurpose());
    opt(o, "LocationIndicator", contextTypeAt(rq, 1));
    opt(o, "CustomerEmail", rq.getCustomerEmailAddress());
    opt(o, "FulfillmentScript", rq.getFulfillmentCode());
    return o;
  }

  /**
   * Fecha convertida con ese nombre.
   *
   * @param tz resultado de la conversión
   * @param name nombre de la fecha
   * @return fecha convertida, o {@code null}
   */
  private String tzDate(MapRequestResultDto tz, String name) {
    return tz.getDateGrp().stream()
        .filter(g -> name.equalsIgnoreCase(g.getDateName()))
        .map(DateGrpDto::getDate)
        .findFirst()
        .orElse(null);
  }

  /**
   * Hora convertida con ese nombre.
   *
   * @param tz resultado de la conversión
   * @param name nombre de la hora
   * @return hora convertida, o {@code null}
   */
  private String tzTime(MapRequestResultDto tz, String name) {
    return tz.getTimeGrp().stream()
        .filter(g -> name.equalsIgnoreCase(g.getTimeName()))
        .map(TimeGrpDto::getTime)
        .findFirst()
        .orElse(null);
  }

  /**
   * Quita los segundos a una hora {@code HH:mm:ss}; si no tiene tres partes, la deja igual.
   *
   * @param t hora
   * @return hora sin segundos, o cadena vacía si es nula
   */
  private static String withoutSeconds(String t) {
    if (t == null || t.isEmpty()) {
      return "";
    }
    return t.split(":", -1).length == 3 ? t.substring(0, t.lastIndexOf(':')) : t;
  }

  /**
   * La validación de zona horaria fue correcta si el código termina en {@code 0}.
   *
   * @param responseCode código de la validación
   * @return {@code true} si fue correcta
   */
  private static boolean tzOk(String responseCode) {
    return responseCode != null
        && !responseCode.isEmpty()
        && responseCode.charAt(responseCode.length() - 1) == '0';
  }

  /**
   * Número de cliente, rellenado a la izquierda si el relleno está activo.
   *
   * @param v número de cliente
   * @return número de cliente para el evento
   */
  private String customerNo(String v) {
    if (v == null || v.isEmpty()) {
      return "";
    }
    return props.isCustomerPadding()
        ? padFront(v, props.getCustomerPaddingLength(), props.getCustomerPaddingChar())
        : v;
  }

  /**
   * Rellena a la izquierda con el carácter indicado hasta la longitud pedida.
   *
   * @param v texto
   * @param len longitud deseada
   * @param c carácter de relleno
   * @return texto completado
   */
  private static String padFront(String v, int len, char c) {
    StringBuilder sb = new StringBuilder();
    for (int i = v.length(); i < len; i++) {
      sb.append(c);
    }
    return sb.append(v).toString();
  }

  /**
   * Valor de {@code contextType} en la posición indicada.
   *
   * @param rq oferta
   * @param idx posición
   * @return valor, o {@code null} si no existe
   */
  private String contextTypeAt(UpdateOfferRequest rq, int idx) {
    return rq.getContextType() != null
            && idx < rq.getContextType().size()
            && rq.getContextType().get(idx) != null
        ? rq.getContextType().get(idx).getContextType()
        : null;
  }

  /**
   * Indica si el texto tiene contenido.
   *
   * @param s texto
   * @return {@code true} si no es nulo ni está en blanco
   */
  private static boolean hasText(String s) {
    return s != null && !s.trim().isEmpty();
  }

  /**
   * Campo obligatorio: siempre se escribe (vacío si no hay dato).
   *
   * @param m campos
   * @param k nombre
   * @param v valor
   */
  private static void req(Map<String, String> m, String k, String v) {
    m.put(k, v == null ? "" : v);
  }

  /**
   * Campo opcional: solo se escribe si trae valor.
   *
   * @param m campos
   * @param k nombre
   * @param v valor
   */
  private static void opt(Map<String, String> m, String k, String v) {
    if (v != null) {
      m.put(k, v);
    }
  }
}
