package com.banamex.app.validation;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import java.util.List;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Aplica las reglas de validación (obligatorio, opcional, lista) que llevan los DTO internos del
 * flujo.
 */
@Component
public class DtoValidator {

  /** Validador de Jakarta Validation. */
  private final Validator validator;

  /**
   * Constructor que usa Spring: toma el validador del contexto o, si no existe, crea uno por
   * defecto.
   *
   * @param provider proveedor del validador
   */
  @Autowired
  public DtoValidator(ObjectProvider<Validator> provider) {
    Validator v = provider.getIfAvailable();
    this.validator = v != null ? v : Validation.buildDefaultValidatorFactory().getValidator();
  }

  /**
   * Constructor con un validador ya creado (útil en las pruebas).
   *
   * @param validator validador
   */
  public DtoValidator(Validator validator) {
    this.validator = validator;
  }

  /**
   * Reglas incumplidas del DTO.
   *
   * @param dto objeto a validar
   * @return lista ordenada de {@code ruta: mensaje}, vacía si cumple todo
   */
  public List<String> violations(Object dto) {
    return validator.validate(dto).stream()
        .map((ConstraintViolation<Object> v) -> v.getPropertyPath() + ": " + v.getMessage())
        .sorted()
        .toList();
  }

  /**
   * Lanza una excepción con el detalle si el DTO incumple alguna regla.
   *
   * @param dto objeto a validar
   * @throws IllegalArgumentException si hay reglas incumplidas
   */
  public void validateOrThrow(Object dto) {
    List<String> v = violations(dto);
    if (!v.isEmpty()) {
      throw new IllegalArgumentException(
          "Datos inválidos en " + dto.getClass().getSimpleName() + ": " + String.join("; ", v));
    }
  }
}
