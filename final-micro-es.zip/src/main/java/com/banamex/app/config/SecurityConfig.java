package com.banamex.app.config;

import com.citibanamex.messaging.connector.ems.config.EmsConfig;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Configuración de seguridad web: sin CSRF y con todas las rutas abiertas; la validación de headers
 * la hace la librería de errores.
 */
@Configuration("updateoffer_SecurityConfig")
@EnableWebSecurity
@Import(EmsConfig.class)
public class SecurityConfig {

  /**
   * Cadena de filtros de seguridad.
   *
   * @param http configuración HTTP de Spring Security
   * @return cadena de filtros
   * @throws Exception si no se puede construir
   */
  @Bean
  public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    http.csrf(AbstractHttpConfigurer::disable)
        .authorizeHttpRequests(auth -> auth.anyRequest().permitAll());
    return http.build();
  }
}
