package com.banamex.app.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/** Relleno del número de cliente que se manda al EMS ({@code update-offer.jms-requestor.*}). */
@Data
@Component
@ConfigurationProperties(prefix = "update-offer.jms-requestor")
public class OfferJmsProperties {

  /** Si es {@code true}, el número de cliente se rellena a la izquierda. */
  private boolean customerPadding;

  /** Longitud final del número de cliente. */
  private int customerPaddingLength = 19;

  /** Carácter de relleno. */
  private char customerPaddingChar = '0';
}
