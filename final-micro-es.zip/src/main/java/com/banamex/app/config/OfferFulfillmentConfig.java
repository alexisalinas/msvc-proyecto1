package com.banamex.app.config;

import com.banamex.cops.app.service.impl.CopOfferFulfillmentServiceImpl;
import com.banamex.cops.app.service.impl.CopSuppressionServiceImpl;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * Conecta el micro con las consultas de la librería {@code chnn-cop-lib-operation-db}: registra sus
 * servicios y activa sus repositorios JPA (consultas nativas).
 */
@Configuration
@Import({CopOfferFulfillmentServiceImpl.class, CopSuppressionServiceImpl.class})
@EnableJpaRepositories(basePackages = "com.banamex.cops.app.repository")
public class OfferFulfillmentConfig {}
