package com.banamex.app.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Configuration;

/**
 * Registra las entidades JPA del micro y de la librería de base de datos para evitar el error
 * {@code Not a managed type}.
 */
@Configuration
@EntityScan(basePackages = {"com.banamex.app", "com.banamex.cops.app"})
public class EntityScanConfig {}
