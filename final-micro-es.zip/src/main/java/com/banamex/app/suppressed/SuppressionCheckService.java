package com.banamex.app.suppressed;

import com.banamex.app.dto.suppression.FilteredSuppressionList;
import com.banamex.app.dto.suppression.FilteredSuppressionResult;
import com.banamex.app.dto.suppression.OperationDetailOutput;
import com.banamex.app.dto.suppression.StartRequest;
import com.banamex.app.dto.suppression.StartRequestParams;
import com.banamex.app.dto.suppression.SuppressedEntitiesListRoot;
import com.banamex.app.dto.suppression.SuppressedEntityDto;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 * Filtra la lista de entidades suprimidas con los datos de la petición. Una entidad coincide si es
 * del canal y país de la petición, con bandera de supresión {@code Y}, modo {@code RT} y sistema
 * origen {@code ECRM}. Dentro de ella, la operación está suprimida si su nombre está contenido en
 * el de la operación en curso, el canal coincide y su bandera es {@code Y}; entonces el resultado
 * es {@code COP_OPSUP_001}.
 */
@Service
public class SuppressionCheckService {

  /**
   * Devuelve las entidades suprimidas que coinciden con la petición.
   *
   * @param request canal, país y operación a revisar
   * @param suppressed lista de entidades suprimidas
   * @return entidades que coinciden, con las operaciones suprimidas
   */
  public FilteredSuppressionList checkIfSuppressed(
      StartRequest request, SuppressedEntitiesListRoot suppressed) {
    StartRequestParams p = request.getRequestParams();

    List<FilteredSuppressionResult> results =
        suppressed.getSuppressedEntities().stream()
            .filter(
                e ->
                    p.getRequestingChannel() != null
                        && p.getRequestingChannel().equals(e.getChannelId()))
            .filter(
                e ->
                    p.getCountryCode().equals(e.getCountryCode())
                        && "Y".equals(e.getSuppressionFlag())
                        && "RT".equals(e.getMode())
                        && "ECRM".equals(e.getSourceSystem()))
            .map(e -> toResult(e, p))
            .toList();

    FilteredSuppressionList out = new FilteredSuppressionList();
    out.setResults(results);
    return out;
  }

  /**
   * Convierte una entidad en resultado, dejando solo las operaciones suprimidas con su código y
   * texto de respuesta.
   *
   * @param e entidad
   * @param p datos de la petición
   * @return resultado
   */
  private FilteredSuppressionResult toResult(SuppressedEntityDto e, StartRequestParams p) {
    FilteredSuppressionResult r = new FilteredSuppressionResult();
    r.setCountryCode(e.getCountryCode());
    r.setChannelId(e.getChannelId());
    r.setSuppressionFlag(e.getSuppressionFlag());
    r.setOperationFlag(e.getOperationFlag());
    r.setMode(e.getMode());
    r.setSourceSystem(e.getSourceSystem());

    List<OperationDetailOutput> details =
        e.getOperationDetails().stream()
            .filter(d -> p.getCurrentOperationName().contains(d.getOperationName()))
            .filter(
                d ->
                    p.getRequestingChannel().equals(d.getReqChannel())
                        && "Y".equals(d.getOperationFlag()))
            .map(
                d -> {
                  OperationDetailOutput o = new OperationDetailOutput();
                  o.setOperationName(d.getOperationName());
                  o.setReqChannel(d.getReqChannel());
                  o.setOperationFlag(d.getOperationFlag());
                  o.setCountryCode(p.getCountryCode());
                  o.setIndicator("true");
                  o.setResponseCode("COP_OPSUP_001");
                  o.setResponseText(
                      "The " + d.getOperationName() + " operation is temporarily unavailable");
                  return o;
                })
            .toList();

    r.setOperationDetails(details);
    return r;
  }
}
