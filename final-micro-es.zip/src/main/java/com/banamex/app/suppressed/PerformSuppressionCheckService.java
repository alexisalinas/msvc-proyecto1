package com.banamex.app.suppressed;

import com.banamex.app.dto.suppression.FilteredSuppressionList;
import com.banamex.app.dto.suppression.StartRequest;
import com.banamex.app.dto.suppression.SuppressedEntitiesListRoot;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * Revisa si la operación está suprimida. Con {@code cop.suppression.check-for-suppression=Y}
 * obtiene la lista de entidades suprimidas y la filtra con los datos de la petición; con cualquier
 * otro valor no revisa nada.
 */
@Slf4j
@Service
public class PerformSuppressionCheckService {

  /** Entrega la lista de entidades suprimidas. */
  private final SuppressedEntitiesClient suppressedEntitiesClient;

  /** Filtra la lista con los datos de la petición. */
  private final SuppressionCheckService checkService;

  /**
   * Crea el servicio.
   *
   * @param suppressedEntitiesClient cliente de la lista de entidades suprimidas
   * @param checkService filtro de la lista
   */
  public PerformSuppressionCheckService(
      @Qualifier("dbSuppressedEntitiesClient") SuppressedEntitiesClient suppressedEntitiesClient,
      SuppressionCheckService checkService) {
    this.suppressedEntitiesClient = suppressedEntitiesClient;
    this.checkService = checkService;
  }

  /** {@code Y} para revisar la supresión; cualquier otro valor la omite. */
  @Value("${cop.suppression.check-for-suppression:N}")
  private String checkForSuppression;

  /**
   * Consulta la lista de entidades suprimidas y devuelve las que coinciden con la petición. Si la
   * revisión está desactivada o ocurre un error, devuelve un resultado vacío (la operación no se
   * considera suprimida).
   *
   * @param request canal, país y operación a revisar
   * @return entidades que coinciden; vacía si no se revisa o falla la consulta
   */
  public FilteredSuppressionList perform(StartRequest request) {
    try {
      if ("Y".equals(checkForSuppression)) {
        SuppressedEntitiesListRoot suppressed =
            suppressedEntitiesClient.getListOfSuppressedEntities(request.getRequestParams());
        return checkService.checkIfSuppressed(request, suppressed);
      }

      return empty();

    } catch (Exception ex) {
      log.error("Error en PerformSuppressionCheck", ex);
      return empty();
    }
  }

  /**
   * Resultado vacío, sin entidades que coincidan.
   *
   * @return resultado vacío, sin entidades que coincidan
   */
  private FilteredSuppressionList empty() {
    FilteredSuppressionList out = new FilteredSuppressionList();
    out.setResults(List.of());
    return out;
  }
}
