package com.banamex.app.suppressed;

import com.banamex.app.dto.suppression.StartRequestParams;
import com.banamex.app.dto.suppression.SuppressedEntitiesListRoot;
import com.banamex.cops.app.model.CopSuppressionChannel;
import com.banamex.cops.app.model.CopSuppressionOperation;
import com.banamex.cops.app.service.CopSuppressionService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Entrega la lista de entidades suprimidas leyéndola de la base de datos (tablas de canales y de
 * operaciones suprimidas). La primera consulta la carga y la deja en memoria; las siguientes usan
 * esa copia.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DbSuppressedEntitiesClient implements SuppressedEntitiesClient {

  /** Servicio de la librería, que se obtiene hasta que se usa. */
  private final ObjectProvider<CopSuppressionService> suppressionService;

  /** Arma la lista a partir de las filas de la base. */
  private final StartUpSuppressionLoader loader;

  /** Tiempo máximo de las consultas, en segundos. */
  @Value("${cop.suppression.query-timeout-seconds:30}")
  private int queryTimeoutSeconds = 30;

  /** Filas máximas de las consultas; 0 = sin límite. */
  @Value("${cop.suppression.max-rows:0}")
  private int maxRows = 0;

  /** Lista ya armada, en memoria. */
  private volatile SuppressedEntitiesListRoot cached;

  /**
   * Devuelve la lista de entidades suprimidas; la primera vez la carga de la base.
   *
   * @param params datos de la petición (no se usan para filtrar)
   * @return lista de entidades suprimidas
   */
  @Override
  public SuppressedEntitiesListRoot getListOfSuppressedEntities(StartRequestParams params) {
    SuppressedEntitiesListRoot list = cached;
    if (list == null) {
      synchronized (this) {
        list = cached;
        if (list == null) {
          list = load();
          cached = list;
        }
      }
    }
    return list;
  }

  /**
   * Vuelve a cargar la lista de la base y reemplaza la que está en memoria.
   *
   * @return lista recién cargada
   */
  public synchronized SuppressedEntitiesListRoot reload() {
    SuppressedEntitiesListRoot list = load();
    cached = list;
    return list;
  }

  /**
   * Consulta canales y operaciones suprimidos y arma la lista.
   *
   * @return lista armada
   */
  private SuppressedEntitiesListRoot load() {
    CopSuppressionService service =
        suppressionService
            .orderedStream()
            .findFirst()
            .orElseThrow(
                () ->
                    new IllegalStateException(
                        "CopSuppressionService no está disponible: revisa que exista"
                            + " OfferFulfillmentConfig (registra las consultas de la librería) y"
                            + " que haya un spring.datasource configurado"));
    List<CopSuppressionChannel> channels = service.findAllChannels(queryTimeoutSeconds, maxRows);
    List<CopSuppressionOperation> operations =
        service.findAllOperations(queryTimeoutSeconds, maxRows);
    SuppressedEntitiesListRoot list = loader.build(channels, operations);
    log.debug(
        "startUpSuppression: {} entidades suprimidas cargadas",
        list.getSuppressedEntities().size());
    return list;
  }
}
