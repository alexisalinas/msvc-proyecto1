package com.banamex.app.service;

import com.banamex.app.dto.UpdateOfferHeaders;
import com.banamex.app.dto.UpdateOfferRequest;
import com.banamex.app.dto.UpdateOfferResponse;
import java.util.List;

/** Contrato del servicio que atiende la actualización de ofertas. */
public interface UpdateOfferService {

  /**
   * Procesa las ofertas de la petición, una por una.
   *
   * @param requests ofertas recibidas en el body
   * @param headers headers de la petición
   * @return una respuesta por oferta, en el mismo orden
   */
  List<UpdateOfferResponse> updateOffer(
      List<UpdateOfferRequest> requests, UpdateOfferHeaders headers);
}
