package com.banamex.app.service.impl;

import com.banamex.app.audit.AuditLogService;
import com.banamex.app.dto.UpdateOfferHeaders;
import com.banamex.app.dto.UpdateOfferRequest;
import com.banamex.app.dto.UpdateOfferResponse;
import com.banamex.app.dto.suppression.FilteredSuppressionList;
import com.banamex.app.dto.suppression.StartRequest;
import com.banamex.app.dto.suppression.StartRequestParams;
import com.banamex.app.dto.timezonevalidation.MapRequestResultDto;
import com.banamex.app.dto.timezonevalidation.TimeZoneValidationResult;
import com.banamex.app.dto.timezonevalidation.TimeZoneValidationStartDto;
import com.banamex.app.dto.timezonevalidation.ValueItemDto;
import com.banamex.app.kafka.KafkaSenderDashboard;
import com.banamex.app.mapper.UpdateOfferMapper;
import com.banamex.app.sender.EmsSender;
import com.banamex.app.sender.OfferFulfillmentEmsSender;
import com.banamex.app.service.UpdateOfferResponseFactory;
import com.banamex.app.service.UpdateOfferService;
import com.banamex.app.service.timezonevalidation.TimeZoneValidationService;
import com.banamex.app.service.timezonevalidation.UpdateOfferFlowConditions;
import com.banamex.app.suppressed.PerformSuppressionCheckService;
import com.banamex.app.validation.DtoValidator;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * Flujo de actualización de una oferta. Por cada oferta de la petición:
 *
 * <ol>
 *   <li>Si {@code update-offer.timezone.translate-time-zone} es {@code true}, valida y convierte la
 *       fecha y las horas de la cita a la zona del backend ({@link TimeZoneValidationService}). Si
 *       el código resultante no permite continuar, responde con ese código.
 *   <li>Revisa la supresión de la operación para el canal y el país ({@link
 *       PerformSuppressionCheckService}). Si está suprimida, responde con el código de supresión.
 *   <li>Arma el XML y las propiedades del mensaje ({@link UpdateOfferMapper}) y los envía al EMS
 *       esperando su respuesta ({@link EmsSender}).
 *   <li>Encola el evento de cumplimiento de la oferta ({@link OfferFulfillmentEmsSender}); no
 *       bloquea la respuesta.
 *   <li>Arma la respuesta de la oferta ({@link UpdateOfferResponseFactory}).
 * </ol>
 *
 * <p>Si un paso falla, la oferta responde con el código de error y el nombre del paso; las demás
 * ofertas siguen.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class UpdateOfferServiceImpl implements UpdateOfferService {

  /** Nombre de la operación que se busca en la lista de supresión. */
  private static final String OPERATION_NAME = "UpdateOffer";

  /** Header del que sale {@code UpdatedBy} en el mensaje al EMS. */
  private static final String CLIENT_ID_HEADER = "client_id";

  /** Envía el mensaje al EMS y espera la respuesta. */
  private final EmsSender emsSender;

  /**
   * Convierte la oferta en el XML y las propiedades del EMS, y la respuesta del EMS en respuesta
   * REST.
   */
  private final UpdateOfferMapper updateOfferMapper;

  /** Escribe en el log la petición recibida y la respuesta final. */
  private final AuditLogService auditLogService;

  /** Revisa si la operación está suprimida para el canal y el país. */
  private final PerformSuppressionCheckService suppressionCheckService;

  /** Valida y convierte fechas y horas entre la zona del cliente y la del backend. */
  private final TimeZoneValidationService timeZoneValidationService;

  /** Arma el evento de entrada del envío de cumplimiento. */
  private final KafkaSenderDashboard kafkaSenderDashboard;

  /** Publica el evento de cumplimiento de la oferta en los destinos activos. */
  private final OfferFulfillmentEmsSender offerFulfillmentEmsSender;

  /** Valida las reglas de los DTO internos antes de usarlos. */
  private final DtoValidator dtoValidator;

  /** Arma las respuestas de éxito y de error de cada oferta. */
  private final UpdateOfferResponseFactory responses;

  /** Si es {@code true}, se valida y convierte la zona horaria antes de continuar. */
  @Value("${update-offer.timezone.translate-time-zone:true}")
  private boolean translateTimeZone;

  /**
   * Bandera de pruebas {@code update-offer.ab-initio-test}. Con {@code Y} solo se escribe una
   * advertencia en el log: el micro no tiene un camino alterno de pruebas y la oferta sigue el
   * flujo normal.
   */
  @Value("${update-offer.ab-initio-test:N}")
  private String abInitioTest;

  /** Modo del sistema que se usa para buscar la configuración de zona horaria. */
  @Value("${update-offer.timezone.sys-mode:RealTime}")
  private String tzSysMode;

  /**
   * Escribe el log de entrada, procesa cada oferta y escribe el log de salida.
   *
   * @param requests ofertas recibidas
   * @param headers headers de la petición
   * @return una respuesta por oferta
   */
  @Override
  public List<UpdateOfferResponse> updateOffer(
      List<UpdateOfferRequest> requests, UpdateOfferHeaders headers) {
    auditLogService.logRequest(headers, requests);
    List<UpdateOfferResponse> responses =
        requests.stream().map(request -> procesarOferta(request, headers)).toList();
    auditLogService.logResponse(headers, responses);
    return responses;
  }

  /**
   * Procesa una oferta. Cualquier falla se convierte en una respuesta de error de esa oferta.
   *
   * @param request oferta a procesar
   * @param headers headers de la petición
   * @return respuesta de la oferta
   */
  private UpdateOfferResponse procesarOferta(
      UpdateOfferRequest request, UpdateOfferHeaders headers) {
    LocalDateTime requestTime = LocalDateTime.now();

    try {
      return ejecutar(request, headers, requestTime);
    } catch (StepFailedException e) {
      log.error("Falló '{}' uuid={}: {}", e.getStep(), headers.getUuid(), e.getCause().toString());
      return responses.error(e.getStep(), e.getCause());
    } catch (Exception e) {
      log.error("Falló el proceso de la oferta uuid={}", headers.getUuid(), e);
      return responses.error("Proceso de la oferta", e);
    }
  }

  /**
   * Ejecuta un paso y, si falla, lo marca con su nombre para saber en cuál falló.
   *
   * @param nombre nombre del paso
   * @param accion trabajo del paso
   * @param <T> tipo del resultado
   * @return resultado del paso
   */
  private <T> T paso(String nombre, Supplier<T> accion) {
    try {
      return accion.get();
    } catch (Exception e) {
      throw new StepFailedException(nombre, e);
    }
  }

  /** Un paso del flujo falló: lleva el nombre del paso y la causa. */
  private static final class StepFailedException extends RuntimeException {
    /** Nombre del paso que falló. */
    private final String step;

    /**
     * Crea la excepción del paso.
     *
     * @param step nombre del paso
     * @param cause causa de la falla
     */
    StepFailedException(String step, Throwable cause) {
      super(cause);
      this.step = step;
    }

    /**
     * Nombre del paso que falló.
     *
     * @return nombre del paso que falló
     */
    String getStep() {
      return step;
    }
  }

  /**
   * Ejecuta el flujo completo de una oferta: zona horaria, supresión, envío al EMS, evento de
   * cumplimiento y respuesta. Si el EMS falla, el evento de cumplimiento se envía igual (sin la
   * respuesta del EMS) y el error se propaga.
   *
   * @param request oferta a procesar
   * @param headers headers de la petición
   * @param requestTime hora en que se empezó a procesar la oferta
   * @return respuesta de la oferta
   */
  private UpdateOfferResponse ejecutar(
      UpdateOfferRequest request, UpdateOfferHeaders headers, LocalDateTime requestTime) {
    String tzResponseCode = null;
    MapRequestResultDto tz = null;
    if (translateTimeZone) {
      TimeZoneValidationStartDto start =
          TimeZoneValidationStartDto.builder()
              .system(headers.getChannelId())
              .sysMode(tzSysMode)
              .type("Request")
              .date(dates(request))
              .time(times(request))
              .build();
      TimeZoneValidationResult validation =
          paso(
              "Validación de zona horaria",
              () -> {
                dtoValidator.validateOrThrow(start);
                return timeZoneValidationService.validate(start);
              });
      if (!UpdateOfferFlowConditions.continueToSuppression(validation.getResponseCode())) {
        UpdateOfferResponse res = new UpdateOfferResponse();
        res.setCode(validation.getResponseCode());
        res.setDescription(validation.getResponseText());
        return res;
      }
      tzResponseCode = validation.getResponseCode();
      tz = validation.getMapResult();
    }

    UpdateOfferResponse suppressed =
        paso("Validación de supresión", () -> checkSuppression(request, headers));
    if (suppressed != null) {
      return suppressed;
    }

    if ("Y".equals(abInitioTest)) {
      log.warn(
          "AbInitioTest = Y uuid={}: el camino de AbInitio no está migrado; la oferta sigue por el"
              + " JMS",
          headers.getUuid());
    }

    final String codigoZona = tzResponseCode;
    final MapRequestResultDto zona = tz;
    String xml =
        paso(
            "Armado del XML para el EMS",
            () ->
                updateOfferMapper.toEmsXml(
                    request, requestTime, headers.get(CLIENT_ID_HEADER), codigoZona, zona));
    Map<String, String> propiedades =
        paso(
            "Armado de las propiedades del mensaje",
            () ->
                updateOfferMapper.toEmsProperties(
                    request, requestTime, headers.get(CLIENT_ID_HEADER), codigoZona, zona));
    String reply;
    try {
      reply = paso("Envío al EMS", () -> emsSender.send(xml, propiedades));
    } catch (StepFailedException e) {
      sendToKafka(request, headers, requestTime, null); // el evento no depende del EMS
      throw e;
    }
    UpdateOfferResponse emsResponse = leerRespuestaDelEms(reply);

    sendToKafka(request, headers, requestTime, emsResponse);

    return responses.success(request, emsResponse);
  }

  /**
   * Lee el código y el texto de la respuesta del EMS, que viajan en el evento de cumplimiento.
   *
   * @param reply respuesta cruda del EMS
   * @return respuesta leída, o {@code null} si no hubo respuesta o no se pudo leer
   */
  private UpdateOfferResponse leerRespuestaDelEms(String reply) {
    if (reply == null || reply.isBlank()) {
      return null;
    }
    try {
      return updateOfferMapper.toRestResponse(reply);
    } catch (Exception e) {
      log.warn("No se pudo leer la respuesta del EMS: {}", e.getMessage());
      return null;
    }
  }

  /**
   * Encola el evento de cumplimiento si hay un destino activo. Nunca propaga errores: el evento no
   * afecta la respuesta.
   *
   * @param request oferta procesada
   * @param headers headers de la petición
   * @param requestTime hora en que se empezó a procesar la oferta
   * @param response respuesta del EMS, o {@code null} si no hubo
   */
  private void sendToKafka(
      UpdateOfferRequest request,
      UpdateOfferHeaders headers,
      LocalDateTime requestTime,
      UpdateOfferResponse response) {
    try {
      if (offerFulfillmentEmsSender.isEnabled()) {
        offerFulfillmentEmsSender.sendAsync(
            kafkaSenderDashboard.build(request, headers, requestTime, response));
      } else {
        log.info("[KAFKA] Resultado: {}", responses.kafkaDisabledText());
      }
    } catch (Exception e) {
      log.error("KAFKA-ERROR no se pudo encolar uuid={}: {}", headers.getUuid(), e.toString(), e);
    }
  }

  /**
   * Fechas de la oferta que se validan: la de la cita.
   *
   * @param r oferta
   * @return lista con la fecha, o vacía
   */
  private List<ValueItemDto> dates(UpdateOfferRequest r) {
    return hasText(r.getAppointmentDate())
        ? List.of(new ValueItemDto(r.getAppointmentDate(), "AppointmentDate"))
        : List.of();
  }

  /**
   * Horas de la oferta que se validan: inicio y fin de la cita, con el nombre con el que se leen
   * después.
   *
   * @param r oferta
   * @return lista con las horas que traen valor
   */
  private List<ValueItemDto> times(UpdateOfferRequest r) {
    List<ValueItemDto> out = new ArrayList<>();
    if (hasText(r.getAppointmentStartTime())) {
      out.add(new ValueItemDto(r.getAppointmentStartTime(), "AppointmentStartTime"));
    }
    if (hasText(r.getAppointmentEndTime())) {
      out.add(new ValueItemDto(r.getAppointmentEndTime(), "AppointmentEndTime"));
    }
    return out;
  }

  /**
   * Indica si el texto tiene contenido.
   *
   * @param s texto a revisar
   * @return {@code true} si no es nulo ni está en blanco
   */
  private static boolean hasText(String s) {
    return s != null && !s.trim().isEmpty();
  }

  /**
   * Revisa si la operación está suprimida para el canal y el país de la oferta.
   *
   * @param request oferta
   * @param headers headers de la petición
   * @return la respuesta de supresión, o {@code null} si la operación no está suprimida
   */
  private UpdateOfferResponse checkSuppression(
      UpdateOfferRequest request, UpdateOfferHeaders headers) {
    StartRequestParams params = new StartRequestParams();
    params.setRequestingChannel(request.getChannelCode());
    params.setCountryCode(headers.getCountryCode());
    params.setCurrentOperationName(OPERATION_NAME);

    StartRequest startRequest = new StartRequest();
    startRequest.setRequestParams(params);
    dtoValidator.validateOrThrow(startRequest);

    FilteredSuppressionList filtered = suppressionCheckService.perform(startRequest);
    if (filtered == null || filtered.getResults() == null) {
      return null;
    }
    return filtered.getResults().stream()
        .filter(r -> r.getOperationDetails() != null)
        .flatMap(r -> r.getOperationDetails().stream())
        .filter(d -> "true".equalsIgnoreCase(d.getIndicator()))
        .findFirst()
        .map(
            d -> {
              UpdateOfferResponse res = new UpdateOfferResponse();
              res.setCode(d.getResponseCode());
              res.setDescription(d.getResponseText());
              return res;
            })
        .orElse(null);
  }
}
