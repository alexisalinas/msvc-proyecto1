package com.banamex.app.service.timezonevalidation;

/** Condiciones del flujo de actualización que dependen de la zona horaria. */
public final class UpdateOfferFlowConditions {

  /** No se instancia. */
  private UpdateOfferFlowConditions() {}

  /**
   * Indica si se debe validar la zona horaria: el valor es {@code true}, sin distinguir mayúsculas.
   *
   * @param translateTimeZone valor configurado
   * @return {@code true} si se debe validar
   */
  public static boolean translateTimeZone(String translateTimeZone) {
    return "true".equalsIgnoreCase(translateTimeZone);
  }

  /**
   * Indica si el flujo continúa con la revisión de supresión: el código de la validación termina en
   * {@code 0} (correcta) o es el de zona no configurada.
   *
   * @param tzResponseCode código de la validación de zona horaria
   * @return {@code true} si debe continuar
   */
  public static boolean continueToSuppression(String tzResponseCode) {
    if (tzResponseCode == null || tzResponseCode.isEmpty()) {
      return false;
    }
    return tzResponseCode.endsWith("0") || "COP_TZCOD_114".equals(tzResponseCode);
  }
}
