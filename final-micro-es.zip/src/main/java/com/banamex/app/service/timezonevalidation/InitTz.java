package com.banamex.app.service.timezonevalidation;

import com.banamex.app.dto.timezonevalidation.TzFormatsDto;
import com.banamex.app.dto.timezonevalidation.TzLookUpDto;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.stereotype.Component;

/**
 * Busca, en una lista de configuraciones de zona horaria, la que corresponde al sistema, modo y
 * tipo, y arma los formatos.
 */
@Component
public class InitTz {

  /**
   * Busca la configuración y devuelve sus formatos.
   *
   * @param system sistema o canal
   * @param sysMode modo del sistema
   * @param type {@code Request} o {@code Response}
   * @param lookUp configuraciones disponibles
   * @return los formatos, o vacío si no hay configuración
   */
  public Optional<TzFormatsDto> execute(
      String system, String sysMode, String type, List<TzLookUpDto> lookUp) {
    if (lookUp == null) {
      return Optional.empty();
    }
    return lookUp.stream()
        .filter(
            l ->
                Objects.equals(system, l.getSystemName())
                    && Objects.equals(sysMode, l.getMode())
                    && Objects.equals(type, l.getType()))
        .findFirst()
        .map(
            l -> {
              TzFormatsDto f = new TzFormatsDto();
              f.setTimeZoneOffset(l.getTimeOffset());
              f.setDateFormat(l.getDateFormat());
              f.setTimeFormat(l.getTimeFormat());
              f.setDateTimeFormat(l.getDateTimeFormat());
              f.setTimeZone(l.getTimeZone());
              return f;
            });
  }
}
