package com.banamex.app.service.timezonevalidation;

import com.banamex.app.dto.timezonevalidation.MapRequestResultDto;
import com.banamex.app.dto.timezonevalidation.TimeZoneValidationResult;
import com.banamex.app.dto.timezonevalidation.TimeZoneValidationStartDto;
import com.banamex.app.dto.timezonevalidation.TzFormatsDto;
import com.banamex.app.dto.timezonevalidation.TzLookUpDto;
import com.banamex.app.dto.timezonevalidation.ValueItemDto;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * Valida la zona horaria de una petición. Busca los formatos del sistema en la caché; si no están,
 * los consulta en la base y los guarda en la caché; después convierte las fechas y horas ({@link
 * TimeZoneMapRequest}). La caché no se limpia mientras el micro está arriba y no guarda los
 * sistemas sin configuración.
 */
@Service
@RequiredArgsConstructor
public class TimeZoneValidationService {

  /** Código cuando la validación fue correcta. */
  public static final String OK = "COP_TZCOD_000";

  /** Código cuando el sistema, modo y tipo no tienen zona horaria configurada. */
  public static final String NOT_CONFIGURED = "COP_TZCOD_114";

  /** Estado de un valor inválido. */
  private static final String INVALID_STATUS = "Invalid TimeZone";

  /** Busca los formatos en una lista de configuraciones. */
  private final InitTz initTz;

  /** Consulta la configuración en la base. */
  private final TimeZoneLookupClient lookupClient;

  /** Convierte las fechas y horas. */
  private final TimeZoneMapRequest mapRequest;

  /** Código cuando algún valor es inválido. */
  @Value("${update-offer.timezone.invalid-code:COP_TZCOD_115}")
  private String invalidCode;

  /** Caché en memoria de las configuraciones ya consultadas. */
  private final List<TzLookUpDto> cache = new CopyOnWriteArrayList<>();

  /**
   * Igual que la otra forma de {@code validate}, recibiendo los datos de entrada completos.
   *
   * @param start sistema, modo, tipo y valores a convertir
   * @return resultado de la validación
   */
  public TimeZoneValidationResult validate(TimeZoneValidationStartDto start) {
    return validate(
        start.getSystem(),
        start.getSysMode(),
        start.getType(),
        start.getDate(),
        start.getTime(),
        start.getDateTime());
  }

  /**
   * Valida la zona horaria: obtiene o carga los formatos del sistema (con caché) y convierte las
   * fechas y horas. Devuelve {@link #OK} si todo es válido, {@link #NOT_CONFIGURED} si no hay
   * configuración, o el código de valor inválido si algún valor no cumple el formato.
   *
   * @param system sistema o canal
   * @param sysMode modo del sistema
   * @param type {@code Request} o {@code Response}
   * @param dates fechas a convertir
   * @param times horas a convertir
   * @param dateTimes fechas-horas a convertir
   * @return resultado de la validación
   */
  public TimeZoneValidationResult validate(
      String system,
      String sysMode,
      String type,
      List<ValueItemDto> dates,
      List<ValueItemDto> times,
      List<ValueItemDto> dateTimes) {
    Optional<TzFormatsDto> formats = initTz.execute(system, sysMode, type, cache);

    if (formats.isEmpty()) {
      List<TzLookUpDto> found = lookupClient.find(system, sysMode, type);
      if (found != null && !found.isEmpty()) {
        cache.addAll(found);
        formats = initTz.execute(system, sysMode, type, found);
      }
    }

    if (formats.isEmpty()) {
      return result(
          NOT_CONFIGURED, "TimeZone not configured", emptyFormats(), new MapRequestResultDto());
    }

    MapRequestResultDto map = mapRequest.map(type, formats.get(), dates, times, dateTimes);
    boolean invalid =
        map.getDateGrp().stream().anyMatch(g -> INVALID_STATUS.equals(g.getDateStatus()))
            || map.getTimeGrp().stream().anyMatch(g -> INVALID_STATUS.equals(g.getTimeStatus()))
            || map.getDateTimeGrp().stream()
                .anyMatch(g -> INVALID_STATUS.equals(g.getDateTimeStatus()));

    return result(
        invalid ? invalidCode : OK, invalid ? INVALID_STATUS : "Success", formats.get(), map);
  }

  /**
   * Formatos sin configuración: los cinco campos son obligatorios, así que van vacíos y no nulos.
   *
   * @return formatos vacíos
   */
  private TzFormatsDto emptyFormats() {
    TzFormatsDto f = new TzFormatsDto();
    f.setTimeZoneOffset("");
    f.setDateFormat("");
    f.setTimeFormat("");
    f.setDateTimeFormat("");
    f.setTimeZone("");
    return f;
  }

  /**
   * Arma el resultado de la validación.
   *
   * @param code código
   * @param text texto
   * @param formats formatos
   * @param map valores convertidos
   * @return resultado
   */
  private TimeZoneValidationResult result(
      String code, String text, TzFormatsDto formats, MapRequestResultDto map) {
    TimeZoneValidationResult r = new TimeZoneValidationResult();
    r.setResponseCode(code);
    r.setResponseText(text);
    r.setFormats(formats);
    r.setMapResult(map);
    return r;
  }
}
