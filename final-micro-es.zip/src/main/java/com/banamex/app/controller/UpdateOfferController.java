package com.banamex.app.controller;

import com.banamex.app.dto.UpdateOfferHeaders;
import com.banamex.app.dto.UpdateOfferRequest;
import com.banamex.app.dto.UpdateOfferResponse;
import com.banamex.app.service.UpdateOfferService;
import com.banamex.cops.commons.errors.headers.HeaderValidation;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controlador REST de la operación de actualización de ofertas. Expone {@code POST
 * /sd-campaing-management/v1/update-offer}. Los headers obligatorios los valida la librería de
 * errores con {@code @HeaderValidation}; el controlador solo reúne headers y body y delega el flujo
 * en {@link UpdateOfferService}.
 */
@Slf4j
@RestController
@RequestMapping("/sd-campaing-management/v1/update-offer")
@RequiredArgsConstructor
@HeaderValidation
public class UpdateOfferController {

  /** Servicio que ejecuta el flujo de la actualización. */
  private final UpdateOfferService updateOfferService;

  /**
   * Actualiza una o varias ofertas. Responde 200 aunque una oferta falle: el resultado de cada una
   * viaja en su propio {@code code} y {@code description}. Los errores de headers o de body los
   * resuelve la librería de errores antes de llegar aquí.
   *
   * @param uuid identificador de la transacción
   * @param channelId canal que invoca la operación
   * @param countryCode código de país de 2 letras (ISO 3166)
   * @param businessCode código de negocio
   * @param host host de origen (opcional)
   * @param sid identificador de sesión
   * @param acceptLanguage idioma preferido (opcional)
   * @param httpHeaders todos los headers recibidos
   * @param requests ofertas a actualizar
   * @return una respuesta por oferta, en el mismo orden de la petición
   */
  @PostMapping
  public ResponseEntity<List<UpdateOfferResponse>> updateOffer(
      @RequestHeader(value = "uuid", required = false) String uuid,
      @RequestHeader(value = "ChannelId", required = false) String channelId,
      @RequestHeader(value = "countryCode", required = false)
          @Pattern(regexp = "^[A-Za-z]{2}$", message = "countryCode debe tener 2 letras (ISO 3166)")
          String countryCode,
      @RequestHeader(value = "businessCode", required = false) String businessCode,
      @RequestHeader(value = "host", required = false) String host,
      @RequestHeader(value = "sid", required = false) String sid,
      @RequestHeader(value = "Accept-Language", required = false) String acceptLanguage,
      @RequestHeader HttpHeaders httpHeaders,
      @RequestBody List<@Valid UpdateOfferRequest> requests) {

    UpdateOfferHeaders headers =
        UpdateOfferHeaders.builder()
            .uuid(uuid)
            .channelId(channelId)
            .countryCode(countryCode)
            .businessCode(businessCode)
            .host(host)
            .sid(sid)
            .acceptLanguage(acceptLanguage)
            .all(allHeaders(httpHeaders))
            .build();

    List<UpdateOfferResponse> responses = updateOfferService.updateOffer(requests, headers);

    return ResponseEntity.ok(responses);
  }

  /**
   * Copia todos los headers recibidos en un mapa que no distingue mayúsculas, con el primer valor
   * de cada uno.
   *
   * @param httpHeaders headers de la petición
   * @return mapa de nombre a primer valor
   */
  private static Map<String, String> allHeaders(HttpHeaders httpHeaders) {
    Map<String, String> all = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
    if (httpHeaders != null) {
      httpHeaders.forEach(
          (name, values) -> {
            if (values != null && !values.isEmpty()) {
              all.put(name, values.get(0));
            }
          });
    }
    return all;
  }
}
