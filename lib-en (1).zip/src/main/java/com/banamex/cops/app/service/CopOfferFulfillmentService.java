package com.banamex.cops.app.service;

import com.banamex.cops.app.model.CopOfferFulfillment;

import java.util.List;

/** Query service for the fulfillment data of an offer. */
public interface CopOfferFulfillmentService {

    /** Fulfillment data of an offer (read-only query). */
    List<CopOfferFulfillment> findByWaveKeyAndOfferKey(String waveKey, String offerKey);
}
