package com.banamex.cops.app.model;

/**
 * One row of {@code COP_SUPP_CHNL}: the suppression settings of a channel.
 */
public record CopSuppressionChannel(String countryCode,
                                    String reqMode,
                                    String channelId,
                                    String suppressionFlag,
                                    String operationFlag,
                                    String sourceSystem) {
}
