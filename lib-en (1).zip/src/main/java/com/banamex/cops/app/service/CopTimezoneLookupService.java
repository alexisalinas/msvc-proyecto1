package com.banamex.cops.app.service;

import com.banamex.cops.app.model.CopTimezoneLookup;
import java.util.List;

/** Query service for the time zone settings ({@code COP_TIMEZONE_LOOKUP}). */
public interface CopTimezoneLookupService {

    /**
     * Time zone settings of a system, mode and operation type (read-only).
     *
     * @param tzSystemName system name
     * @param tzMode request mode
     * @param tzOperationType operation type
     * @return matching settings
     */
    List<CopTimezoneLookup> findBySystemNameAndModeAndOperationType(
            String tzSystemName, String tzMode, String tzOperationType);
}
