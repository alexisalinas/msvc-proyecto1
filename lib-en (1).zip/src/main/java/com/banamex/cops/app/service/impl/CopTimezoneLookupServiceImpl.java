package com.banamex.cops.app.service.impl;

import com.banamex.cops.app.model.CopTimezoneLookup;
import com.banamex.cops.app.repository.CopTimezoneLookupRepository;
import com.banamex.cops.app.service.CopTimezoneLookupService;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/** Implementation of {@link CopTimezoneLookupService}: builds the model from the columns by position. */
@Service
@RequiredArgsConstructor
public class CopTimezoneLookupServiceImpl implements CopTimezoneLookupService {

    private final CopTimezoneLookupRepository repository;

    /** {@inheritDoc} */
    @Override
    public List<CopTimezoneLookup> findBySystemNameAndModeAndOperationType(
            String tzSystemName, String tzMode, String tzOperationType) {
        return repository.findBySystemNameAndModeAndOperationType(tzSystemName, tzMode, tzOperationType)
                .stream()
                .map(r -> new CopTimezoneLookup(
                        text(r[0]), text(r[1]), text(r[2]), text(r[3]),
                        text(r[4]), text(r[5]), text(r[6]), text(r[7])))
                .toList();
    }

    private static String text(Object value) {
        return Objects.toString(value, null);
    }
}
