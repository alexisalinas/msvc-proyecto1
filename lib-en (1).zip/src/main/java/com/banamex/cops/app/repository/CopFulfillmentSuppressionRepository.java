package com.banamex.cops.app.repository;

import com.banamex.cops.app.entity.DOfferpalette;
import com.banamex.cops.app.natives.CopQuery;
import java.math.BigDecimal;
import java.util.List;
import javax.persistence.QueryHint;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;

/** Native queries of the library; each row is an {@code Object[]} with the query columns. */
public interface CopFulfillmentSuppressionRepository extends JpaRepository<DOfferpalette, BigDecimal> {

    /**
     * Offer fulfillment (10 s timeout).
     *
     * @param waveKey wave key with its channel
     * @param offerKey offer key
     * @param page maximum number of rows
     * @return query rows
     */
    @Query(value = CopQuery.FIND_OFFER_FULFILLMENT, nativeQuery = true)
    @QueryHints(@QueryHint(name = "javax.persistence.query.timeout", value = "10000"))
    List<Object[]> findOfferFulfillment(
            @Param("waveKey") String waveKey, @Param("offerKey") String offerKey, Pageable page);

    /**
     * Suppressed channels (30 s timeout).
     *
     * @param page maximum number of rows ({@code Pageable.unpaged()} for all)
     * @return query rows
     */
    @Query(value = CopQuery.FIND_ALL_CHANNELS, nativeQuery = true)
    @QueryHints(@QueryHint(name = "javax.persistence.query.timeout", value = "30000"))
    List<Object[]> findAllChannels(Pageable page);

    /**
     * Suppressed operations (30 s timeout).
     *
     * @param page maximum number of rows ({@code Pageable.unpaged()} for all)
     * @return query rows
     */
    @Query(value = CopQuery.FIND_ALL_OPERATIONS, nativeQuery = true)
    @QueryHints(@QueryHint(name = "javax.persistence.query.timeout", value = "30000"))
    List<Object[]> findAllOperations(Pageable page);
}
