package com.banamex.cops.app.repository;

import com.banamex.cops.app.entity.DOfferpalette;
import com.banamex.cops.app.natives.CopQuery;
import java.math.BigDecimal;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/** Native query of the time zone settings; each row is an {@code Object[]} with the query columns. */
public interface CopTimezoneLookupRepository extends JpaRepository<DOfferpalette, BigDecimal> {

    /**
     * Time zone settings of a system, mode and operation type.
     *
     * @param tzSystemName system name
     * @param tzMode request mode
     * @param tzOperationType operation type
     * @return query rows
     */
    @Query(value = CopQuery.FIND_TIMEZONE_LOOKUP, nativeQuery = true)
    List<Object[]> findBySystemNameAndModeAndOperationType(
            @Param("tzSystemName") String tzSystemName,
            @Param("tzMode") String tzMode,
            @Param("tzOperationType") String tzOperationType);
}
