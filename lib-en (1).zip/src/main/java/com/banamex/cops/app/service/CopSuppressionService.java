package com.banamex.cops.app.service;

import com.banamex.cops.app.model.CopSuppressionChannel;
import com.banamex.cops.app.model.CopSuppressionOperation;
import java.util.List;

/** Query service for suppression data (suppressed channels and operations). */
public interface CopSuppressionService {

    /**
     * All channels with their suppression settings (read-only).
     *
     * @param timeoutSeconds kept for compatibility; the 30 s timeout is set by the repository query
     * @param maxRows maximum number of rows; 0 = no limit
     * @return channels with their suppression settings
     */
    List<CopSuppressionChannel> findAllChannels(int timeoutSeconds, int maxRows);

    /**
     * All operations suppressed per channel (read-only).
     *
     * @param timeoutSeconds kept for compatibility; the 30 s timeout is set by the repository query
     * @param maxRows maximum number of rows; 0 = no limit
     * @return suppressed operations
     */
    List<CopSuppressionOperation> findAllOperations(int timeoutSeconds, int maxRows);
}
