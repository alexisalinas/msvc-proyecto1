package com.banamex.cops.app.model;

/** One row of {@code COP_SUPP_OPR}: an operation suppressed for a channel. */
public record CopSuppressionOperation(String operationName,
                                      String operationSuppressFlag,
                                      String reqChannel) {
}
