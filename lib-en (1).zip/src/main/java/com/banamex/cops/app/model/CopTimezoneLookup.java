package com.banamex.cops.app.model;

/** One row of {@code COP_TIMEZONE_LOOKUP}: the time zone settings of a system, mode and operation type. */
public record CopTimezoneLookup(
        String tzSystemName,
        String tzMode,
        String tzTimezone,
        String tzOperationType,
        String tzTimeOffset,
        String tzDatetimeFormat,
        String tzDateFormat,
        String tzTimeFormat) {
}
