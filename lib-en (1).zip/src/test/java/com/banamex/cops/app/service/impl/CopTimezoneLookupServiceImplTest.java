package com.banamex.cops.app.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import com.banamex.cops.app.model.CopTimezoneLookup;
import com.banamex.cops.app.repository.consultasnativas.CopTimezoneLookupRepository;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/** Unit tests for {@code CopTimezoneLookupServiceImpl}. */
@ExtendWith(MockitoExtension.class)
class CopTimezoneLookupServiceImplTest {

    @Mock CopTimezoneLookupRepository repository;
    @InjectMocks CopTimezoneLookupServiceImpl service;

    @Test
    void armaElModeloConLasOchoColumnasEnOrden() {
        // Given
        when(repository.findBySystemNameAndModeAndOperationType("ECRM", "RT", "UpdateOffer"))
                .thenReturn(List.<Object[]>of(new Object[] {
                    "ECRM", "RT", "America/Mexico_City", "UpdateOffer", "-06:00",
                    "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd", "HH:mm:ss"}));

        // When
        List<CopTimezoneLookup> out = service.findBySystemNameAndModeAndOperationType("ECRM", "RT", "UpdateOffer");

        // Then
        assertThat(out).containsExactly(new CopTimezoneLookup(
                "ECRM", "RT", "America/Mexico_City", "UpdateOffer", "-06:00",
                "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd", "HH:mm:ss"));
    }

    @Test
    void sinFilas_devuelveListaVacia() {
        // Given
        when(repository.findBySystemNameAndModeAndOperationType("X", "Y", "Z")).thenReturn(List.of());

        // When / Then
        assertThat(service.findBySystemNameAndModeAndOperationType("X", "Y", "Z")).isEmpty();
    }
}
