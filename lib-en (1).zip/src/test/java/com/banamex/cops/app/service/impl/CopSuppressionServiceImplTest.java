package com.banamex.cops.app.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.banamex.cops.app.model.CopSuppressionChannel;
import com.banamex.cops.app.model.CopSuppressionOperation;
import com.banamex.cops.app.repository.CopFulfillmentSuppressionRepository;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

/** Unit tests for {@code CopSuppressionServiceImpl}. */
@ExtendWith(MockitoExtension.class)
class CopSuppressionServiceImplTest {

    @Mock CopFulfillmentSuppressionRepository repository;
    @InjectMocks CopSuppressionServiceImpl service;

    @Test
    void canales_armaElModeloConLasColumnasEnOrden() {
        // Given
        when(repository.findAllChannels(Pageable.unpaged()))
                .thenReturn(List.<Object[]>of(new Object[] {"MX", "RT", "CAT", "Y", "N", "ECRM"}));

        // When / Then
        assertThat(service.findAllChannels(30, 0))
                .containsExactly(new CopSuppressionChannel("MX", "RT", "CAT", "Y", "N", "ECRM"));
    }

    @Test
    void canales_conMaximoDeFilas_lasLimitaEnElRepositorio() {
        // Given
        when(repository.findAllChannels(PageRequest.of(0, 50))).thenReturn(List.of());

        // When
        service.findAllChannels(30, 50);

        // Then
        verify(repository).findAllChannels(PageRequest.of(0, 50));
    }

    @Test
    void operaciones_armaElModeloConLasColumnasEnOrden() {
        // Given
        when(repository.findAllOperations(Pageable.unpaged()))
                .thenReturn(List.<Object[]>of(new Object[] {"UpdateOffer", "Y", "CAT"}));

        // When / Then
        assertThat(service.findAllOperations(30, 0))
                .containsExactly(new CopSuppressionOperation("UpdateOffer", "Y", "CAT"));
    }

    @Test
    void operaciones_conMaximoDeFilas_lasLimitaEnElRepositorio() {
        // Given
        when(repository.findAllOperations(PageRequest.of(0, 100))).thenReturn(List.of());

        // When
        service.findAllOperations(15, 100);

        // Then
        verify(repository).findAllOperations(PageRequest.of(0, 100));
    }
}
