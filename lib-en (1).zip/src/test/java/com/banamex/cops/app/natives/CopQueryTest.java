package com.banamex.cops.app.natives;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

/** Unit tests for {@code CopQuery}. */
class CopQueryTest {

    @Test
    void cumplimiento_traeLos100UserFieldYLosParametrosConNombre() {
        // Given
        String sql = CopQuery.FIND_OFFER_FULFILLMENT;

        // When / Then
        assertThat(sql.split("O\\.USERFIELD_", -1).length - 1).isEqualTo(100);
        assertThat(sql).contains("O.USERFIELD_1,", "O.USERFIELD_100,", ":waveKey", ":offerKey")
                .doesNotContain("?", "to_char");
    }

    @Test
    void cumplimiento_unaLasCuatroTablasDelModelo() {
        // Given
        String sql = CopQuery.FIND_OFFER_FULFILLMENT;

        // When / Then
        assertThat(sql).contains("FROM D_OFFERPALETTE O, D_CAMPAIGN C, D_PRODUCT P, D_WAVECHINFO W",
                "O.CAMPAIGNID = C.CMPID", "C.PRDCODE = P.PRDCODE");
    }

    @Test
    void supresion_seleccionaLasColumnasEnElOrdenDelServicio() {
        // Given
        // (constantes)

        // When / Then
        assertThat(CopQuery.FIND_ALL_CHANNELS).contains(
                "SELECT COUNTRY_CODE, REQMODE, CHANNEL_ID, SUPPRESSION_FLAG, OPERATION_FLAG, SOURCE_SYSTEM",
                "FROM COP_SUPP_CHNL");
        assertThat(CopQuery.FIND_ALL_OPERATIONS)
                .contains("SELECT OPERATION_NAME, OPERATION_SUPPRESS_FLAG, REQCHANNEL FROM COP_SUPP_OPR");
    }

    @Test
    void timezone_traeLasOchoColumnasYFiltraPorLosTresParametros() {
        // Given
        String sql = CopQuery.FIND_TIMEZONE_LOOKUP;

        // When / Then
        assertThat(sql).contains("SELECT TZ_SYSTEM_NAME, TZ_MODE, TZ_TIMEZONE, TZ_OPERATION_TYPE,",
                "TZ_TIME_OFFSET, TZ_DATETIME_FORMAT, TZ_DATE_FORMAT, TZ_TIME_FORMAT", "FROM COP_TIMEZONE_LOOKUP",
                "TZ_SYSTEM_NAME = :tzSystemName", "TZ_MODE = :tzMode", "TZ_OPERATION_TYPE = :tzOperationType");
    }
}
