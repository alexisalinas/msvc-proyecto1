package com.banamex.cops.app.repository;

import static org.assertj.core.api.Assertions.assertThat;

import com.banamex.cops.app.natives.CopQuery;
import org.junit.jupiter.api.Test;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

/** Unit tests for {@code CopTimezoneLookupRepository}. */
class CopTimezoneLookupRepositoryTest {

    @Test
    void heredaDeJpaRepository_yUsaLaConsultaNativaDeCopQuery() throws Exception {
        // Given
        Query query = CopTimezoneLookupRepository.class
                .getMethod("findBySystemNameAndModeAndOperationType", String.class, String.class, String.class)
                .getAnnotation(Query.class);

        // When / Then
        assertThat(JpaRepository.class).isAssignableFrom(CopTimezoneLookupRepository.class);
        assertThat(query.nativeQuery()).isTrue();
        assertThat(query.value()).isEqualTo(CopQuery.FIND_TIMEZONE_LOOKUP);
    }
}
