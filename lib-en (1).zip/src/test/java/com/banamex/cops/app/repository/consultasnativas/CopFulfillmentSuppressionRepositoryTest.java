package com.banamex.cops.app.repository.consultasnativas;

import static org.assertj.core.api.Assertions.assertThat;

import com.banamex.cops.app.natives.CopQuery;
import java.lang.reflect.Method;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;

/** Unit tests for {@code CopFulfillmentSuppressionRepository}. */
class CopFulfillmentSuppressionRepositoryTest {

    private static void verifica(Method m, String sql, String timeoutMs) {
        assertThat(m.getAnnotation(Query.class).nativeQuery()).isTrue();
        assertThat(m.getAnnotation(Query.class).value()).isEqualTo(sql);
        assertThat(m.getAnnotation(QueryHints.class).value()[0].name())
                .isEqualTo("javax.persistence.query.timeout");
        assertThat(m.getAnnotation(QueryHints.class).value()[0].value()).isEqualTo(timeoutMs);
    }

    @Test
    void heredaDeJpaRepository() {
        // Given
        // (sin precondiciones)

        // When / Then
        assertThat(JpaRepository.class).isAssignableFrom(CopFulfillmentSuppressionRepository.class);
    }

    @Test
    void cumplimiento_usaSuQueryConTimeoutDe10Segundos() throws Exception {
        // Given
        Method m = CopFulfillmentSuppressionRepository.class.getMethod(
                "findOfferFulfillment", String.class, String.class, Pageable.class);

        // When / Then
        verifica(m, CopQuery.FIND_OFFER_FULFILLMENT, "10000");
    }

    @Test
    void supresion_usaSusQueriesConTimeoutDe30Segundos() throws Exception {
        // Given
        Method canales = CopFulfillmentSuppressionRepository.class.getMethod("findAllChannels", Pageable.class);
        Method operaciones = CopFulfillmentSuppressionRepository.class.getMethod("findAllOperations", Pageable.class);

        // When / Then
        verifica(canales, CopQuery.FIND_ALL_CHANNELS, "30000");
        verifica(operaciones, CopQuery.FIND_ALL_OPERATIONS, "30000");
    }
}
