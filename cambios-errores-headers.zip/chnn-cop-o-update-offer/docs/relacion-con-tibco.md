# Cada pieza del micro: por qué existe y qué relación tiene con TIBCO y con el flujo

Micro `chnn-cop-o-update-offer` (paquete `com.banamex.cops.update_offer`) y librería `chnn-cop-lib-operation-db` (paquete `com.banamex.cops.app`).
Proceso de BW que se migra: `OpUpdateOffer` (COPS / OfferManagementServices / UpdateOffer).

Cómo leerlo: cada clase dice **qué hace**, **por qué existe**, **su equivalente en TIBCO** y **dónde entra en el flujo del micro**.
Los valores del yml son los de `application.yml` actual. Lo que sigue abierto está marcado como *(supuesto)* y se detalla en `pendientes-y-suposiciones.md`.

---

## 1. Vista general

### 1.1 Flujo del micro

```
POST /sd-campaing-management/v1/update-offer   (lista de ofertas + headers)
  │
  ├─ @HeaderValidation (librería) . ¿vienen los headers obligatorios?  (si no: 400 / 406)
  ├─ UpdateOfferController ....... arma UpdateOfferHeaders, valida el body (@Valid)
  │
  └─ UpdateOfferServiceImpl.updateOffer
       ├─ AuditLogService.logRequest ............ [REQUEST] en el log
       ├─ por cada oferta (procesarOferta → ejecutar):
       │    1. TimeZoneValidationService ........ solo si translate-time-zone = true
       │    2. PerformSuppressionCheckService ... solo si check-for-suppression = Y
       │    3. UpdateOfferMapper ................ XML + propiedades para el EMS
       │    4. EmsSender.send ................... envía a la cola y espera la respuesta
       │    5. OfferFulfillmentEmsSender ........ evento JSON, asíncrono (Kafka / EMS alterno)
       │    6. UpdateOfferResponseFactory ....... respuesta REST de la oferta
       └─ AuditLogService.logResponse ........... [RESPONSE] en el log
```

### 1.2 Actividad de BW → clase del micro

| Actividad o subproceso de BW | Clase(s) del micro |
|---|---|
| Start + GetContext | `@HeaderValidation` (librería `chnn-cop-lib-errors-handling`), `UpdateOfferController`, `UpdateOfferHeaders` (el contexto llega en headers HTTP) |
| Log service request / Log service response (`/BW/Logging/LogRequest`) | `AuditLogService` |
| Esquemas XSD (obligatorio / opcional / lista) | DTOs + `DtoValidator` |
| `RequestTimeZoneValidation` (`/BW/Common/TimeZoneValidation`) | `TimeZoneValidationService`, `InitTZ`, `CopTimezoneLookupClient`, `TimeZoneMapRequest`, `UpdateOfferFlowConditions` |
| `PerformSuppressionCheck` (`/BW/Common/PerformSuppressionCheck`) | `PerformSuppressionCheckService`, `SuppressionCheckService`, `DbSuppressedEntitiesClient`, `StartUpSuppressionLoader` |
| JMS Queue Requestor (rama "XSD Format") | `UpdateOfferMapper`, `UpdateOfferRequestXmlMapper`, `OfferEventMapper`, `UserTextParser`, `XmlUtil`, `EmsSender` |
| Parse de la respuesta del JMS | `UpdateOfferResponseXmlMapper` |
| Map Data + End | `UpdateOfferResponseFactory` |
| `KafkaSenderDashboard` | `KafkaSenderDashboard`, `OfferInput`, `OfferKeyBuilder` |
| `FulFillKafkaSender` | `OfferFulfillmentEmsSender`, `OfferPublisher`, `JmsOfferPublisher`, `EventDestinations` |
| `/BW/Kafka/DataFetch` (CitiDataStore) | `OfferDataClient` + librería (`CopOfferFulfillment*`) |
| Variables globales | `application.yml` + clases `*Props` / `@Value` |
| JMS Connection compartida | `JmsConfig` + librería `mafim-u-messaging-connector` |

---

## 2. Entrada y log

### 2.1 `UpdateOfferController`
- **Qué hace:** recibe el POST, junta los headers en `UpdateOfferHeaders` (los del swagger y `all`, con todos los recibidos sin distinguir mayúsculas), valida `countryCode` (2 letras) y el body (`@Valid` por oferta) y llama al service. Siempre responde 200 con la lista de respuestas.
- **Por qué existe:** es la puerta REST que reemplaza el Start del proceso. Se conserva la ruta `/sd-campaing-management/v1/update-offer`.
- **TIBCO:** Start + GetContext. El GetContext ya no se consulta: sus datos vienen en los headers.
- **Método `allHeaders`:** copia todos los headers para que `[REQUEST]` los muestre completos.

### 2.2 `@HeaderValidation` (librería `chnn-cop-lib-errors-handling`)
- **Qué hace:** el controller lleva la anotación y un interceptor de la librería valida los headers antes de llegar al método. Obligatorios: `Accept` (debe ser `application/json`, si no responde 406), `uuid` (formato UUID), `Content-Type`, `ChannelId`, `sid`, `countryCode` (2 letras) y `businessCode`. Opcionales (pero sin vacíos ni duplicados): `client_id`, `Authorization`, `Accept-Language` y `host`. Además cada valor debe estar en el catálogo `catalogs.properties` de la librería, si el header aparece ahí.
- **Si falla:** responde 400 (406 para `Accept`) con el `ErrorResponse` de la librería (`type`, `code`, `details`, `location`, `moreInfo`, `uuid`, `timestamp`).
- **Errores del body:** el `GlobalExceptionHandler` de la librería convierte JSON mal formado, `@Valid` y `ConstraintViolationException` en 400 con el mismo formato.
- **Propiedades:** `messages.header.*` del yml (sin ellas la app no arranca).
- **Por qué existe:** el contrato del swagger exige esos headers y BW los necesitaba para el contexto. Reemplaza a la clase propia `HeaderValidation` y a `ErrorResponse`/`ErrorType`, que se borraron.
- **TIBCO:** validación implícita del GetContext.

### 2.3 DTOs de la API
| Clase | Para qué sirve |
|---|---|
| `UpdateOfferRequest` | Cuerpo de cada oferta (obligatorios: `channelCode`, `campaignId`, `waveId`, `customerId`). `userText` trae los UserFields como JSON |
| `UpdateOfferResponse` | Respuesta por oferta (`code`, `description` obligatorios) |
| `UpdateOfferHeaders` | Headers del swagger + `all` con todos los recibidos |
| `ControlFieldDTO`, `KeyProcessEnum` | `contextType` y las versiones V1/V2/V3 (la rama XSD es fija, `keyProcess` no se usa) |

**TIBCO:** los esquemas del proceso. Regla de BW que se respeta en todos los DTOs: sin símbolo = obligatorio, `?` = opcional, `*` = lista (nunca nula).

### 2.4 `DtoValidator`
- **Métodos:** `violations(dto)` devuelve la lista "ruta: mensaje"; `validateOrThrow(dto)` lanza `IllegalArgumentException` con el detalle.
- **Por qué existe:** BW validaba contra el esquema al mapear. Aquí se valida lo que el micro arma (el `Start` de zona horaria y el de supresión) antes de llamar a cada subproceso.
- **Dónde entra:** `UpdateOfferServiceImpl` lo llama antes de la zona horaria y de la supresión.

### 2.5 `AuditLogService`
- **Métodos:** `logRequest(headers, requests)` y `logResponse(headers, responses)`.
- **Qué hace:** escribe `[REQUEST]` (todos los headers + body en JSON con la tarjeta enmascarada a los últimos 4 dígitos) y `[RESPONSE]` (JSON de la respuesta final).
- **Por qué existe:** decidiste que el log muestre solo lo que entra y lo que sale.
- **TIBCO:** `/BW/Logging/LogRequest` (Check Audit Enabled → Map Data → Write To Log). La global `AuditPointsEnabled` es una cadena de banderas: posición 1 = request, posición 4 = respuesta. Con `audit.points-enabled: "1001"` salen las dos.

---

## 3. Orquestación: `UpdateOfferServiceImpl`

Equivale a todo `OpUpdateOffer`: cada `if` de `ejecutar` es una transición del diagrama.

| Método | Qué hace | Por qué existe / TIBCO |
|---|---|---|
| `updateOffer` | Log request → procesa cada oferta → log response | Start → End |
| `procesarOferta` | Atrapa cualquier falla de una oferta y devuelve su respuesta `ERROR` | Catch de BW. Una oferta con error no tumba a las demás |
| `paso(nombre, acción)` | Ejecuta un paso y, si falla, lanza `StepFailedException` con el nombre del paso | Sin equivalente: BW mostraba la actividad en el diagrama; el micro lo escribe en la respuesta ("Falló en {step}: {detail}") |
| `ejecutar` | Zona horaria → supresión → XML y propiedades → EMS → evento → respuesta | Las transiciones de `OpUpdateOffer` |
| `dates` / `times` | Arman el `Start` de zona horaria con `AppointmentDate`, `AppointmentStartTime` y `AppointmentEndTime` | Mapeo de entrada del subproceso |
| `checkSuppression` | Arma `StartRequest` (canal, país, operación `UpdateOffer`), llama a supresión y, si algún detalle tiene `indicator = true`, devuelve su `ResponseCode/ResponseText` | Actividad PerformSuppressionCheck |
| `leerRespuestaDelEms` | Lee `Code` y `Description` del reply; si no hay o no se puede leer, devuelve `null` (solo avisa en el log) | Parse del JMS. Esos dos datos solo viajan en el evento |
| `sendToKafka` | Si hay destino activo arma el `OfferInput` y encola el envío; nunca lanza excepción | Transición condicional `isKafkaOn_1` |

Reglas de `ejecutar`:
- **Zona horaria** (solo si `translate-time-zone: true`): `system = ChannelId`, `sysMode = RealTime`, `type = Request`. Si el código no continúa (`UpdateOfferFlowConditions.continueToSuppression`), responde con ese código y texto y no sigue.
- **Supresión:** si la operación está suprimida, responde con el código del detalle y no llega al EMS.
- **`AbInitioTest = Y`:** solo escribe un aviso; el camino de AbInitio no se migró y la oferta sigue por el JMS.
- **Falla del EMS:** igual se manda el evento (con `ResponseCode/Text` nulos) y la oferta responde `ERROR` en el paso "Envío al EMS".
- **El EMS contesta un error de negocio o no contesta:** el flujo sigue igual y la respuesta REST es de éxito (decisión tuya: la respuesta la arma el micro).

---

## 4. Zona horaria (BW: `/BW/Common/TimeZoneValidation`)

| Clase | Método | Qué hace / por qué / TIBCO |
|---|---|---|
| `UpdateOfferFlowConditions` | `translateTimeZone(valor)` | `true` sin distinguir mayúsculas. Condición de la transición hacia RequestTimeZoneValidation |
| | `continueToSuppression(code)` | Sigue si el código termina en `0` o es `COP_TZCOD_114` (zona no configurada). Es el XPath de la transición hacia PerformSuppressionCheck |
| `TimeZoneValidationService` | `validate(start)` / `validate(system, sysMode, type, dates, times, dateTimes)` | GetVariable (caché) → InitTZ → LookupTZ → SetVariable → MapRequest. Códigos: `COP_TZCOD_000` correcto, `COP_TZCOD_114` no configurada, `COP_TZCOD_115` inválida *(códigos por confirmar)* |
| | caché `cache` | Equivale a la variable compartida `LookUp`. No se limpia nunca |
| `InitTZ` | `execute(system, sysMode, type, lookUp)` | Busca sistema + modo + tipo y arma los `Formats`. Es el Assign "InitTZ" |
| `TimeZoneLookupClient` / `CopTimezoneLookupClient` | `find(system, sysMode, type)` | LookupTZ: consulta `COP_TIMEZONE_LOOKUP` por la librería; los NULL pasan a `""` |
| `TimeZoneMapRequest` | `map(type, formats, dates, times, dateTimes)` | MapRequest: valida y convierte fecha, hora y fecha-hora (Request y Response) con `BETimeFormat`, `BEDateTimeFormat` y `ECRMTimeZone` |

**Relación con el flujo:** si está activa, sus resultados (`MapRequestResultDTO`) los usa `OfferEventMapper` para escribir `ApptDate`, `ApptStartTime`, `ApptEndTime` y `UpdateTime` convertidos.
**Pendientes:** el horario de verano con `US/Central`, y que las conversiones de Request vienen de la guía, no de una ejecución real. La tabla `COP_TIMEZONE_LOOKUP` estaba vacía (hay `docs/cargar-timezone-lookup.sql`).

---

## 5. Supresión (BW: `/BW/Common/PerformSuppressionCheck`)

| Clase | Qué hace | TIBCO |
|---|---|---|
| `PerformSuppressionCheckService.perform` | Con `check-for-suppression: "Y"` consulta la lista y filtra; con otro valor devuelve lista vacía. Si falla algo, lo registra y devuelve lista vacía (no bloquea la oferta) | Subproceso PerformSuppressionCheck |
| `SuppressionCheckService.checkIfSuppressed` | Filtra por canal y país con bandera `Y`, modo `RT` y sistema `ECRM` | Mapper "CheckIfSuppressed" |
| `DbSuppressedEntitiesClient` | `getListOfSuppressedEntities` carga la lista de la BD la primera vez y la deja en memoria; `reload()` la vuelve a cargar | GetListOfSuppressedEntities + variable compartida |
| `StartUpSuppressionLoader.build` | Arma la lista desde canales y operaciones, según las banderas del canal | `/BW/StartUp/startUpSuppression` (SetVariable y su `Choose`) |
| `SuppressedEntitiesClient` | Interfaz del cliente | — |

Propiedades: `cop.suppression.check-for-suppression` (`N` = no consulta), `query-timeout-seconds` (BW: `QueryRecords/TimeoutDefault`) y `max-rows` (BW: `Connections/BSDB/MaxConns`; 0 = sin límite).
**Pendiente:** quién carga la lista de supresión en BW.

---

## 6. Mensaje al EMS principal (BW: JMS Queue Requestor, rama "XSD Format")

| Clase | Método | Qué hace / por qué / TIBCO |
|---|---|---|
| `UpdateOfferMapper` | `toEmsProperties`, `toEmsXml`, `toRestResponse(s)` | Fachada que usa el service. Equivale a `toSoapRequest / toRestResponse` |
| `UpdateOfferRequestXmlMapper` | `toEmsXml` | XML del evento: `<UpdateOffer>` con sus campos (`body-element`, `event-namespace`, `envelope`, `xml-namespace` del yml). `_nm_` y `_ns_` de BW |
| | `toEmsProperties` | Propiedades JMS (`OtherProperties`) con `_nm_`, `_ns_` y los campos |
| `OfferEventMapper` | `map` | El mapeo de la pestaña Input: `RequestingChannel`, `CampaignID`, `WaveID`, `AccountNO`, `CardNO`, `ApptDate`, `ApptStartTime`, `ApptEndTime`, `CustomerNO`, `UserField1..100`, `UpdatedBy`, `UpdateTime`, etc. Campo obligatorio = siempre va (vacío si no hay dato); opcional = solo si trae valor |
| | `customerNo` / `padFront` | `CustomerNO` con `pad-front` si `customer-padding: true` (hoy `false`, longitud 19, carácter `0`) |
| | `withoutSeconds` | `if (count(tokenize(t, ':')) = 3) then substring-before-last(t, ':') else t` |
| | `tzOk` | `substring(ResponseCode, len, 1) = '0'`: si la zona horaria fue correcta usa las fechas convertidas |
| `UserTextParser` | `parse` | Convierte el JSON de `userText` (`{"parameterName":"userField1","parameterValue":"..."}`) en `UserField1..100`. Reemplaza los ~100 campos del mapeo |
| `XmlUtil` | `esc`, `tag`, `tagOrEmpty` | Escribe el XML a mano. Equivale al `render-xml` |
| `EmsSender` | `send(xml, props)` | Ver abajo |
| `UpdateOfferResponseXmlMapper` | `fromReply`, `fromReplies` | Lee `Code` y `Description` de la respuesta (XML o JSON). `fromReplies` está para el caso de varias ofertas en un solo mensaje, que aún no se usa |

### `EmsSender`
- **Qué hace:** abre sesión con el `JmsTemplate updateOfferJmsTemplate`, crea una cola temporal de respuesta, envía el mensaje a `update-offer.ems.queue` (no persistente) y espera la respuesta hasta `timeout-seconds` (0 = no espera). Lee la respuesta sea TextMessage, BytesMessage, MapMessage u otro.
- **Formato del mensaje** (`update-offer.ems.message-format`): `properties` (cuerpo vacío y todo en propiedades), `xml` (solo cuerpo XML) o `both` (las dos cosas; valor actual).
- **Por qué:** es el JMS Queue Requestor. Mismo patrón: enviar y esperar el reply.
- **Variables de BW:** `RequestTimeout_Category1 = 7` → `timeout-seconds`; `JMSExpiration` → `time-to-live-ms` (queda en 0 porque con 30 ms el reloj de una PC de desarrollo hace que el EMS descarte el mensaje).
- **Cola:** una sola, fija (el resultado del `concat` de globales de BW): `citi.gcg.la.cop_163621.mx_card.offer.update`.
- **Log:** `[EMS] Envía a queue=… (N propiedades)` con la tarjeta enmascarada, y `[EMS] Responde`. `dry-run: true` solo escribe el log.
- **Errores:** `rootCause` (una línea "Clase: mensaje" para la respuesta) y `causeChain` (toda la cadena para el log, útil para "Not allowed to create destination").

---

## 7. Respuesta REST (BW: Map Data + End)

### `UpdateOfferResponseFactory`
| Método | Qué arma |
|---|---|
| `success()` | `COP_UPDOF_0` — "Successfully update offer {dateTime}" |
| `success(request)` | Con `offerStatus = U` y `status-u-bw-format: true`: `COP_UPDOF_0` "Successfully update offer {offerKey}" (llave `off:mx:CAMPAÑA_OLA_CLIENTE[_CUENTA][_TARJETA]`) o `COP_UPDOF_432` si no hay campaña |
| `success(request, emsResponse)` | Con `response.source: ems` y un código del EMS, devuelve la respuesta del EMS; con `micro` (valor actual) la arma el micro |
| `error(step, cause)` | `ERROR` — "Error update offer {dateTime}. Falló en {step}: {detail}" |
| `kafkaSuccessText(destino)`, `kafkaDryRunText(destino)`, `kafkaDisabledText()`, `kafkaErrorText(destino, paso, detalle \| causa)` | Los textos del **resultado del envío del evento**; solo van al log |

- **Por qué existe:** decidiste que la respuesta no dependa del JMS. El `ResponseCode/Text` del EMS solo va al evento.
- **Fecha:** `{dateTime}` en `ECRMTimeZone` con formato `yyyy/MM/dd HH:mm:ss`.
- **TIBCO:** el Map Data final y el `End`. El caso `U` replica el mapper de BW.
- **Propiedades:** `UpdateOfferResponseProperties` (`update-offer.response.*`).

---

## 8. El evento (BW: `KafkaSenderDashboard` + `FulFillKafkaSender`)

### 8.1 Paso a paso

```
sendToKafka
  ├─ OfferFulfillmentEmsSender.isEnabled()   offer.kafka.enabled y al menos un destino activo
  ├─ KafkaSenderDashboard.build(...)         arma el OfferInput
  └─ sendAsync(input)                        el hilo del REST sigue y responde
        └─ (hilo del ejecutor) process(input):
             1. valid         RefID, OfferKey, CampaignID, WaveID, CustomerNo, OfferStatus
             2. espera        offer.kafka.delay-ms (200)
             3. consulta BD   OfferDataClient.find(waveKey, offerKey)  [con reintentos]
             4. assemble      JSON { "event": { "header", "body" } }
             5. publica       en cada destino activo, con reintentos
```

### 8.2 Clases

| Clase | Qué hace / por qué / TIBCO |
|---|---|
| `KafkaSenderDashboard.build` | Arma el `OfferInput` con el request, los headers y la respuesta del EMS. Genera el `esbUuid` (un GUID) y las horas `transactionTime` y `responseTime` (esta con `ECRMTimeZone`). Es la actividad del mismo nombre en BW |
| `OfferInput` | El "evento de entrada": uuid, esbUuid, channel, transactionTime, refId, offerKey, campaignId, waveId, customerNo, accountNo, cardNumber, offerStatus, actionId, responseTime, responseCode, responseText |
| `OfferKeyBuilder` | Arma las tres claves (ver 8.3) |
| `OfferDataClient.find` | Llama a la librería con `waveKey` y `offerKey`. Si trae varias filas usa la primera y avisa (`KAFKA-MULTI-ROWS`). Equivale a `/BW/Kafka/DataFetch` (antes CitiDataStore, ahora la BD de COPS) |
| `OfferFulfillmentEmsSender` | Es el `FulFillKafkaSender` completo. `sendAsync` encola en el ejecutor; si está lleno cuenta `KAFKA-REJECTED` y deja el resultado en el log. `process` hace los pasos 1 a 5. `assemble` arma el JSON. `retry` reintenta solo fallas de infraestructura. `publicar` publica en un destino y, si falla, solo ese destino queda con error |
| `OfferPublisher` | Contrato "publicar un JSON con su RefId" |
| `JmsOfferPublisher.publish` | Deja el JSON en la cola con `JMSCorrelationID = RefId` y la propiedad `RefId`, no persistente. Con `message-format: envelope` lo envuelve en `<root><RefId/><jsonString/></root>` (la forma `{RefId, jsonString}` de BW). El `JmsTemplate` se pide al publicar: la conexión solo se crea si el destino se usa |
| `EventDestinations` | Decide los destinos en cada envío, según el yml. Ver 8.4 |
| `OfferKafkaProps` | Propiedades `offer.kafka.*` |
| `AlternateEmsProps` | Propiedades `offer.alternate-ems.*` |
| `KafkaExecutorConfig` | Ejecutor `offerFulfillmentExecutor` (núcleo 2, máximo 4, cola 100). Si la cola se llena rechaza en vez de acumular |
| `KafkaMetrics` | Contadores: enviados, sin filas, inválidos, fallidos, rechazados |

### 8.3 Las claves

| Clave | Formato | Ejemplo | Dónde se usa |
|---|---|---|---|
| `RefID` | `CAMPAÑA_OLA_CLIENTE` y, solo si hay **cuenta y tarjeta**, `_CUENTA_TARJETA` | `DYNMCBIRTHWELC_DUNIUWPEMQ_023810810` | JSON (`RefID`), `JMSCorrelationID`, propiedad `RefId` |
| `offerKey` | `off:mx:CAMPAÑA:OLA:CLIENTE[:CUENTA]` | `off:mx:CAMP:OLA:12345:6789` | Consulta: `D_OFFERPALETTE.EXTID$` |
| `waveKey` | `wvch:OLA:CANAL` | `wvch:DUNIUWPEMQ:CAT` | Consulta: `D_WAVECHINFO.EXTID$` |

Los prefijos y el separador salen de `offer-prefix`, `wave-prefix` y `key-separator`. **Si la consulta no encuentra la oferta, casi siempre es una de estas dos claves** (prefijo, canal u ola distintos a los de la BD).

### 8.4 Destinos (`EventDestinations`)

| Interruptor | Destino | JmsTemplate | Cola |
|---|---|---|---|
| `offer.kafka.bridge-enabled: true` | Bridge de Kafka | `updateOfferJmsTemplate` (la conexión principal) | `offer.kafka.queue` |
| `offer.alternate-ems.enabled: true` | EMS alterno | `alternateEmsJmsTemplate` (conexión `banamex-cops-alterno`) | `offer.alternate-ems.queue` |

- **Por qué existe:** la conexión a Kafka va a tardar; el envío queda listo pero apagable, y mientras tanto el JSON va a otra cola de un EMS.
- **Los dos pueden estar activos a la vez:** hoy comparten la misma cola, así que no prendas los dos.
- `offer.kafka.mode: dry-run` usa un publicador que no envía y solo escribe el JSON en el log. `offer.kafka.enabled: false` apaga todo.
- La lista se arma en cada envío, así un cambio de configuración se respeta.
- Queue actual de los dos: `citi.gcg.la.cop_163621.mx_dm.raw.cops-offer-fulfillment-req` (en minúsculas: el EMS distingue mayúsculas).

### 8.5 De dónde sale cada campo del JSON

**`header`**

| Campo | Origen |
|---|---|
| `name`, `version`, `producerCSI`, `countryCode`, `businessCode` | Constantes de `KafkaSenderDashboard` en BW → `offer.kafka.event-name` (`Updateofferrequest`), `event-version` (`1.0`), `producer-csi` (`163621`), `country-code` (`MX`), `business-code` (`DM`) |
| `Channel` | `channelCode` del request |
| `UUID` | Header `uuid` |
| `sid` | `esbUuid` (GUID generado); si viene vacío, el `uuid` |
| `transactionTime` | Hora de inicio de la oferta, `yyyy-MM-dd'T'HH:mm:ss.SSS` |
| `timeStamp` | Hora del armado en `ECRMTimeZone`, con offset |

**`body`**

| Campo | Origen |
|---|---|
| `RefID`, `CampaignID`, `WaveID`, `AccountNo`, `OfferStatus` | Request |
| `CustomerNo` | `customerId` rellenado con ceros a la izquierda a 9 |
| `CardNumber` | Request; con `mask-card-number: true` solo los últimos 4 |
| `Action_ID` | `offerActionCode` del request |
| `ResponseTime` | Hora de la respuesta en `ECRMTimeZone` con offset |
| `ResponseCode`, `ResponseText` | Respuesta del EMS (nulos si no hubo) |
| `ID_ProductType` | BD: `D_CAMPAIGN.PRDTYPE` |
| `CRP_Category_ID` | BD: `D_WAVECHINFO.CRPCATEGORYID` |
| `Product_Description` | BD: `D_PRODUCT.DESCRIPTION` |
| `Reason_Code`, `Reason_Description` | BD: `D_OFFERPALETTE.REASONCODE`, `REASONDESC` |
| `FulfillmentID` | BD: `D_CAMPAIGN.FULFILLMENTPROCID` |
| `UserField1..100` | BD: `D_OFFERPALETTE.USERFIELD_1..100` |
| `AppointmentDate` | BD: `APPTSTARTDATE_TM` |
| `AppointmentMinDur` | Minutos entre `APPTSTARTDATE_TM` y `APPTENDDATE_TM` (si no es positivo, nulo) |
| `OfferExpiryDate`, `OfferStartDate` | BD: `EXPIRYDATE_TM`, `OFFERCREATIONDATE_TM` |
| `PrdCode`, `PrdFamily` | BD: `D_PRODUCT.PRDCODE`, `PRDFAMILY` |
| `Availability` | BD: `D_OFFERPALETTE.AVAILABILITY` |

Con `omit-nulls: true` los campos nulos no se escriben. Con `send-without-db-rows: true` y sin fila en la BD, todos los campos de la BD salen nulos (y se omiten) pero el evento se envía.

### 8.6 Reintentos, errores y resultado

- **Reintentos:** `max-attempts: 3`, espera `retry-backoff-ms: 500` y se duplica. Aplican a la consulta a la BD y a cada publicación. "Sin filas" no es excepción y no se reintenta.
- **Sin filas (`KAFKA-NO-ROWS`):** con `send-without-db-rows: true` avisa y envía; con `false` registra error y no envía.
- **Un destino falla:** solo ese queda con error; el otro se publica igual.
- **Resultado:** `[KAFKA]`, `[EMS-ALTERNO]` o `[KAFKA+EMS-ALTERNO]` `Resultado: …` con éxito, dry-run, desactivado o error y el paso donde falló.
- **La respuesta REST no cambia nunca** por lo que pase con el evento.

---

## 9. Configuración y pegamento

| Clase | Qué hace / por qué |
|---|---|
| `UpdateOfferApplication` | Arranque. Escanea solo `update_offer` |
| `JmsConfig` | Beans de la conexión al EMS con la librería mafim: `jsonMapper`, `jmsProperties`, identidad, `emsConnectionFactoryBean`, `emsJmsTemplateBean`, `updateOfferConnectionFactory` y `updateOfferJmsTemplate` (el de `EmsSender` y el del bridge). Para el EMS alterno: `alternateEmsConnectionFactory` y `alternateEmsJmsTemplate`, con `@Lazy` y `@ConditionalOnProperty offer.alternate-ems.enabled`. En BW era la JMS Connection compartida |
| `SecurityConfig` | `permitAll` y CSRF apagado, e importa `EmsConfig` de la librería. BW no tenía este concepto |
| `OfferFulfillmentConfig` | Importa del jar `CopOfferFulfillmentRepository`, `CopOfferFulfillmentServiceImpl`, `CopSuppressionRepository` y `CopSuppressionServiceImpl`. En BW la conexión era BSDB |
| `EntityScanConfig` | Registra las entidades JPA de la librería (evita "Not a managed type") |
| `LibraryRepositoryFragmentsConfig` | Registra solo las implementaciones `*Repository(Custom)Impl` de la librería, que Spring Data busca por nombre |
| `LibraryBeanDeduplicator` | Si una clase de la librería quedó registrada dos veces, conserva solo el registro de la librería |
| `OfferJmsProperties` | `update-offer.jms-requestor.*` (relleno de `CustomerNO`) |
| `UpdateOfferResponseProperties` | `update-offer.response.*` (códigos y textos) |

---

## 10. Librería `chnn-cop-lib-operation-db`

La consulta de DataFetch va en la librería (como el lookup de zona horaria) y la lógica en el micro.

| Clase | Qué hace |
|---|---|
| `CopOfferFulfillmentNatives` | El SQL: une `D_OFFERPALETTE`, `D_CAMPAIGN`, `D_PRODUCT` y `D_WAVECHINFO` (por `CAMPAIGNID = CMPID` y `PRDCODE`) con `D_WAVECHINFO.EXTID$ = ?` y `D_OFFERPALETTE.EXTID$ = ?` |
| `CopOfferFulfillmentRepository` | Ejecuta el SQL |
| `CopOfferFulfillmentService` + `…Impl` | `findByWaveKeyAndOfferKey(waveKey, offerKey)` delega en el repositorio |
| `CopOfferFulfillment` (record) | Los 14 datos de la oferta (`crpCategoryId`, `prdType`, `reasonCode`, `reasonDesc`, `prdDescription`, `fulfillmentProcId`, `userFields`, `apptStartDate`, `apptEndDate`, `expiryDate`, `offerCreationDate`, `prdCode`, `prdFamily`, `availability`) |

---

## 11. Variables globales de BW ↔ yml

| Global de BW | Propiedad | Valor actual | Usada en |
|---|---|---|---|
| `AuditPointsEnabled` | `audit.points-enabled` | `1001` | `AuditLogService` |
| `RequestTimeout_Category1` | `update-offer.ems.timeout-seconds` | `7` | `EmsSender` |
| `JMSExpiration` | `update-offer.ems.time-to-live-ms` | `0` (BW: 30 ms) | `EmsSender`, `JmsOfferPublisher` |
| `PadCharacter` | `update-offer.jms-requestor.customer-padding-char` | `0` | `OfferEventMapper` |
| `CustomerPadding` / longitud | `customer-padding` / `customer-padding-length` | `false` / `19` | `OfferEventMapper` |
| `TranslateTimeZone` | `update-offer.timezone.translate-time-zone` | `true` (BW: `false`; lo dejaste en `true` y configurable) | `UpdateOfferServiceImpl`, `OfferEventMapper` |
| `ECRMTimeZone` | `update-offer.timezone.ecrm-time-zone` | `US/Central` | Mapeos, respuesta, evento |
| `TimeZoneDateTimeFormat` | `…time-zone-date-time-format` | `yyyy-MM-dd'T'HH:mm:ssZ` | `TimeZoneMapRequest` |
| `BETimeFormat` | `…be-time-format` | `HH:mm:ss` | `TimeZoneMapRequest` |
| `BEDateTimeFormat` | `…be-date-time-format` | `yyyy-MM-dd HH:mm:ss` | `TimeZoneMapRequest` |
| `CheckForSuppression` | `cop.suppression.check-for-suppression` | `N` | `PerformSuppressionCheckService` |
| `EHKafkaUpdate_Delay` | `offer.kafka.delay-ms` | `200` | `OfferFulfillmentEmsSender` |
| `isKafkaOn_1` | `offer.kafka.enabled` | `true` | `UpdateOfferServiceImpl` |
| `AbInitioTest` | `update-offer.ab-initio-test` | `N` | `UpdateOfferServiceImpl` |
| `concat` de sector/Business/Región/…/`UpdateOffer` | `update-offer.ems.queue` | cola fija | `EmsSender` |

`ApplicationName`, `Application_CSI_ID` y `ComponentName` ya no se usan.

---

## 12. Lo que existe solo en el micro (sin equivalente en TIBCO)

| Pieza | Por qué |
|---|---|
| `paso()` / `StepFailedException` | Decir en qué paso falló la oferta |
| `retry` con backoff | BW dependía de su manejo de fallas |
| Ejecutor acotado y `KafkaMetrics` | Que el evento no frene ni sature el REST |
| `EventDestinations` y `AlternateEmsProps` | Kafka tardará: destinos independientes y apagables |
| Modos dry-run (`update-offer.ems.dry-run`, `offer.kafka.mode`) | Ver el mensaje sin enviarlo |
| `send-without-db-rows` | Mandar el evento aunque la BD no traiga la oferta |
| `response.source` | Elegir si la respuesta la arma el micro o el EMS |
| `LibraryBeanDeduplicator` y las `*Config` de la librería | Pegamento de Spring con `cops-bd` |

---

## 13. Qué pasa cuando algo falla

| Falla | Qué hace el micro | Respuesta REST |
|---|---|---|
| Falta o es inválido un header obligatorio | Rechaza la librería | 400 (406 si `Accept` no es JSON) con su `ErrorResponse` |
| Body inválido (`@Valid`) | Rechaza con el manejador global | 400 |
| Excepción en zona horaria | Registra | `ERROR` — "Falló en Validación de zona horaria" |
| Zona horaria con código que no continúa (ej. `COP_TZCOD_115`) | No sigue a supresión ni al EMS | Código y texto de la zona horaria |
| Operación suprimida | No llega al EMS | `ResponseCode/Text` del detalle de supresión |
| Falla al armar XML o propiedades | Registra | `ERROR` — paso del armado |
| Falla el EMS (conexión, permiso de la cola) | Manda el evento con `ResponseCode/Text` nulos | `ERROR` — "Envío al EMS" |
| El EMS no contesta o contesta un error de negocio | Sigue el flujo | Éxito |
| Falta un dato obligatorio del evento | `KAFKA-INVALID`, no envía | Sin cambio |
| La oferta no está en la BD | Envía igual (`send-without-db-rows: true`) o `KAFKA-NO-ROWS` | Sin cambio |
| Falla la BD o la cola del destino | Reintenta 3 veces; luego `KAFKA-ERROR` y resultado con el paso | Sin cambio |
| Ejecutor lleno | `KAFKA-REJECTED` | Sin cambio |

---

## 14. Pruebas

Reglas: Given / When / Then, Javadoc en español y cobertura mínima de JaCoCo de 90 %.

| Grupo | Clases de prueba |
|---|---|
| Entrada y log | `UpdateOfferControllerTest`, `AuditLogServiceTest`, `DtoValidatorTest`, `DtoValidationTest`, `UpdateOfferRequestValidationTest`, `KeyProcessEnumTest` |
| Orquestación y respuesta | `UpdateOfferServiceImplTest`, `UpdateOfferResponseFactoryTest` |
| Zona horaria | `TimeZoneValidationServiceTest`, `InitTZTest`, `TimeZoneMapRequestTest`, `CopTimezoneLookupClientTest`, `UpdateOfferFlowConditionsTest` |
| Supresión | `PerformSuppressionCheckServiceTest`, `SuppressionCheckServiceTest`, `DbSuppressedEntitiesClientTest`, `StartUpSuppressionLoaderTest` |
| Mensaje al EMS | `UpdateOfferMapperTest`, `UpdateOfferRequestXmlMapperTest`, `UpdateOfferResponseXmlMapperTest`, `OfferEventMapperTest`, `UserTextParserTest`, `XmlUtilTest`, `EmsSenderTest` |
| Evento | `OfferFulfillmentEmsSenderTest`, `KafkaSenderDashboardTest`, `OfferKeyBuilderTest`, `OfferDataClientTest`, `OfferKafkaPropsTest`, `EventDestinationsTest`, `JmsOfferPublisherTest`, `KafkaMetricsTest` |
| Configuración | `UpdateOfferApplicationTest`, `EntityScanConfigTest`, `OfferFulfillmentConfigTest`, `LibraryBeanDeduplicatorTest`, `LibraryRepositoryFragmentsConfigTest` |
| Apoyo | `TestData`, `XmlTestUtil` |

Las pruebas del endpoint se hacen con SoapUI (no hay peticiones de prueba en el repositorio).

---

## 15. Lo que sigue abierto

- **Varias ofertas en un solo mensaje al EMS:** BW las manda juntas; hoy el micro manda un mensaje por oferta (`UpdateOfferResponseXmlMapper.fromReplies` ya está listo para leer la respuesta).
- **Ramas no migradas:** Counter Offer, Json Format y AbInitio (indicaste que solo va la rama XSD).
- **Códigos de zona horaria** `COP_TZCOD_000/114/115`, el horario de verano con `US/Central` y las conversiones de Request.
- **Origen de `Org`, `OrgUnit`, `TerminalID`, `UserID`** y de parte de los datos de ClientDetails (equipo / Apigee).
- **Quién carga la lista de supresión** en BW.
- **Cola del evento:** que exista en el EMS y que el usuario tenga permiso de envío. Es independiente del código.
