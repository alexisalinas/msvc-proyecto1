package com.banamex.cops.update_offer.dto.timeZoneValidation;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Un registro de configuración de zona horaria de la base de datos. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TzLookUpDTO {

    /** Sistema o canal. */
    @NotNull private String systemName;
    /** Modo del sistema. */
    @NotNull private String mode;
    /** Nombre de la zona horaria. */
    @NotNull private String timeZone;
    /** Tipo ({@code Request} o {@code Response}). */
    @NotNull private String type;
    /** Diferencia con UTC. */
    @NotNull private String timeOffset;
    /** Formato de fecha. */
    @NotNull private String dateFormat;
    /** Formato de hora. */
    @NotNull private String timeFormat;
    /** Formato de fecha-hora. */
    @NotNull private String dateTimeFormat;
}
