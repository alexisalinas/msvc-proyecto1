package com.banamex.cops.update_offer.dto.timeZoneValidation;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Formatos de la zona horaria de un sistema; pueden venir vacíos pero no ausentes. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TzFormatsDTO {

    /** Diferencia con UTC, por ejemplo {@code -0600}. */
    @NotNull private String timeZoneOffset;
    /** Formato de fecha del cliente. */
    @NotNull private String dateFormat;
    /** Formato de hora del cliente. */
    @NotNull private String timeFormat;
    /** Formato de fecha-hora del cliente. */
    @NotNull private String dateTimeFormat;
    /** Nombre de la zona horaria, por ejemplo {@code America/Mexico_City}. */
    @NotNull private String timeZone;
}
