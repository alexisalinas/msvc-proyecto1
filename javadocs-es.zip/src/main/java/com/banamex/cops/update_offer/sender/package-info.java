/** Envío al EMS del mensaje de actualización y publicación del evento de cumplimiento. */
package com.banamex.cops.update_offer.sender;
