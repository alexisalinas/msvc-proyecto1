/** Microservicio {@code chnn-cop-o-update-offer}: actualiza ofertas de campaña. Flujo: controlador REST, zona horaria, supresión, mensaje al EMS, evento de cumplimiento y respuesta por oferta. */
package com.banamex.cops.update_offer;
