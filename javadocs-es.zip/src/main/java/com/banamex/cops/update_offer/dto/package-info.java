/** Objetos de la petición y la respuesta REST. */
package com.banamex.cops.update_offer.dto;
