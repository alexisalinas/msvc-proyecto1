package com.banamex.cops.update_offer.dto.suppression;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Operación suprimida con el código y el texto de respuesta que se devuelven. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OperationDetailOutput {

    /** Nombre de la operación. */
    @NotBlank(message = "El campo OperationName es obligatorio")
    private String operationName;

    /** Canal que solicita la operación. */
    @NotBlank(message = "El campo ReqChannel es obligatorio")
    private String reqChannel;

    /** Bandera de la operación. */
    @NotBlank(message = "El campo OperationFlag es obligatorio")
    private String operationFlag;

    /** País. */
    @NotBlank(message = "El campo CountryCode es obligatorio")
    private String countryCode;

    /** Código de respuesta de la supresión. */
    @NotBlank(message = "El campo ResponseCode es obligatorio")
    private String responseCode;

    /** Texto de respuesta de la supresión. */
    @NotBlank(message = "El campo ResponseText es obligatorio")
    private String responseText;

    /** {@code true} cuando la operación está suprimida. */
    private String indicator;
}
