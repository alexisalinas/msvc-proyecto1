package com.banamex.cops.update_offer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Punto de arranque del microservicio {@code chnn-cop-o-update-offer}.
 * Recibe una lista de ofertas por REST, valida zona horaria y supresión, envía el mensaje de actualización al EMS
 * y publica el evento de cumplimiento de cada oferta.
 */
@SpringBootApplication(scanBasePackages = "com.banamex.cops.update_offer")
public class UpdateOfferApplication {

    /**
     * Arranca la aplicación Spring Boot.
     * @param args argumentos de línea de comandos
     */
    public static void main(String[] args) {
        SpringApplication.run(UpdateOfferApplication.class, args);
    }
}
