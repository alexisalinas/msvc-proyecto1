package com.banamex.cops.update_offer.dto.timeZoneValidation;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Resultado de la validación de zona horaria: código, texto, formatos y valores convertidos. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TimeZoneValidationResult {

    /** Código del resultado. */
    @NotBlank(message = "El campo ResponseCode es obligatorio")
    private String responseCode;

    /** Texto del resultado. */
    @NotBlank(message = "El campo ResponseText es obligatorio")
    private String responseText;

    /** Formatos de la zona horaria del sistema. */
    private TzFormatsDTO formats;

    /** Fechas y horas convertidas. */
    @Valid
    private MapRequestResultDTO mapResult;
}
