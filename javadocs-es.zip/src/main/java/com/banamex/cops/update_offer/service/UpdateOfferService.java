package com.banamex.cops.update_offer.service;

import com.banamex.cops.update_offer.dto.UpdateOfferHeaders;
import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;

import java.util.List;

/** Contrato del servicio que atiende la actualización de ofertas. */
public interface UpdateOfferService {

    /**
     * Procesa las ofertas de la petición, una por una.
     * @param requests ofertas recibidas en el body
     * @param headers headers de la petición
     * @return una respuesta por oferta, en el mismo orden
     */
    List<UpdateOfferResponse> updateOffer(List<UpdateOfferRequest> requests, UpdateOfferHeaders headers);
}
