package com.banamex.cops.update_offer.sender;

import jakarta.jms.BytesMessage;
import jakarta.jms.DeliveryMode;
import jakarta.jms.JMSException;
import jakarta.jms.MapMessage;
import jakarta.jms.Message;
import jakarta.jms.MessageConsumer;
import jakarta.jms.MessageProducer;
import jakarta.jms.TemporaryQueue;
import jakarta.jms.TextMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Envía al EMS el mensaje de actualización de la oferta y devuelve la respuesta de la cola como texto.
 * El mensaje lleva el XML y/o las propiedades según {@code update-offer.ems.message-format}. La conversión de la
 * respuesta a {@code UpdateOfferResponse} la hace {@link com.banamex.cops.update_offer.mapper.UpdateOfferMapper}.
 */
@Slf4j
@Component
public class EmsSender {

    /** Reconoce el número de tarjeta en el XML para enmascararlo en el log. */
    private static final Pattern CARD = Pattern.compile("(<(?:\\w+:)?(?:CardNumber|CardNO)(?:\\s[^>]*)?>)\\d*(\\d{4})(</)");

    /** Respuesta simulada cuando {@code dry-run} es {@code true}. */
    private static final String DRY_RUN_REPLY =
            "<Response><Code>DRY-RUN</Code>"
            + "<Description>Mensaje NO enviado al EMS (update-offer.ems.dry-run=true)</Description></Response>";

    /** Plantilla JMS de la conexión al EMS principal. */
    private final JmsTemplate updateOfferJmsTemplate;

    /** Contenido del mensaje: {@code properties} (por defecto), {@code both} o {@code xml}. */
    @Value("${update-offer.ems.message-format:properties}")
    private String messageFormat = "properties";

    /** Cola del EMS a la que se envía el mensaje. */
    @Value("${update-offer.ems.queue}")
    private String queueName;

    /** Segundos que se espera la respuesta; con 0 o menos no se espera respuesta. */
    @Value("${update-offer.ems.timeout-seconds:30}")
    private long timeoutSeconds;

    /** Vigencia del mensaje en milisegundos; 0 = no expira. */
    @Value("${update-offer.ems.time-to-live-ms:0}")
    private long timeToLiveMs;

    /** Si es {@code true}, solo escribe el mensaje en el log y no se conecta al EMS. */
    @Value("${update-offer.ems.dry-run:false}")
    private boolean dryRun;

    /**
     * Crea el emisor. La plantilla es perezosa para que la conexión se cree solo al primer envío.
     * @param updateOfferJmsTemplate plantilla JMS del EMS principal
     */
    public EmsSender(@Qualifier("updateOfferJmsTemplate") @Lazy JmsTemplate updateOfferJmsTemplate) {
        this.updateOfferJmsTemplate = updateOfferJmsTemplate;
    }

    /**
     * Envía el XML sin propiedades y espera la respuesta.
     * @param xml mensaje a enviar
     * @return respuesta del EMS, o {@code null} si no hubo
     */
    public String send(String xml) {
        return send(xml, Map.of());
    }

    /**
     * Envía el mensaje a la cola del EMS y espera la respuesta.
     * Crea una cola temporal para la respuesta, publica el mensaje sin persistencia y espera hasta el tiempo configurado.
     * El número de tarjeta se enmascara en el log.
     * @param xml cuerpo del mensaje
     * @param properties propiedades del mensaje
     * @return texto de la respuesta, o {@code null} si no hubo respuesta a tiempo
     * @throws RuntimeException si falla el envío o la conexión con el EMS
     */
    public String send(String xml, Map<String, String> properties) {
        String queue = queueName;
        boolean soloXml = "xml".equalsIgnoreCase(messageFormat);
        Map<String, String> props = soloXml || properties == null ? Map.of() : properties;
        boolean soloPropiedades = "properties".equalsIgnoreCase(messageFormat) && !props.isEmpty();
        String body = soloPropiedades ? "" : xml;
        String masked = CARD.matcher(xml).replaceAll("$1************$2$3");

        if (dryRun) {
            log.info("[EMS] dry-run: no se envió. Enviaría a queue={}:\n{}", queue, masked);
            return DRY_RUN_REPLY;
        }

        log.info("[EMS] Envía a queue={} ({} propiedades):\n{}", queue, props.size(), masked);

        try {
            String reply = updateOfferJmsTemplate.execute(session -> {
                boolean esperar = timeoutSeconds > 0;
                TemporaryQueue replyQueue = esperar ? session.createTemporaryQueue() : null;
                MessageConsumer consumer = esperar ? session.createConsumer(replyQueue) : null;
                try (MessageProducer producer = session.createProducer(session.createQueue(queue))) {

                    TextMessage message = session.createTextMessage(body);
                    for (Map.Entry<String, String> p : props.entrySet()) {
                        if (p.getValue() != null) {
                            message.setStringProperty(p.getKey(), p.getValue());
                        }
                    }
                    if (esperar) {
                        message.setJMSReplyTo(replyQueue);
                    }
                    producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
                    if (timeToLiveMs > 0) {
                        producer.setTimeToLive(timeToLiveMs);
                    }
                    producer.send(message);

                    if (!esperar) {
                        return null;
                    }
                    Message response = consumer.receive(timeoutSeconds * 1000);
                    return response == null ? null : readReply(response);
                } finally {
                    if (consumer != null) {
                        consumer.close();
                    }
                    if (replyQueue != null) {
                        replyQueue.delete();
                    }
                }
            }, true);

            log.info("[EMS] Responde:\n{}", reply != null ? reply : "(sin respuesta)");
            return reply;

        } catch (Exception e) {
            log.error("[EMS] Falló el envío a queue={}. Causas: {}", queue, causeChain(e), e);
            throw new RuntimeException("Error enviando al EMS: " + rootCause(e), e);
        }
    }

    /**
     * Causa más profunda como {@code Clase: mensaje}.
     * @param t excepción
     * @return texto de la causa
     */
    static String rootCause(Throwable t) {
        Throwable root = t;
        for (int i = 0; i < 20 && root.getCause() != null && root.getCause() != root; i++) {
            root = root.getCause();
        }
        return root.getClass().getSimpleName() + ": " + root.getMessage();
    }

    /**
     * Toda la cadena de causas en una línea ({@code A: msg <- B: msg}), para ver el origen sin recorrer el stacktrace.
     * @param t excepción
     * @return cadena de causas
     */
    static String causeChain(Throwable t) {
        StringBuilder sb = new StringBuilder();
        Throwable c = t;
        for (int i = 0; i < 20 && c != null; i++) {
            if (i > 0) sb.append(" <- ");
            sb.append(c.getClass().getSimpleName()).append(": ").append(c.getMessage());
            if (c.getCause() == c) break;
            c = c.getCause();
        }
        return sb.toString();
    }

    /**
     * Extrae el texto de la respuesta sin importar el tipo de mensaje (texto, bytes o mapa). Si el cuerpo viene vacío,
     * usa las propiedades del mensaje.
     * @param reply mensaje de respuesta
     * @return respuesta como texto
     * @throws JMSException si no se puede leer el mensaje
     */
    private String readReply(Message reply) throws JMSException {
        String body;
        if (reply instanceof TextMessage t) {
            body = t.getText();
        } else if (reply instanceof BytesMessage b) {
            byte[] data = new byte[(int) b.getBodyLength()];
            b.readBytes(data);
            body = new String(data, StandardCharsets.UTF_8);
        } else if (reply instanceof MapMessage m) {
            StringBuilder x = new StringBuilder("<Response>");
            Enumeration<?> keys = m.getMapNames();
            while (keys.hasMoreElements()) {
                String k = (String) keys.nextElement();
                x.append('<').append(k).append('>').append(m.getObject(k)).append("</").append(k).append('>');
            }
            body = x.append("</Response>").toString();
        } else {
            body = reply.toString();
        }

        if (body == null || body.isBlank()) {
            StringBuilder x = new StringBuilder("<Response>");
            Enumeration<?> pn = reply.getPropertyNames();
            while (pn.hasMoreElements()) {
                String k = (String) pn.nextElement();
                x.append('<').append(k).append('>').append(reply.getObjectProperty(k)).append("</").append(k).append('>');
            }
            body = x.append("</Response>").toString();
        }
        return body;
    }
}
