package com.banamex.cops.update_offer.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/** Una oferta del cuerpo de la petición; el body es una lista de estas. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateOfferRequest {

    /** Canal que solicita la actualización; también se usa para revisar la supresión. */
    @NotNull(message = "channelCode es obligatorio")
    private String channelCode;

    /** Campaña de la oferta. */
    @NotNull(message = "campaignId es obligatorio")
    @Size(min = 1, max = 20, message = "campaignId debe tener entre 1 y 20 caracteres")
    private String campaignId;

    /** Ola de la oferta. */
    @NotNull(message = "waveId es obligatorio")
    @Size(min = 1, max = 20, message = "waveId debe tener entre 1 y 20 caracteres")
    private String waveId;

    /** Cliente de la oferta. */
    @NotNull(message = "customerId es obligatorio")
    @Size(min = 1, max = 20, message = "customerId debe tener entre 1 y 20 caracteres")
    private String customerId;

    /** Versión de ejecución. */
    private KeyProcessEnum keyProcess;

    /** Número de cuenta. */
    @Size(min = 1, max = 35)
    private String accountNumber;

    /** Número de tarjeta; se enmascara en los logs. */
    @Size(min = 1, max = 19)
    private String cardNumber;

    /** Origen de la oferta. */
    private String offerSource;

    /** Prioridad de la oferta. */
    @Size(min = 1, max = 5)
    private String offerPriority;

    /** Quien asignó la oferta. */
    private String assignedBy;
    /** A quien se asignó la oferta. */
    private String assignedTo;
    /** Identificador del departamento. */
    private String departmentId;
    /** Identificador de la sucursal. */
    private String branchId;
    /** Fecha de la cita. */
    private String appointmentDate;
    /** Hora de inicio de la cita. */
    private String appointmentStartTime;
    /** Hora de fin de la cita. */
    private String appointmentEndTime;
    /** Número ofrecido (confirmación de la cita). */
    private String offeredNumber;

    /** Estado de la oferta. */
    @Size(min = 1, max = 2)
    private String offerStatus;

    /** Código del motivo. */
    private String reasonCode;
    /** Descripción del motivo. */
    private String reasonDescription;
    /** Monto o probabilidad de la oferta. */
    private String amount;
    /** Acción de la oferta. */
    private String offerActionCode;
    /** Comentarios. */
    private String comments;

    /** JSON con los campos de usuario ({@code UserField1} a {@code UserField100}). */
    @Pattern(regexp = "(?s)^\\{.*\\}$", message = "userText debe ser un JSON válido")
    private String userText;

    /** Número o indicador de contacto. */
    private String contactIndicatorNumber;
    /** Referencia del contacto con el cliente. */
    private String customerReferenceNumber;
    /** Código del regalo. */
    private String giftCode;
    /** Confirmación del regalo. */
    private String giftConfirmationNumber;
    /** Referencia de seguimiento del cumplimiento. */
    private String fulfillmentTrackerFlag;
    /** Código del nivel. */
    private String levelCode;

    /** Versión del esquema. */
    @Size(min = 1, max = 3)
    private String schemaVersion;

    /** Grupo de trabajo. */
    private String workgroupId;
    /** Nombre del agente. */
    private String agentName;
    /** Código de la división. */
    private String divisionCode;
    /** Región de la sucursal. */
    private String branchRegionIdentifier;
    /** Identificador del área. */
    private String areaIdentifier;
    /** Tipo de contacto. */
    private String contactType;
    /** Categoría de la oferta. */
    private String offerCategory;
    /** Nombre de la sucursal. */
    private String branchName;
    /** Propósito del contacto. */
    private String purpose;
    /** Nombre del departamento. */
    private String departmentName;
    /** Canal de respuesta. */
    private String responseChannel;
    /** Correo electrónico del cliente. */
    private String customerEmailAddress;
    /** Guion o código de cumplimiento. */
    private String fulfillmentCode;

    /** Campos de control; el primero es el campo de control y el segundo el indicador de ubicación. */
    @Valid
    private List<ControlFieldDTO> contextType;
}