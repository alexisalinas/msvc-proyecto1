/** Log de auditoría de la petición recibida y de la respuesta devuelta. */
package com.banamex.cops.update_offer.audit;
