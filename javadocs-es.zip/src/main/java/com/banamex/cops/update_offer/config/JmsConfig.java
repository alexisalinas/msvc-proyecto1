package com.banamex.cops.update_offer.config;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import org.springframework.jms.core.JmsTemplate;

import com.citibanamex.messaging.connector.config.jms.JmsProperties;
import com.citibanamex.messaging.connector.ems.config.EmsConnectionFactory;
import com.citibanamex.messaging.connector.ems.config.EmsJmsTemplate;
import com.citibanamex.messaging.connector.ems.service.IdentityService;
import com.citibanamex.messaging.connector.ems.service.impl.IdentityServiceImpl;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.json.JsonMapper;

import jakarta.jms.ConnectionFactory;
import jakarta.jms.JMSException;
import lombok.extern.slf4j.Slf4j;

/**
 * Configuración de las conexiones JMS: el EMS principal al que se envía la actualización y el EMS alterno del evento.
 */
@Configuration
@Slf4j
public class JmsConfig {

    /**
     * Mapper JSON compartido.
     * @return mapper JSON
     */
    @Bean("jsonMapper")
    public JsonMapper jsonMapper() {
        return JsonMapper.builder().findAndAddModules().disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS).build();
    }

    /**
     * Propiedades de las conexiones JMS del yml ({@code digital-integration.messaging.jms}).
     * @return propiedades JMS
     */
    @Bean("jmsProperties")
    @ConfigurationProperties(prefix = "digital-integration.messaging.jms")
    public JmsProperties jmsProperties() {
        return new JmsProperties();
    }

    /**
     * Servicio de identidad que se usa para las credenciales del EMS.
     * @return servicio de identidad
     */
    @Bean("localOrRemoteIdentityService")
    @Primary
    public IdentityService localOrRemoteIdentityService() {
        IdentityService remote = new IdentityServiceImpl(10);
        return location -> {
            if (location.startsWith("http://") || location.startsWith("https://")) {
                return remote.getIdentity(location);
            }
            try {
                return Files.readAllBytes(Path.of(location));
            } catch (IOException e) {
                throw new UncheckedIOException("No se pudo leer la identidad: " + location, e);
            }
        };
    }

    /**
     * Fábrica de conexiones del EMS.
     * @param identityService servicio de identidad
     * @return fábrica de conexiones
     */
    @Bean("emsConnectionFactoryBean")
    public EmsConnectionFactory emsConnectionFactoryBean(IdentityService identityService) {
        return new EmsConnectionFactory(identityService);
    }

    /**
     * Plantilla JMS base del EMS.
     * @return plantilla JMS
     */
    @Bean("emsJmsTemplateBean")
    public EmsJmsTemplate emsJmsTemplateBean() {
        return new EmsJmsTemplate();
    }

    /**
     * Conexión al EMS principal.
     * @return fábrica de conexiones del EMS principal
     */
    @Bean("updateOfferConnectionFactory")
    public ConnectionFactory updateOfferConnectionFactory(
            @Qualifier("emsConnectionFactoryBean") EmsConnectionFactory emsConnectionFactory,
            JmsProperties props) throws JMSException {
        JmsProperties.JmsConnection connection =
                props.getPlatforms().get(0).getConnections().get(0);
        log.info("Creando ConnectionFactory EMS: id={}, brokerUrl={}",
                connection.getId(), connection.getBrokerUrl());
        return emsConnectionFactory.createInstance(connection);
    }

    /**
     * Plantilla JMS del EMS principal, usada por {@link com.banamex.cops.update_offer.sender.EmsSender}.
     * @return plantilla JMS
     */
    @Bean("updateOfferJmsTemplate")
    public JmsTemplate updateOfferJmsTemplate(
            @Qualifier("updateOfferConnectionFactory") ConnectionFactory connectionFactory,
            @Qualifier("emsJmsTemplateBean") EmsJmsTemplate emsJmsTemplate,
            @Value("${update-offer.ems.timeout-seconds:30}") long timeoutSeconds) {
        return emsJmsTemplate.createInstance(connectionFactory, timeoutSeconds * 1000);
    }

    /**
     * Conexión al EMS alterno: la del yml cuyo {@code jmsTemplateName} es {@code offer.alternate-ems.jms-template-name}. Solo existe si el destino está activo y se crea al primer envío.
     * @return fábrica de conexiones del EMS alterno
     */
    @Lazy
    @Bean("alternateEmsConnectionFactory")
    @ConditionalOnProperty(name = "offer.alternate-ems.enabled", havingValue = "true")
    public ConnectionFactory alternateEmsConnectionFactory(
            @Qualifier("emsConnectionFactoryBean") EmsConnectionFactory emsConnectionFactory,
            JmsProperties props,
            @Value("${offer.alternate-ems.jms-template-name:alternateEmsJmsTemplate}") String templateName) throws JMSException {
        JmsProperties.JmsConnection connection = props.getPlatforms().stream()
                .flatMap(platform -> platform.getConnections().stream())
                .filter(c -> templateName.equals(c.getJmsTemplateName()))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException(
                        "No hay conexión con jmsTemplateName=" + templateName + " en digital-integration.messaging.jms.platforms"));
        log.info("Creando ConnectionFactory EMS alterno: id={}, brokerUrl={}",
                connection.getId(), connection.getBrokerUrl());
        return emsConnectionFactory.createInstance(connection);
    }

    /**
     * Plantilla JMS del EMS alterno; se crea al primer envío.
     * @return plantilla JMS
     */
    @Lazy
    @Bean("alternateEmsJmsTemplate")
    @ConditionalOnProperty(name = "offer.alternate-ems.enabled", havingValue = "true")
    public JmsTemplate alternateEmsJmsTemplate(
            @Qualifier("alternateEmsConnectionFactory") ConnectionFactory connectionFactory,
            @Qualifier("emsJmsTemplateBean") EmsJmsTemplate emsJmsTemplate,
            @Value("${update-offer.ems.timeout-seconds:30}") long timeoutSeconds) {
        return emsJmsTemplate.createInstance(connectionFactory, timeoutSeconds * 1000);
    }

}
