package com.banamex.cops.update_offer.mapper;

import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import com.banamex.cops.update_offer.dto.timeZoneValidation.MapRequestResultDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Fachada de conversiones que usa el servicio: de la oferta al mensaje del EMS y de la respuesta del EMS a la respuesta REST.
 */
@Component
@RequiredArgsConstructor
public class UpdateOfferMapper {

    /** Arma el XML y las propiedades del mensaje. */
    private final UpdateOfferRequestXmlMapper requestXmlMapper;
    /** Lee la respuesta del EMS. */
    private final UpdateOfferResponseXmlMapper responseXmlMapper;

    /**
     * Propiedades del mensaje al EMS: el nombre y el namespace del evento más los campos de la oferta.
     * @param rq oferta
     * @param requestTime hora de proceso
     * @param updatedBy valor del header {@code client_id}
     * @param tzResponseCode código de zona horaria
     * @param tz fechas y horas convertidas
     * @return propiedades del mensaje
     */
    public java.util.Map<String, String> toEmsProperties(UpdateOfferRequest rq, LocalDateTime requestTime, String updatedBy,
                                                         String tzResponseCode, MapRequestResultDTO tz) {
        return requestXmlMapper.toEmsProperties(rq, requestTime, updatedBy, tzResponseCode, tz);
    }

    /**
     * XML que se envía al EMS con el evento {@code UpdateOffer}.
     * @param rq oferta
     * @param requestTime hora de proceso
     * @param updatedBy valor del header {@code client_id}
     * @param tzResponseCode código de zona horaria
     * @param tz fechas y horas convertidas
     * @return XML del mensaje
     */
    public String toEmsXml(UpdateOfferRequest rq, LocalDateTime requestTime, String updatedBy,
                           String tzResponseCode, MapRequestResultDTO tz) {
        return requestXmlMapper.toEmsXml(rq, requestTime, updatedBy, tzResponseCode, tz);
    }

    /**
     * Una respuesta por oferta: cuando el mensaje lleva varias ofertas, el EMS contesta una por cada una.
     * @param reply respuesta cruda del EMS
     * @return respuestas leídas
     */
    public List<UpdateOfferResponse> toRestResponses(String reply) {
        return responseXmlMapper.fromReplies(reply);
    }

    /**
     * Convierte la respuesta del EMS (XML o JSON) en una sola respuesta REST.
     * @param reply respuesta cruda del EMS
     * @return respuesta REST
     */
    public UpdateOfferResponse toRestResponse(String reply) {
        return responseXmlMapper.fromReply(reply);
    }
}
