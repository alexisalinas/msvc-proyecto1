package com.banamex.cops.update_offer.service.timeZoneValidation;

import com.banamex.cops.update_offer.dto.timeZoneValidation.TzLookUpDTO;

import java.util.List;

/** Consulta la configuración de zona horaria por sistema, modo y tipo. */
public interface TimeZoneLookupClient {
    /**
     * Busca la configuración.
     * @param system sistema o canal
     * @param sysMode modo del sistema
     * @param type {@code Request} o {@code Response}
     * @return registros encontrados, vacío si no hay
     */
    List<TzLookUpDTO> find(String system, String sysMode, String type);
}
