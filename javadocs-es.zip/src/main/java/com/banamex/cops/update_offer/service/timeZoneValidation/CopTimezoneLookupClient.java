package com.banamex.cops.update_offer.service.timeZoneValidation;

import com.banamex.cops.app.model.CopTimezoneLookup;
import com.banamex.cops.app.service.CopTimezoneLookupService;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TzLookUpDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Consulta la configuración de zona horaria en la tabla {@code COP_TIMEZONE_LOOKUP} a través de la librería
 * {@code chnn-cop-lib-operation-db} ({@code CopTimezoneLookupService}).
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CopTimezoneLookupClient implements TimeZoneLookupClient {

    /** Servicio de la librería, que se obtiene hasta que se usa. */
    private final ObjectProvider<CopTimezoneLookupService> lookupService;

    /**
     * Busca la configuración del sistema, modo y tipo.
     * @param system sistema o canal
     * @param sysMode modo del sistema
     * @param type {@code Request} o {@code Response}
     * @return registros encontrados, vacío si no hay
     */
    @Override
    public List<TzLookUpDTO> find(String system, String sysMode, String type) {
        CopTimezoneLookupService service = lookupService.orderedStream().findFirst().orElse(null);
        if (service == null) {
            log.warn("CopTimezoneLookupService no está disponible (¿BD sin configurar?); sin lookup de zona horaria");
            return List.of();
        }
        return service.findBySystemNameAndModeAndOperationType(system, sysMode, type).stream()
                .map(this::toDto)
                .toList();
    }

    /**
     * Convierte el registro de la base en el DTO; un {@code NULL} de la base se vuelve cadena vacía porque los ocho campos son obligatorios.
     * @param r registro de la base
     * @return DTO
     */
    private TzLookUpDTO toDto(CopTimezoneLookup r) {
        TzLookUpDTO d = new TzLookUpDTO();
        d.setSystemName(nz(r.tzSystemName()));
        d.setMode(nz(r.tzMode()));
        d.setTimeZone(nz(r.tzTimezone()));
        d.setType(nz(r.tzOperationType()));
        d.setTimeOffset(nz(r.tzTimeOffset()));
        d.setDateFormat(nz(r.tzDateFormat()));
        d.setTimeFormat(nz(r.tzTimeFormat()));
        d.setDateTimeFormat(nz(r.tzDatetimeFormat()));
        return d;
    }

    /**
     * @param s texto
     * @return el texto, o cadena vacía si es nulo
     */
    private static String nz(String s) {
        return s == null ? "" : s;
    }
}
