/** Configuración de Spring: conexiones JMS, seguridad, propiedades de la respuesta y enlace con la librería de base de datos. */
package com.banamex.cops.update_offer.config;
