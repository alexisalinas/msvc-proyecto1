package com.banamex.cops.update_offer.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Códigos y textos de la respuesta que arma el micro por cada oferta y de los resultados del envío del evento
 * ({@code update-offer.response.*}). Los textos aceptan los marcadores {@code {dateTime}}, {@code {step}},
 * {@code {detail}}, {@code {destination}}, {@code {offerKey}} y {@code {campaignId}}.
 */
@Data
@Component
@ConfigurationProperties(prefix = "update-offer.response")
public class UpdateOfferResponseProperties {

    /** De dónde sale la respuesta de éxito: {@code micro} o {@code ems}. */
    private String source = "micro";

    /** Código cuando la oferta se procesó bien. */
    private String successCode = "COP_UPDOF_0";

    /** Texto de éxito. */
    private String successText = "Successfully update offer {dateTime}";

    /** Código cuando algo falla. */
    private String errorCode = "ERROR";

    /** Texto de error: la fecha y en qué paso falló. */
    private String errorText = "Error update offer {dateTime}. Falló en {step}: {detail}";

    /** Formato de la fecha ({@link java.time.format.DateTimeFormatter}). */
    private String dateFormat = "yyyy/MM/dd HH:mm:ss";

    /**
     * Si es {@code true}, las ofertas con {@code OfferStatus = "U"} responden con la llave de la oferta en el texto de éxito.
     */
    private boolean statusUBwFormat = true;

    /** Estado {@code U}: código cuando la oferta se procesó. */
    private String statusUSuccessCode = "COP_UPDOF_0";

    /**
     * Estado {@code U}: texto de éxito; {@code {offerKey}} es la llave {@code off:mx:campaña_ola_cliente[_cuenta][_tarjeta]}.
     */
    private String statusUSuccessText = "Successfully update offer {offerKey}";

    /** Estado {@code U}: código cuando la petición no trae {@code campaignId}. */
    private String statusUCampaignMissingCode = "COP_UPDOF_432";

    /** Estado {@code U}: texto cuando falta {@code campaignId}; {@code {campaignId}} es el valor recibido. */
    private String statusUCampaignMissingText = "Campaign cmp: {campaignId} is not present cannot proceed with the Update Offer";

    /** Texto del log cuando el evento se publicó. */
    private String kafkaSuccessText = "Successfully send offer to {destination} {dateTime}";

    /** Texto del log cuando el evento no tiene ningún destino activo. */
    private String kafkaDisabledText = "Envío del evento desactivado: no hay destino activo {dateTime}";

    /** Texto del log cuando el destino está en dry-run y no se publica nada. */
    private String kafkaDryRunText = "{destination} en dry-run: el mensaje no se publicó {dateTime}";

    /** Texto del log cuando el evento no se pudo enviar: la fecha y en qué falló. */
    private String kafkaErrorText = "Error send offer to {destination} {dateTime}. Falló en {step}: {detail}";
}
