package com.banamex.cops.update_offer.service.timeZoneValidation;

import com.banamex.cops.update_offer.dto.timeZoneValidation.DateGrpDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.DateTimeGrpDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.MapRequestResultDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TimeGrpDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.TzFormatsDTO;
import com.banamex.cops.update_offer.dto.timeZoneValidation.ValueItemDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.TemporalAccessor;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

/**
 * Valida y convierte fechas, horas y fechas-horas entre la zona del cliente y la zona del backend (ECRM).
 * Con tipo {@code Request} lleva los valores del cliente al backend; con {@code Response}, del backend al cliente.
 * Un valor inválido se marca con el estado {@code Invalid TimeZone}.
 */
@Service
@RequiredArgsConstructor
public class TimeZoneMapRequest {

    /** Estado de un valor inválido. */
    private static final String INVALID = "Invalid TimeZone";

    /** Zona del backend: un nombre como {@code America/Mexico_City} o una diferencia como {@code -06:00}. */
    @Value("${update-offer.timezone.ecrm-time-zone}")
    private String ecrmTimeZone;

    /** Patrón de origen con el que se leen las fechas-horas al convertirlas. */
    @Value("${update-offer.timezone.time-zone-date-time-format}")
    private String timeZoneDateTimeFormat;

    /** Formato de hora del backend. */
    @Value("${update-offer.timezone.be-time-format:HH:mm:ss}")
    private String beTimeFormat;

    /** Formato de fecha-hora del backend. */
    @Value("${update-offer.timezone.be-date-time-format:yyyy-MM-dd HH:mm:ss}")
    private String beDateTimeFormat;

    /**
     * Valida y convierte los valores recibidos.
     * @param type {@code Request} o {@code Response}; con otro valor devuelve un resultado vacío
     * @param f formatos de la zona horaria del sistema
     * @param dates fechas a convertir
     * @param times horas a convertir
     * @param dateTimes fechas-horas a convertir
     * @return valores convertidos o marcados como inválidos
     */
    public MapRequestResultDTO map(String type, TzFormatsDTO f,
                                   List<ValueItemDTO> dates,
                                   List<ValueItemDTO> times,
                                   List<ValueItemDTO> dateTimes) {
        MapRequestResultDTO out = new MapRequestResultDTO();
        boolean request = "request".equalsIgnoreCase(type);
        boolean response = "response".equalsIgnoreCase(type);
        if (!request && !response) {
            return out;
        }

        for (ValueItemDTO d : nz(dates)) {
            DateGrpDTO g = mapDate(request, f, d);
            if (g != null) out.getDateGrp().add(g);
        }

        for (ValueItemDTO t : nz(times)) {
            String v = t.getValue();
            if (request) {
                if (invalid(f.getTimeZoneOffset(), f.getTimeFormat(), v)) {
                    out.getTimeGrp().add(new TimeGrpDTO(v, INVALID, null));
                } else if (hasText(v)) {
                    try {
                        out.getTimeGrp().add(new TimeGrpDTO(convertTimeRequest(f, v), "", t.getName()));
                    } catch (DateTimeException | IllegalArgumentException e) {
                        out.getTimeGrp().add(new TimeGrpDTO(v, INVALID, null));
                    }
                }
            } else if (hasText(v)) {
                out.getTimeGrp().add(new TimeGrpDTO(formatTimeResponse(f, v), "", t.getName()));
            }
        }

        for (ValueItemDTO dt : nz(dateTimes)) {
            String v = dt.getValue();
            if (request) {
                if (invalid(f.getTimeZoneOffset(), f.getDateTimeFormat(), v)) {
                    out.getDateTimeGrp().add(new DateTimeGrpDTO(v, INVALID, null));
                } else if (hasText(v)) {
                    try {
                        out.getDateTimeGrp().add(new DateTimeGrpDTO(convertDateTimeRequest(f, v), "", dt.getName()));
                    } catch (DateTimeException | IllegalArgumentException e) {
                        out.getDateTimeGrp().add(new DateTimeGrpDTO(v, INVALID, null));
                    }
                }
            } else if (hasText(v)) {
                out.getDateTimeGrp().add(new DateTimeGrpDTO(formatDateTimeResponse(f, v), "", dt.getName()));
            }
        }
        return out;
    }

    /**
     * Valida y convierte una fecha.
     * @param request {@code true} si el tipo es {@code Request}
     * @param f formatos
     * @param d fecha
     * @return fecha convertida, o {@code null} si no trae valor
     */
    private DateGrpDTO mapDate(boolean request, TzFormatsDTO f, ValueItemDTO d) {
        String v = d.getValue();
        if (request) {
            if (invalid(f.getTimeZoneOffset(), f.getDateFormat(), v)) {
                return new DateGrpDTO(v, INVALID, null);
            }
            if (hasText(v)) {
                return new DateGrpDTO(parseDate(f.getDateFormat(), v) + "T00:00:00" + tzOffset(), "", d.getName());
            }
            return null;
        }
        return hasText(v) ? new DateGrpDTO(formatDate(f.getDateFormat(), v), "", d.getName()) : null;
    }

    /**
     * Hora del cliente, leída con su formato, llevada a la zona del backend y escrita con el formato del backend.
     * @param f formatos
     * @param v hora del cliente
     * @return hora convertida
     */
    private String convertTimeRequest(TzFormatsDTO f, String v) {
        ZoneId client = clientZone(f);
        LocalTime t = LocalTime.parse(v.trim(), DateTimeFormatter.ofPattern(f.getTimeFormat()));
        ZonedDateTime src = ZonedDateTime.of(LocalDate.now(client), t, client);
        return src.withZoneSameInstant(ecrmZone()).toLocalTime().format(DateTimeFormatter.ofPattern(beTimeFormat));
    }

    /**
     * Fecha-hora del cliente, llevada a la zona del backend y escrita con el formato del backend.
     * @param f formatos
     * @param v fecha-hora del cliente
     * @return fecha-hora convertida
     */
    private String convertDateTimeRequest(TzFormatsDTO f, String v) {
        ZonedDateTime src = parseZoned(v.trim(), f.getDateTimeFormat(), clientZone(f));
        return src.withZoneSameInstant(ecrmZone()).format(DateTimeFormatter.ofPattern(beDateTimeFormat));
    }

    /**
     * Lee el texto con el patrón; si no trae zona, supone la indicada.
     * @param v texto
     * @param pattern patrón
     * @param assumed zona que se supone
     * @return fecha-hora con zona
     */
    private ZonedDateTime parseZoned(String v, String pattern, ZoneId assumed) {
        DateTimeFormatter fm = DateTimeFormatter.ofPattern(pattern);
        try {
            TemporalAccessor ta = fm.parseBest(v, ZonedDateTime::from, OffsetDateTime::from, LocalDateTime::from);
            if (ta instanceof ZonedDateTime z) return z;
            if (ta instanceof OffsetDateTime o) return o.toZonedDateTime();
            return ((LocalDateTime) ta).atZone(assumed);
        } catch (DateTimeParseException e) {
            if (v.length() >= 3 && v.charAt(v.length() - 3) == ':') {
                return OffsetDateTime.parse(v).toZonedDateTime();
            }
            throw e;
        }
    }

    /**
     * Hora del backend (de hoy) llevada a la zona del cliente y escrita con su formato.
     * @param f formatos
     * @param timeVal hora del backend
     * @return hora convertida
     */
    private String formatTimeResponse(TzFormatsDTO f, String timeVal) {
        ZoneId ecrm = ecrmZone();
        ZonedDateTime src = ZonedDateTime.of(LocalDate.now(ecrm), parseBackendTime(timeVal), ecrm);
        return src.withZoneSameInstant(clientZone(f)).toLocalTime().format(DateTimeFormatter.ofPattern(f.getTimeFormat()));
    }

    /**
     * Lee la hora del backend con su formato; si no coincide, la intenta como {@code HH:mm:ss}.
     * @param value hora
     * @return hora leída
     */
    private LocalTime parseBackendTime(String value) {
        String v = value.trim();
        try {
            return LocalTime.parse(v, DateTimeFormatter.ofPattern(beTimeFormat));
        } catch (DateTimeException e) {
            return LocalTime.parse(v);
        }
    }

    /**
     * Fecha-hora del backend llevada al formato del cliente; si la diferencia horaria lleva {@code :}, se inserta en el valor.
     * @param f formatos
     * @param v fecha-hora del backend
     * @return fecha-hora convertida
     */
    private String formatDateTimeResponse(TzFormatsDTO f, String v) {
        String offset = f.getTimeZoneOffset();
        String dtvar;
        if (v.length() >= 3 && v.charAt(v.length() - 3) == ':') {
            dtvar = OffsetDateTime.parse(v.trim())
                    .atZoneSameInstant(clientZone(f))
                    .format(DateTimeFormatter.ofPattern(f.getDateTimeFormat()));
        } else {
            dtvar = convertedDateTime(v, f);
        }
        if (offset != null && offset.contains(":")) {
            int n = dtvar.length();
            return dtvar.substring(0, n - 2) + ":" + dtvar.substring(n - 2);
        }
        return dtvar;
    }

    /**
     * Interpreta el valor en la zona del backend con el patrón configurado y lo muestra en la zona del cliente con su formato.
     * @param v valor
     * @param f formatos
     * @return fecha-hora convertida
     */
    private String convertedDateTime(String v, TzFormatsDTO f) {
        try {
            SimpleDateFormat in = new SimpleDateFormat(timeZoneDateTimeFormat);
            in.setTimeZone(TimeZone.getTimeZone(ecrmTimeZone));
            Date d = in.parse(v);
            SimpleDateFormat out = new SimpleDateFormat(f.getDateTimeFormat());
            out.setTimeZone(TimeZone.getTimeZone(f.getTimeZone()));
            return out.format(d);
        } catch (Exception e) {
            throw new IllegalArgumentException("DateTime inválido: " + v, e);
        }
    }

    /**
     * Decide si un valor es inválido según la diferencia horaria y el formato del cliente.
     * @param offset diferencia con UTC
     * @param format formato esperado
     * @param value valor
     * @return {@code true} si es inválido
     */
    private boolean invalid(String offset, String format, String value) {
        if (isEmpty(offset)) return true;
        if (!hasText(value)) return false;
        return !validate(format, value);
    }

    /**
     * Revisa que el valor cumpla el formato.
     * @param format formato esperado
     * @param value valor
     * @return {@code true} si lo cumple
     */
    private boolean validate(String format, String value) {
        try {
            SimpleDateFormat s = new SimpleDateFormat(format);
            s.setLenient(false);
            s.parse(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Lee una fecha con el formato del cliente y la devuelve en formato ISO.
     * @param format formato del cliente
     * @param value fecha
     * @return fecha ISO
     */
    private String parseDate(String format, String value) {
        try {
            SimpleDateFormat s = new SimpleDateFormat(format);
            s.setLenient(false);
            return new SimpleDateFormat("yyyy-MM-dd").format(s.parse(value));
        } catch (Exception e) {
            throw new IllegalArgumentException("Fecha inválida: " + value, e);
        }
    }

    /**
     * Escribe una fecha ISO con el formato del cliente.
     * @param format formato del cliente
     * @param isoValue fecha ISO
     * @return fecha con el formato del cliente
     */
    private String formatDate(String format, String isoValue) {
        LocalDateTime ldt;
        try {
            ldt = OffsetDateTime.parse(isoValue).toLocalDateTime();
        } catch (Exception e) {
            ldt = LocalDateTime.parse(isoValue);
        }
        return ldt.format(DateTimeFormatter.ofPattern(format));
    }

    /**
     * @return zona del backend
     */
    private ZoneId ecrmZone() {
        return ZoneId.of(ecrmTimeZone);
    }

    /**
     * @return diferencia con UTC de la zona del backend
     */
    private ZoneOffset ecrmOffset() {
        return ecrmZone().getRules().getOffset(Instant.now());
    }

    /**
     * Diferencia con UTC de la zona del backend con formato {@code -0600}, sin dos puntos.
     * @return diferencia horaria
     */
    private String tzOffset() {
        ZoneOffset o = ecrmOffset();
        return o.getTotalSeconds() == 0 ? "+0000" : o.getId().replace(":", "");
    }

    /**
     * Zona del cliente: su diferencia con UTC si viene; si no, el nombre de la zona.
     * @param f formatos
     * @return zona del cliente
     */
    private ZoneId clientZone(TzFormatsDTO f) {
        if (hasText(f.getTimeZoneOffset())) {
            return ZoneOffset.of(f.getTimeZoneOffset().trim());
        }
        if (hasText(f.getTimeZone())) {
            return ZoneId.of(f.getTimeZone().trim());
        }
        throw new IllegalArgumentException("No hay TimeZoneOffset ni TimeZone del cliente en la configuración");
    }

    /**
     * @param s texto
     * @return {@code true} si no es nulo ni está en blanco
     */
    private static boolean hasText(String s) { return s != null && !s.trim().isEmpty(); }
    /**
     * @param s texto
     * @return {@code true} si es nulo o vacío
     */
    private static boolean isEmpty(String s) { return s == null || s.isEmpty(); }
    /**
     * @param l lista
     * @param <T> tipo de los elementos
     * @return la lista, o una vacía si es nula
     */
    private static <T> List<T> nz(List<T> l) { return l == null ? List.of() : l; }
}
