package com.banamex.cops.update_offer.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/** Respuesta de una oferta. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UpdateOfferResponse {

    /** Código de retorno. */
    @NotNull(message = "El campo code es obligatorio")
    private String code;

    /** Descripción de la operación. */
    @NotNull(message = "El campo description es obligatorio")
    private String description;

    /** Referencia del contacto con el cliente. */
    private String customerReferenceNumber;

    /** Fecha de inicio. */
    private String startDate;

    /** Fecha de fin. */
    private String endDate;

    /** Modo de encuesta. */
    private String surveyModeCode;

    /** Campos de control. */
    @Valid
    private List<ControlFieldDTO> contextType;
}