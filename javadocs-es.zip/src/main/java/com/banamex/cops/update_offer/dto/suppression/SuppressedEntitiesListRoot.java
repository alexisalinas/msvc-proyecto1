package com.banamex.cops.update_offer.dto.suppression;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/** Lista de entidades suprimidas, armada desde la base de datos. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SuppressedEntitiesListRoot {

    /** Entidades suprimidas. */
    @NotNull
    @Valid
    @Builder.Default
    @JsonProperty("SuppressedEntities")
    private List<SuppressedEntityDTO> suppressedEntities = new ArrayList<>();
}
