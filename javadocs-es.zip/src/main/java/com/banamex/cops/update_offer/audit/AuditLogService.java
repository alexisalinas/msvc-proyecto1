package com.banamex.cops.update_offer.audit;

import com.banamex.cops.update_offer.dto.UpdateOfferHeaders;
import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Escribe en el log, en JSON, la petición que recibe el micro y la respuesta que devuelve.
 * Cada punto se activa con {@code audit.points-enabled}: el dígito 1 activa el log de la petición y el dígito 4 el de
 * la respuesta. Los headers sensibles y el número de tarjeta se enmascaran.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AuditLogService {

    /** Headers cuyo valor nunca se escribe en el log. */
    private static final Set<String> SENSITIVE_HEADERS = Set.of(
            "authorization", "proxy-authorization", "cookie", "set-cookie", "x-api-key", "api-key", "client_secret");

    /** Serializa los mensajes del log a JSON. */
    private final ObjectMapper jsonMapper;

    /** Puntos de auditoría activos, por ejemplo {@code 1001}. */
    @Value("${audit.points-enabled:1001}")
    private String pointsEnabled;

    /**
     * Escribe la petición recibida: headers y body.
     * @param headers headers de la petición
     * @param requests ofertas del body
     */
    public void logRequest(UpdateOfferHeaders headers, List<UpdateOfferRequest> requests) {
        if (!requestAuditEnabled()) {
            return;
        }
        try {
            Map<String, Object> message = new LinkedHashMap<>();
            message.put("headers", receivedHeaders(headers));
            message.put("body", maskedBody(requests));
            log.info("[REQUEST] uuid={}\n{}", uuid(headers), pretty(message));
        } catch (Exception e) {
            log.warn("No se pudo escribir el log del request: {}", e.getMessage());
        }
    }

    /**
     * Escribe la respuesta final del micro.
     * @param headers headers de la petición
     * @param responses respuestas por oferta
     */
    public void logResponse(UpdateOfferHeaders headers, List<UpdateOfferResponse> responses) {
        if (!responseAuditEnabled()) {
            return;
        }
        try {
            log.info("[RESPONSE] uuid={}\n{}", uuid(headers), pretty(responses));
        } catch (Exception e) {
            log.warn("No se pudo escribir el log de la respuesta: {}", e.getMessage());
        }
    }

    /**
     * @return {@code true} si el primer dígito de {@code audit.points-enabled} es 1
     */
    private boolean requestAuditEnabled() {
        return pointsEnabled != null && pointsEnabled.length() >= 1 && pointsEnabled.charAt(0) == '1';
    }

    /**
     * @return {@code true} si el cuarto dígito de {@code audit.points-enabled} es 1
     */
    private boolean responseAuditEnabled() {
        return pointsEnabled != null && pointsEnabled.length() >= 4 && pointsEnabled.charAt(3) == '1';
    }

    /**
     * Serializa el objeto a JSON con sangría.
     * @param value objeto
     * @return JSON en texto
     */
    private String pretty(Object value) {
        try {
            return jsonMapper.writerWithDefaultPrettyPrinter().writeValueAsString(value);
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo serializar a JSON: " + e.getMessage(), e);
        }
    }

    /**
     * @param headers headers de la petición
     * @return el uuid, o {@code null} si no hay headers
     */
    private static String uuid(UpdateOfferHeaders headers) {
        return headers == null ? null : headers.getUuid();
    }

    /**
     * Headers recibidos con los sensibles enmascarados; si no llegó el mapa completo, usa los headers conocidos.
     * @param h headers de la petición
     * @return mapa de nombre a valor
     */
    private Map<String, Object> receivedHeaders(UpdateOfferHeaders h) {
        Map<String, Object> out = new LinkedHashMap<>();
        if (h == null) {
            return out;
        }
        Map<String, String> source = new LinkedHashMap<>();
        if (h.getAll() != null && !h.getAll().isEmpty()) {
            source.putAll(h.getAll());
        } else {
            put(source, "uuid", h.getUuid());
            put(source, "host", h.getHost());
            put(source, "ChannelId", h.getChannelId());
            put(source, "countryCode", h.getCountryCode());
            put(source, "businessCode", h.getBusinessCode());
            put(source, "sid", h.getSid());
            put(source, "Accept-Language", h.getAcceptLanguage());
        }
        source.forEach((name, value) ->
                out.put(name, SENSITIVE_HEADERS.contains(name.toLowerCase(Locale.ROOT)) ? "****" : value));
        return out;
    }

    /**
     * Agrega el header al mapa solo si tiene valor.
     * @param map mapa destino
     * @param name nombre del header
     * @param value valor
     */
    private static void put(Map<String, String> map, String name, String value) {
        if (value != null) {
            map.put(name, value);
        }
    }

    /**
     * El body tal como llegó, con el número de tarjeta enmascarado.
     * @param requests ofertas del body
     * @return ofertas como mapas, o {@code null} si no hay body
     */
    @SuppressWarnings("unchecked")
    private List<Object> maskedBody(List<UpdateOfferRequest> requests) {
        if (requests == null) {
            return null;
        }
        return requests.stream().map(rq -> {
            Map<String, Object> fields = jsonMapper.convertValue(rq, Map.class);
            if (fields != null && fields.get("cardNumber") instanceof String card) {
                fields.put("cardNumber", mask(card));
            }
            return (Object) fields;
        }).toList();
    }

    /**
     * Deja solo los últimos 4 dígitos.
     * @param s texto
     * @return texto enmascarado
     */
    static String mask(String s) {
        if (s == null || s.length() <= 4) {
            return s;
        }
        return "*".repeat(s.length() - 4) + s.substring(s.length() - 4);
    }
}
