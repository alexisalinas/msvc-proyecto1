/** Validación de las reglas de los DTO internos. */
package com.banamex.cops.update_offer.validation;
