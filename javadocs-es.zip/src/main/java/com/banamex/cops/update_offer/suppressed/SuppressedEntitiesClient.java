package com.banamex.cops.update_offer.suppressed;

import com.banamex.cops.update_offer.dto.suppression.StartRequestParams;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntitiesListRoot;

/** Entrega la lista de entidades suprimidas. */
public interface SuppressedEntitiesClient {

    /**
     * Devuelve la lista de entidades suprimidas.
     * @param params datos de la petición
     * @return lista de entidades suprimidas
     */
    SuppressedEntitiesListRoot getListOfSuppressedEntities(StartRequestParams params);
}
