package com.banamex.cops.update_offer.suppressed;

import com.banamex.cops.app.model.CopSuppressionChannel;
import com.banamex.cops.app.model.CopSuppressionOperation;
import com.banamex.cops.update_offer.dto.suppression.OperationDetailsDTO;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntitiesListRoot;
import com.banamex.cops.update_offer.dto.suppression.SuppressedEntityDTO;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/** Arma la lista de entidades suprimidas con las filas de canales y de operaciones de la base. */
@Component
public class StartUpSuppressionLoader {

    /**
     * Arma la lista de entidades suprimidas.
     * @param channels canales suprimidos
     * @param operations operaciones suprimidas
     * @return lista armada
     */
    public SuppressedEntitiesListRoot build(List<CopSuppressionChannel> channels, List<CopSuppressionOperation> operations) {
        List<CopSuppressionOperation> ops = operations == null ? List.of() : operations;
        List<SuppressedEntityDTO> entities = new ArrayList<>();
        if (channels != null) {
            for (CopSuppressionChannel channel : channels) {
                entities.add(entity(channel, details(channel, ops)));
            }
        }
        return SuppressedEntitiesListRoot.builder().suppressedEntities(entities).build();
    }

    /**
     * Convierte un canal en una entidad con sus operaciones.
     * @param c canal
     * @param details operaciones del canal
     * @return entidad
     */
    private SuppressedEntityDTO entity(CopSuppressionChannel c, List<OperationDetailsDTO> details) {
        return SuppressedEntityDTO.builder()
                .countryCode(c.countryCode())
                .mode(c.reqMode())
                .channelId(c.channelId())
                .suppressionFlag(c.suppressionFlag())
                .operationFlag(c.operationFlag())
                .sourceSystem(c.sourceSystem())
                .operationDetails(details)
                .build();
    }

    /**
     * Operaciones del canal según sus banderas. Con supresión {@code Y} y operaciones {@code Y}: las operaciones de ese canal. Con supresión {@code Y} y operaciones {@code N}: todas las operaciones, cada una con su propia bandera. En otro caso: ninguna.
     * @param c canal
     * @param ops operaciones suprimidas
     * @return operaciones del canal
     */
    private List<OperationDetailsDTO> details(CopSuppressionChannel c, List<CopSuppressionOperation> ops) {
        List<OperationDetailsDTO> out = new ArrayList<>();
        if ("Y".equals(c.suppressionFlag()) && "Y".equals(c.operationFlag())) {
            for (CopSuppressionOperation o : ops) {
                if (o.reqChannel() != null && o.reqChannel().equals(c.channelId())) {
                    out.add(detail(o, "Y"));
                }
            }
        } else if ("Y".equals(c.suppressionFlag()) && "N".equals(c.operationFlag())) {
            for (CopSuppressionOperation o : ops) {
                out.add(detail(o, o.operationSuppressFlag()));
            }
        }
        return out;
    }

    /**
     * Convierte una operación de la base en su DTO.
     * @param o operación
     * @param operationFlag bandera de la operación
     * @return DTO de la operación
     */
    private OperationDetailsDTO detail(CopSuppressionOperation o, String operationFlag) {
        return OperationDetailsDTO.builder()
                .operationName(o.operationName())
                .operationFlag(operationFlag)
                .reqChannel(o.reqChannel())
                .build();
    }
}
