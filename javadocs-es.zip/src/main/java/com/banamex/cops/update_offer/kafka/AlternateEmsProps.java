package com.banamex.cops.update_offer.kafka;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/** Configuración del destino alterno del evento: una cola en otro EMS ({@code offer.alternate-ems.*}). */
@Data
@Component
@ConfigurationProperties(prefix = "offer.alternate-ems")
public class AlternateEmsProps {

    /** Si es {@code true}, el evento también se publica en este destino. */
    private boolean enabled = false;

    /** Nombre del bean {@code JmsTemplate} de la conexión al EMS alterno. */
    private String jmsTemplateName = "alternateEmsJmsTemplate";

    /** Cola del EMS alterno. */
    private String queue;

    /** Formato del mensaje: {@code json} o {@code envelope}. */
    private String messageFormat = "json";

    /** Vigencia del mensaje en milisegundos; 0 = no expira. */
    private long timeToLiveMs = 0;
}
