package com.banamex.cops.update_offer.kafka;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * Arma las llaves de la oferta, de la ola y la referencia del evento a partir de los valores sin modificar, tal como llegan en el request.
 */
@Component
@RequiredArgsConstructor
public class OfferKeyBuilder {

    /** Prefijos y separador configurados. */
    private final OfferKafkaProps props;

    /**
     * Llave de la oferta para la consulta ({@code D_OFFERPALETTE.EXTID$}): {@code off:mx:campaña:ola:cliente[:cuenta]}.
     * @param campaignId campaña
     * @param waveId ola
     * @param customerNo cliente
     * @param accountNo cuenta, opcional
     * @return llave de la oferta
     */
    public String offerKey(String campaignId, String waveId, String customerNo, String accountNo) {
        return props.getOfferPrefix() + join(props.getKeySeparator(), campaignId, waveId, customerNo, accountNo, null);
    }

    /**
     * Referencia del evento: {@code campaña_ola_cliente}, y con {@code _cuenta_tarjeta} solo si vienen ambas.
     * @param campaignId campaña
     * @param waveId ola
     * @param customerNo cliente
     * @param accountNo cuenta, opcional
     * @param cardNumber tarjeta, opcional
     * @return referencia del evento
     */
    public String refId(String campaignId, String waveId, String customerNo, String accountNo, String cardNumber) {
        boolean cuentaYTarjeta = hasText(accountNo) && hasText(cardNumber);
        return cuentaYTarjeta
                ? join("_", campaignId, waveId, customerNo, accountNo, cardNumber)
                : join("_", campaignId, waveId, customerNo, null, null);
    }

    /**
     * @param s texto
     * @return {@code true} si no es nulo ni está en blanco
     */
    private static boolean hasText(String s) {
        return s != null && !s.isBlank();
    }

    /**
     * Llave de la ola con su canal ({@code D_WAVECHINFO.EXTID$}): {@code wvch:ola:canal}.
     * @param waveId ola
     * @param channel canal
     * @return llave de la ola
     */
    public String waveKey(String waveId, String channel) {
        return props.getWavePrefix() + waveId + props.getKeySeparator() + channel;
    }

    /**
     * Une campaña, ola y cliente siempre; cuenta y tarjeta solo si traen valor.
     * @param sep separador
     * @param campaignId campaña
     * @param waveId ola
     * @param customerNo cliente
     * @param accountNo cuenta
     * @param cardNumber tarjeta
     * @return partes unidas
     */
    private static String join(String sep, String campaignId, String waveId, String customerNo,
                               String accountNo, String cardNumber) {
        StringBuilder sb = new StringBuilder();
        sb.append(campaignId).append(sep).append(waveId).append(sep).append(customerNo);
        if (!isBlank(accountNo)) sb.append(sep).append(accountNo);
        if (!isBlank(cardNumber)) sb.append(sep).append(cardNumber);
        return sb.toString();
    }

    /**
     * @param s texto
     * @return {@code true} si es nulo o está en blanco
     */
    private static boolean isBlank(String s) { return s == null || s.isBlank(); }
}
