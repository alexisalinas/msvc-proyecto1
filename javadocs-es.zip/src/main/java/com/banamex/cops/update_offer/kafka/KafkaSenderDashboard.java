package com.banamex.cops.update_offer.kafka;

import com.banamex.cops.update_offer.dto.UpdateOfferHeaders;
import com.banamex.cops.update_offer.dto.UpdateOfferRequest;
import com.banamex.cops.update_offer.dto.UpdateOfferResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Arma el evento de entrada del envío de cumplimiento ({@link OfferInput}) con el request, los headers HTTP y la
 * respuesta del EMS: llaves de la oferta, identificadores de la transacción y horas del evento.
 */
@Component
@RequiredArgsConstructor
public class KafkaSenderDashboard {

    /** Zona en la que se escribe la hora de respuesta ({@code ResponseTime}). */
    @Value("${update-offer.timezone.ecrm-time-zone:US/Central}")
    private String ecrmTimeZone = "US/Central";

    /** Genera el identificador ESB de la transacción (un GUID). */
    private Supplier<String> esbUuidGenerator = () -> UUID.randomUUID().toString();

    /** Formato de la hora de la transacción. */
    private static final DateTimeFormatter TRANSACTION_TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
    /** Formato con offset de la hora de respuesta. */
    private static final DateTimeFormatter WITH_OFFSET = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

    /** Arma las llaves de la oferta. */
    private final OfferKeyBuilder keys;

    /**
     * Arma el evento de entrada del envío.
     * @param rq oferta recibida
     * @param headers headers de la petición
     * @param requestTime hora en que se empezó a procesar la oferta
     * @param rs respuesta del EMS, o {@code null} si no hubo
     * @return evento de entrada
     */
    public OfferInput build(UpdateOfferRequest rq, UpdateOfferHeaders headers, LocalDateTime requestTime,
                            UpdateOfferResponse rs) {
        LocalDateTime time = requestTime != null ? requestTime : LocalDateTime.now();
        return OfferInput.builder()
                .uuid(headers.getUuid())
                .esbUuid(esbUuidGenerator.get())
                .channel(rq.getChannelCode())
                .transactionTime(time.format(TRANSACTION_TIME))
                .refId(keys.refId(rq.getCampaignId(), rq.getWaveId(), rq.getCustomerId(), rq.getAccountNumber(), rq.getCardNumber()))
                .offerKey(keys.offerKey(rq.getCampaignId(), rq.getWaveId(), rq.getCustomerId(), rq.getAccountNumber()))
                .campaignId(rq.getCampaignId())
                .waveId(rq.getWaveId())
                .customerNo(rq.getCustomerId())
                .accountNo(rq.getAccountNumber())
                .cardNumber(rq.getCardNumber())
                .offerStatus(rq.getOfferStatus())
                .actionId(rq.getOfferActionCode())
                .responseTime(OffsetDateTime.now(ZoneId.of(ecrmTimeZone)).format(WITH_OFFSET))
                .responseCode(rs != null ? rs.getCode() : null)
                .responseText(rs != null ? rs.getDescription() : null)
                .build();
    }
}
