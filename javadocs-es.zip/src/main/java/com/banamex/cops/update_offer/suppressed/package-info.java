/** Revisión de si una operación está suprimida para un canal y un país. */
package com.banamex.cops.update_offer.suppressed;
