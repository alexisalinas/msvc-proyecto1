/** Objetos de la revisión de supresión. */
package com.banamex.cops.update_offer.dto.suppression;
