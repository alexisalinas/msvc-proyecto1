/** Evento de cumplimiento de la oferta: configuración, llaves, destinos (puente a Kafka y EMS alterno), publicación y métricas. */
package com.banamex.cops.update_offer.kafka;
