/** Conversiones entre la oferta REST, el mensaje del EMS y la respuesta del EMS. */
package com.banamex.cops.update_offer.mapper;
