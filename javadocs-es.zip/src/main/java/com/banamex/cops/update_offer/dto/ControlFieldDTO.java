package com.banamex.cops.update_offer.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Campo de control de la oferta: solo lleva el {@code contextType}. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ControlFieldDTO {

    /** Valor del campo de control. */
    private String contextType;
}
