package com.banamex.cops.update_offer.dto.timeZoneValidation;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/** Resultado de la conversión: fechas, horas y fechas-horas. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MapRequestResultDTO {

    /** Fechas convertidas. */
    @NotNull @Valid @Builder.Default private List<DateGrpDTO> dateGrp = new ArrayList<>();
    /** Horas convertidas. */
    @NotNull @Valid @Builder.Default private List<TimeGrpDTO> timeGrp = new ArrayList<>();
    /** Fechas-horas convertidas. */
    @NotNull @Valid @Builder.Default private List<DateTimeGrpDTO> dateTimeGrp = new ArrayList<>();
}
