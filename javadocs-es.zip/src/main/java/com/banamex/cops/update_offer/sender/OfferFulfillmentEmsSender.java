package com.banamex.cops.update_offer.sender;

import com.banamex.cops.app.model.CopOfferFulfillment;
import com.banamex.cops.update_offer.kafka.KafkaMetrics;
import com.banamex.cops.update_offer.kafka.OfferDataClient;
import com.banamex.cops.update_offer.kafka.OfferInput;
import com.banamex.cops.update_offer.kafka.OfferKafkaProps;
import com.banamex.cops.update_offer.kafka.OfferKeyBuilder;
import com.banamex.cops.update_offer.kafka.EventDestinations;
import com.banamex.cops.update_offer.kafka.EventDestinations.EventDestination;
import com.banamex.cops.update_offer.service.UpdateOfferResponseFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.task.TaskExecutor;
import org.springframework.core.task.TaskRejectedException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Publica el evento de cumplimiento de la oferta ({@code Updateofferrequest}) en los destinos activos.
 * El envío corre en un ejecutor aparte para no retrasar la respuesta REST. Pasos de {@link #process}:
 * <ol>
 * <li>Valida que el evento traiga los campos obligatorios.</li>
 * <li>Espera el retardo configurado para que la base ya tenga la oferta.</li>
 * <li>Consulta los datos de la oferta en la base ({@link OfferDataClient}).</li>
 * <li>Ensambla el JSON del evento.</li>
 * <li>Lo publica en cada destino activo, con reintentos.</li>
 * </ol>
 */
@Slf4j
@Service
public class OfferFulfillmentEmsSender {

    /** Zona en la que se escribe la hora del evento ({@code timeStamp}). */
    @Value("${update-offer.timezone.ecrm-time-zone:US/Central}")
    private String ecrmTimeZone = "US/Central";

    /** Fecha-hora con milisegundos y offset. */
    private static final DateTimeFormatter WITH_OFFSET_MILLIS = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
    /** Fecha-hora local con milisegundos. */
    private static final DateTimeFormatter LOCAL_MILLIS = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
    /** Fecha-hora con segundos y offset, sin fracciones. */
    private static final DateTimeFormatter WITH_OFFSET_SECONDS = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssXXX");
    /** Reconoce el número de tarjeta en el JSON para enmascararlo en el log. */
    private static final Pattern CARD_IN_JSON = Pattern.compile("(\"CardNumber\"\\s*:\\s*\")(\\d*?)(\\d{4})\"");

    /** Configuración del evento. */
    private final OfferKafkaProps props;
    /** Arma las llaves de la oferta y de la ola. */
    private final OfferKeyBuilder keys;
    /** Consulta los datos de la oferta en la base. */
    private final OfferDataClient dataClient;
    /** Destinos activos del evento. */
    private final EventDestinations destinations;
    /** Serializa el evento a JSON. */
    private final ObjectMapper mapper;
    /** Contadores del flujo. */
    private final KafkaMetrics metrics;
    /** Ejecutor donde corre el envío, con cola acotada. */
    private final TaskExecutor executor;
    /** Textos de resultado del envío. */
    private final UpdateOfferResponseFactory responses;

    /**
     * Crea el emisor del evento de cumplimiento.
     * @param props configuración del evento
     * @param keys constructor de llaves
     * @param dataClient consulta a la base
     * @param destinations destinos activos
     * @param mapper serializador JSON
     * @param metrics contadores
     * @param executor ejecutor del envío
     * @param responses textos de resultado
     */
    public OfferFulfillmentEmsSender(OfferKafkaProps props, OfferKeyBuilder keys, OfferDataClient dataClient,
                              EventDestinations destinations, ObjectMapper mapper, KafkaMetrics metrics,
                              @Qualifier("offerFulfillmentExecutor") TaskExecutor executor,
                              UpdateOfferResponseFactory responses) {
        this.props = props;
        this.keys = keys;
        this.dataClient = dataClient;
        this.destinations = destinations;
        this.mapper = mapper;
        this.metrics = metrics;
        this.executor = executor;
        this.responses = responses;
    }

    /**
     * Indica si el evento se arma y hay al menos un destino activo.
     * @return {@code true} si se debe enviar el evento
     */
    public boolean isEnabled() {
        return props.isEnabled() && !destinations.enabled().isEmpty();
    }

    /**
     * Encola el envío en el ejecutor. Si la cola está llena, lo rechaza, lo cuenta y escribe el resultado en el log.
     * @param in evento de entrada
     */
    public void sendAsync(OfferInput in) {
        List<EventDestination> activos = destinations.enabled();
        try {
            executor.execute(() -> process(in));
        } catch (TaskRejectedException e) {
            metrics.incRejected();
            log.warn("KAFKA-REJECTED cola llena, no se envió uuid={} refId={}", in.getUuid(), in.getRefId());
            resultado(tag(activos), responses.kafkaErrorText(names(activos), "Cola de envío llena", "no hay espacio en el ejecutor"));
        }
    }

    /**
     * Valida el evento, consulta la base, arma el JSON y lo publica (síncrono; lo ejecuta el hilo del ejecutor).
     * Si la oferta no está en la base y {@code send-without-db-rows} es {@code true}, el evento se envía con los campos
     * de la base vacíos. Cualquier falla se escribe en el log; no se propaga.
     * @param in evento de entrada
     */
    public void process(OfferInput in) {
        List<EventDestination> activos = destinations.enabled();
        String tag = tag(activos);
        String destino = names(activos);
        String paso = "Validación del evento";
        try {
            if (!valid(in)) {
                resultado(tag, responses.kafkaErrorText(destino, paso,
                        "faltan campos obligatorios (RefID, CampaignID, WaveID, CustomerNo, OfferStatus)"));
                return;
            }
            if (props.getDelayMs() > 0) {
                paso = "Espera previa a la consulta";
                Thread.sleep(props.getDelayMs());
            }
            paso = "Consulta a la base de datos";
            String waveKey = keys.waveKey(in.getWaveId(), in.getChannel());
            Optional<CopOfferFulfillment> db =
                    retry("consulta a la BD", () -> dataClient.find(waveKey, in.getOfferKey()));
            if (db.isEmpty()) {
                metrics.incNoRows();
                if (!props.isSendWithoutDbRows()) {
                    log.error("KAFKA-NO-ROWS uuid={} refId={} waveKey={} offerKey={}",
                            in.getUuid(), in.getRefId(), waveKey, in.getOfferKey());
                    resultado(tag, responses.kafkaErrorText(destino, paso,
                            "no se encontró la oferta (waveKey=" + waveKey + ", offerKey=" + in.getOfferKey() + ")"));
                    return;
                }
                log.warn("KAFKA-NO-ROWS uuid={} refId={} waveKey={} offerKey={} se envía el evento sin los datos de la BD",
                        in.getUuid(), in.getRefId(), waveKey, in.getOfferKey());
                db = Optional.of(new CopOfferFulfillment(null, null, null, null, null, null, null,
                        null, null, null, null, null, null, null));
            }
            paso = "Armado del evento";
            String json = mapper.writeValueAsString(assemble(in, db.get()));
            log.info("[{}] Envía: {}", tag, maskCardInJson(json));
            for (EventDestination d : activos) {
                publicar(in, json, d);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.warn("KAFKA-ERROR interrumpido uuid={} refId={}", in.getUuid(), in.getRefId());
            resultado(tag, responses.kafkaErrorText(destino, paso, "el envío se interrumpió"));
        } catch (Exception e) {
            metrics.incFailed();
            log.error("KAFKA-ERROR uuid={} refId={} {}", in.getUuid(), in.getRefId(), e.toString(), e);
            resultado(tag, responses.kafkaErrorText(destino, paso, e));
        }
    }

    /**
     * Publica el JSON en un destino con reintentos; si falla, solo ese destino queda con error.
     * @param in evento de entrada
     * @param json evento serializado
     * @param d destino
     * @throws InterruptedException si el hilo se interrumpe
     */
    private void publicar(OfferInput in, String json, EventDestination d) throws InterruptedException {
        try {
            retry("publicación en " + d.name(), () -> d.publisher().publish(in.getRefId(), json));
            metrics.incSent();
            resultado(d.tag(), "dry-run".equals(props.getMode())
                    ? responses.kafkaDryRunText(d.name()) : responses.kafkaSuccessText(d.name()));
        } catch (InterruptedException e) {
            throw e;
        } catch (Exception e) {
            metrics.incFailed();
            log.error("KAFKA-ERROR uuid={} refId={} destino={} Causas: {}", in.getUuid(), in.getRefId(), d.name(), EmsSender.causeChain(e), e);
            resultado(d.tag(), responses.kafkaErrorText(d.name(), "Publicación en la cola de " + d.name(), e));
        }
    }

    /**
     * Escribe en el log el resultado del envío, con la fecha en la zona ECRM.
     * @param tag etiqueta del destino
     * @param mensaje texto del resultado
     */
    private void resultado(String tag, String mensaje) {
        log.info("[{}] Resultado: {}", tag, mensaje);
    }

    /**
     * Etiqueta del log de los destinos activos, unidas con {@code +}.
     * @param activos destinos activos
     * @return etiqueta
     */
    private static String tag(List<EventDestination> activos) {
        return activos.isEmpty() ? "KAFKA" : String.join("+", activos.stream().map(EventDestination::tag).toList());
    }

    /**
     * Nombres de los destinos activos para los textos de resultado.
     * @param activos destinos activos
     * @return nombres unidos
     */
    private static String names(List<EventDestination> activos) {
        return activos.isEmpty() ? "Kafka" : String.join(" y ", activos.stream().map(EventDestination::name).toList());
    }

    /**
     * Minutos de duración de la cita, de inicio a fin, redondeados.
     * @param start inicio de la cita
     * @param end fin de la cita
     * @return minutos, o {@code null} si falta algún dato o no es positivo
     */
    static Long appointmentMinutes(Timestamp start, Timestamp end) {
        if (start == null || end == null) return null;
        long minutes = Math.round((end.getTime() - start.getTime()) / 60000.0);
        return minutes > 0 ? minutes : null;
    }

    /**
     * Ensambla {@code { "event": { "header": ..., "body": ... } }} con los datos del request, de la respuesta del EMS
     * y de la base, en el orden del evento. Si {@code omit-nulls} es {@code true}, los campos nulos no se escriben.
     * @param in evento de entrada
     * @param db datos de la oferta en la base
     * @return estructura lista para serializar
     */
    Map<String, Object> assemble(OfferInput in, CopOfferFulfillment db) {
        Map<String, Object> header = new LinkedHashMap<>();
        header.put("name", props.getEventName());
        header.put("version", props.getEventVersion());
        header.put("producerCSI", props.getProducerCsi());
        header.put("Channel", in.getChannel());
        header.put("countryCode", props.getCountryCode());
        header.put("businessCode", props.getBusinessCode());
        header.put("UUID", in.getUuid());
        header.put("sid", isBlank(in.getEsbUuid()) ? in.getUuid() : in.getEsbUuid());
        header.put("transactionTime", isBlank(in.getTransactionTime())
                ? LocalDateTime.now().format(LOCAL_MILLIS) : in.getTransactionTime());
        header.put("timeStamp", OffsetDateTime.now(ZoneId.of(ecrmTimeZone)).format(WITH_OFFSET_MILLIS));

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("RefID", in.getRefId());
        body.put("CampaignID", in.getCampaignId());
        body.put("WaveID", in.getWaveId());
        body.put("CustomerNo", padLeft(in.getCustomerNo(), 9));
        body.put("AccountNo", in.getAccountNo());
        body.put("CardNumber", props.isMaskCardNumber() ? mask(in.getCardNumber()) : in.getCardNumber());
        body.put("OfferStatus", in.getOfferStatus());
        body.put("ID_ProductType", db.prdType());
        body.put("CRP_Category_ID", db.crpCategoryId());
        body.put("Product_Description", db.prdDescription());
        body.put("Reason_Code", db.reasonCode());
        body.put("Reason_Description", db.reasonDesc());
        body.put("Action_ID", in.getActionId());
        body.put("ResponseTime", in.getResponseTime());
        body.put("ResponseCode", in.getResponseCode());
        body.put("ResponseText", in.getResponseText());
        body.put("FulfillmentID", db.fulfillmentProcId());
        List<String> userFields = db.userFields();
        for (int i = 1; i <= 100; i++) {
            body.put("UserField" + i, userFields != null && i <= userFields.size() ? userFields.get(i - 1) : null);
        }
        body.put("AppointmentDate", iso(db.apptStartDate()));
        body.put("AppointmentMinDur", appointmentMinutes(db.apptStartDate(), db.apptEndDate()));
        body.put("OfferExpiryDate", iso(db.expiryDate()));
        body.put("OfferStartDate", iso(db.offerCreationDate()));
        body.put("PrdCode", db.prdCode());
        body.put("PrdFamily", db.prdFamily());
        body.put("Availability", db.availability());

        if (props.isOmitNulls()) {
            header.values().removeIf(Objects::isNull);
            body.values().removeIf(Objects::isNull);
        }

        Map<String, Object> event = new LinkedHashMap<>();
        event.put("header", header);
        event.put("body", body);
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("event", event);
        return root;
    }

    /**
     * Revisa que el evento traiga los campos obligatorios; si no, lo cuenta como inválido.
     * @param in evento de entrada
     * @return {@code true} si es válido
     */
    private boolean valid(OfferInput in) {
        if (isBlank(in.getRefId()) || isBlank(in.getOfferKey()) || isBlank(in.getCampaignId())
                || isBlank(in.getWaveId()) || isBlank(in.getCustomerNo()) || isBlank(in.getOfferStatus())) {
            metrics.incInvalid();
            log.error("KAFKA-INVALID uuid={} refId={} faltan campos obligatorios (RefID, CampaignID, WaveID, CustomerNo, OfferStatus)",
                    in.getUuid(), in.getRefId());
            return false;
        }
        return true;
    }

    /**
     * Reintenta solo fallas de infraestructura (excepciones), con espera creciente. Un resultado sin filas no es
     * excepción y no se reintenta.
     * @param what descripción de la acción para el log
     * @param action acción a ejecutar
     * @param <T> tipo del resultado
     * @return resultado de la acción
     * @throws Exception la última falla cuando se agotan los intentos
     */
    private <T> T retry(String what, Callable<T> action) throws Exception {
        long backoff = props.getRetryBackoffMs();
        for (int attempt = 1; ; attempt++) {
            try {
                return action.call();
            } catch (Exception e) {
                if (attempt >= props.getMaxAttempts()) {
                    throw e;
                }
                log.warn("KAFKA-RETRY {} intento {}/{}: {}", what, attempt, props.getMaxAttempts(), e.toString());
                if (backoff > 0) {
                    Thread.sleep(backoff);
                }
                backoff *= 2;
            }
        }
    }

    /**
     * Enmascara el número de tarjeta del JSON, dejando los últimos 4 dígitos (solo para el log).
     * @param json evento serializado
     * @return JSON enmascarado
     */
    static String maskCardInJson(String json) {
        Matcher m = CARD_IN_JSON.matcher(json);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            m.appendReplacement(sb, Matcher.quoteReplacement(m.group(1) + "*".repeat(m.group(2).length()) + m.group(3) + "\""));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    /**
     * Rellena con ceros a la izquierda hasta la longitud indicada.
     * @param s texto
     * @param len longitud deseada
     * @return texto completado, o {@code null} si es nulo
     */
    static String padLeft(String s, int len) {
        if (s == null) return null;
        StringBuilder sb = new StringBuilder();
        for (int i = s.length(); i < len; i++) sb.append('0');
        return sb.append(s).toString();
    }

    /**
     * Deja solo los últimos 4 caracteres y cambia el resto por {@code *}.
     * @param s texto
     * @return texto enmascarado
     */
    static String mask(String s) {
        if (s == null || s.length() <= 4) return s;
        return "*".repeat(s.length() - 4) + s.substring(s.length() - 4);
    }

    /**
     * Convierte una fecha de la base a fecha-hora con offset y sin fracciones, por ejemplo {@code 2026-12-31T00:00:00-06:00}.
     * @param v valor de la base
     * @return fecha en texto, o {@code null} si es nulo
     */
    static String iso(Object v) {
        if (v == null) return null;
        if (v instanceof Timestamp t) {
            return t.toLocalDateTime().atZone(ZoneId.systemDefault()).format(WITH_OFFSET_SECONDS);
        }
        return v.toString();
    }

    /**
     * @param s texto
     * @return {@code true} si es nulo o está en blanco
     */
    private static boolean isBlank(String s) { return s == null || s.isBlank(); }
}
